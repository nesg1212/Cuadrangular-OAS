/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : main.h
*	@funcion    : archivo Main Principal donde se inicializa todo el programa
*				  como los pines, task, etc.
*/
#ifndef SRC_MAIN_CPP_
#define SRC_MAIN_CPP_

#include "main.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "math.h"
#include "cmsis_os.h"
#include "semphr.h"
#include "config.h"

#if defined(STM32F411xE)
	#include "System/f411re/Initial_Config.h"
	#include "Util/structs.h"
	#include "Tasks/Base_Tasks.h"
	#include "Extensions/Pines.h"
	#include "Extensions/DigitalPins.h"
	#include "Extensions/AnalogPins.h"
	#include "Extensions/Serial.h"
	#include "Extensions/Time.h"
	#include "Extensions/SPI.h"
	#include "Extensions/SSD1306/SSD1306.h"
	#include "Extensions/Wire.h"
	#include "Extensions/Extra_String.h"
	#include "Extensions/UID.h"

	UID uid;
	DataESP32Datalogger dataDatalogger;
	Wire Wire3(I2C3, MASTER);
	SPI Spi2(SPI2, MASTER_MODE);
	Serial Serial2(USART2);
	Serial Serial1(USART1);

	#include "Util/EEPROM.h"
	#include "Tasks/LAUNCHER_TASKS.h"

	int main(void)
	{
		SystemClock_Config();
		uid.calculateUIDs();
		init_TIM10_Delay();
		Wire3.begin(STM32_MASTER_ADDRESS, 100000);
		Spi2.begin(SPI_SPEED_21MHZ);
		Serial2.begin(9600);
		//HAL_NVIC_EnableIRQ(USART1_IRQn);
		//MX_USART1_UART_Init();
		Serial1.begin(115200);


		//Serial1.begin(115200);

		Serial2.println(MENSAJE_BIENVENIDA);
		Serial2.print("FIRMWARE ONADVENTURE-STM32 VERSION: ");
		Serial2.print(VERSION);
		Serial2.print(" -> ");
		Serial2.println(VERSION_FECHA);
		Serial2.print("Serial Original->");
		Serial2.println(uid.getOriginalUID());
		Serial2.print("Serial Procesada->");
		Serial2.println(uid.getProcessedUID());
		Serial2.println("*************************");

		analogMode_init();
		LAUNCHER_TASK();
	}

#elif defined(STM32F107xC)
	#include "System/f107vc/Initial_Config.h"
	#include "Util/structs.h"
	#include "Tasks/Base_Tasks.h"
	#include "Extensions/Pines.h"
	#include "Extensions/DigitalPins.h"
	#include "Extensions/AnalogPins.h"
	#include "Extensions/Serial.h"
	#include "Extensions/Time.h"
	#include "Extensions/SPI.h"
	#include "Extensions/SSD1306/SSD1306.h"
	#include "Extensions/Wire.h"
	#include "Extensions/Extra_String.h"
	#include "Extensions/UID.h"

	UID uid;
	Wire Wire1(I2C1,MASTER);
	Serial Serial3(USART3);

	#include "Util/EEPROM.h"
	#include "Tasks/LAUNCHER_TASKS.h"

	int main(void){
		SystemClock_Config();
		uid.calculateUIDs();
		init_TIM10_Delay();
		Wire1.begin(STM32_MASTER_ADDRESS, 100000);
		Serial3.begin(921600);

		Serial3.println(MENSAJE_BIENVENIDA);
		Serial3.print("FIRMWARE ONADVENTURE-MINI-STM32 VERSION: ");
		Serial3.print(VERSION);
		Serial3.print(" -> ");
		Serial3.println(VERSION_FECHA);
		Serial3.print("Serial Original->");
		Serial3.println(uid.getOriginalUID());
		Serial3.print("Serial Procesada->");
		Serial3.println(uid.getProcessedUID());
		Serial3.println("*************************");

		analogMode_init();
		LAUNCHER_TASK();
	}
#endif

#endif/* SRC_MAIN_CPP_ */


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
