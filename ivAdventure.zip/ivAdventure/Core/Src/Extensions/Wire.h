/*
 * I2C_Comunication.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_EXTENSIONS_WIRE_H_
#define SRC_EXTENSIONS_WIRE_H_

I2C_HandleTypeDef hi2cEspCommunication;
I2C_HandleTypeDef hi2cEspCommunication2;

typedef struct{
	uint8_t Buffer_raw[256];
	uint8_t Buffer[1024]={'\0'};
	uint32_t position=0;
	uint8_t numBytesToReceive = 1;
	bool bufferAvailable = false;
}I2C_Buffer;

bool receiveMode = false;
bool receiveMode2 = false;

typedef enum{
	MASTER,
	SLAVE,
	SLAVE2
}I2C_MODE_COMMUNICATION;

I2C_Buffer I2C_Buffer_ESP;
I2C_Buffer I2C_Buffer_ESP2;

class Wire{
private:
	I2C_TypeDef* I2C_Selected;
	I2C_MODE_COMMUNICATION I2C_MODE_COM;
	I2C_HandleTypeDef hi2c_Selected;
	I2C_Buffer I2C_Buffer_Selected;
	SEMAPHORE I2C_Semaphore=FREE;

public:
	Wire(I2C_TypeDef* I2C_Selected,I2C_MODE_COMMUNICATION I2C_MODE_COM){
		this->I2C_Selected=I2C_Selected;
		this->I2C_MODE_COM = I2C_MODE_COM;
	}

	I2C_HandleTypeDef* getWire(){
		if(I2C_MODE_COM == MASTER){
			return(&hi2c_Selected);
		}
		if(I2C_MODE_COM == SLAVE){
			return(&hi2cEspCommunication);
		}
		if(I2C_MODE_COM == SLAVE2){
			return(&hi2cEspCommunication2);
		}
		return(0);
	}

	bool begin(uint8_t address, uint32_t clock){
		if(I2C_MODE_COM == MASTER){
			hi2c_Selected.Instance = I2C_Selected;
			hi2c_Selected.Init.ClockSpeed = clock;
			hi2c_Selected.Init.DutyCycle = I2C_DUTYCYCLE_2;
			hi2c_Selected.Init.OwnAddress1 = (address<<1);
			hi2c_Selected.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
			hi2c_Selected.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
			hi2c_Selected.Init.OwnAddress2 = 0;
			hi2c_Selected.Init.GeneralCallMode = I2C_GENERALCALL_ENABLE;
			hi2c_Selected.Init.NoStretchMode = I2C_NOSTRETCH_ENABLE;

			if (HAL_I2C_Init(&hi2c_Selected) != HAL_OK){
				Error_Handler();
				return(false);
			}
			return(true);
		}
		if(I2C_MODE_COM == SLAVE){
			hi2cEspCommunication.Instance = I2C_Selected;
			hi2cEspCommunication.Init.ClockSpeed = clock;
			hi2cEspCommunication.Init.DutyCycle = I2C_DUTYCYCLE_2;
			hi2cEspCommunication.Init.OwnAddress1 = (address<<1);
			hi2cEspCommunication.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
			hi2cEspCommunication.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
			hi2cEspCommunication.Init.OwnAddress2 = 0;
			hi2cEspCommunication.Init.GeneralCallMode = I2C_GENERALCALL_ENABLE;
			hi2cEspCommunication.Init.NoStretchMode = I2C_NOSTRETCH_ENABLE;
			#if defined(STM32F411xE)
				__HAL_RCC_DMA1_CLK_ENABLE();
				HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 0, 0);
				HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn);
				HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 0, 0);
				HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
			#endif
			if (HAL_I2C_Init(&hi2cEspCommunication) != HAL_OK){
				Error_Handler();
				return(false);
			}
			#if defined(STM32F411xE)
				if(HAL_I2C_Slave_Receive_DMA(&hi2cEspCommunication, I2C_Buffer_ESP.Buffer_raw, I2C_Buffer_ESP.numBytesToReceive) != HAL_OK){
					return(false);
				}
			#endif
			return(true);
		}
		if(I2C_MODE_COM == SLAVE2){
			hi2cEspCommunication2.Instance = I2C_Selected;
			hi2cEspCommunication2.Init.ClockSpeed = clock;
			hi2cEspCommunication2.Init.DutyCycle = I2C_DUTYCYCLE_2;
			hi2cEspCommunication2.Init.OwnAddress1 = (address<<1);
			hi2cEspCommunication2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
			hi2cEspCommunication2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
			hi2cEspCommunication2.Init.OwnAddress2 = 0;
			hi2cEspCommunication2.Init.GeneralCallMode = I2C_GENERALCALL_ENABLE;
			hi2cEspCommunication2.Init.NoStretchMode = I2C_NOSTRETCH_ENABLE;
			#if defined(STM32F411xE)
				__HAL_RCC_DMA1_CLK_ENABLE();
				HAL_NVIC_SetPriority(DMA1_Stream2_IRQn, 0, 0);
				HAL_NVIC_EnableIRQ(DMA1_Stream2_IRQn);
				HAL_NVIC_SetPriority(DMA1_Stream7_IRQn, 0, 0);
				HAL_NVIC_EnableIRQ(DMA1_Stream7_IRQn);
			#endif
			if (HAL_I2C_Init(&hi2cEspCommunication2) != HAL_OK){
				Error_Handler();
				return(false);
			}
			#if defined(STM32F411xE)
				if(HAL_I2C_Slave_Receive_DMA(&hi2cEspCommunication2, I2C_Buffer_ESP2.Buffer_raw, I2C_Buffer_ESP2.numBytesToReceive) != HAL_OK){
					return(false);
				}
			#endif
			return(true);
		}

		return(false);
	}

	void setBytesToReceive(uint8_t numBytesToReceive){ //only slave
		if(I2C_MODE_COM == SLAVE){
			I2C_Buffer_ESP.numBytesToReceive = numBytesToReceive;
		}
		if(I2C_MODE_COM == SLAVE2){
			I2C_Buffer_ESP2.numBytesToReceive = numBytesToReceive;
		}
	}

	uint32_t available(){//only slave
		if(I2C_MODE_COM == SLAVE){
			return(I2C_Buffer_ESP.position);
		}
		if(I2C_MODE_COM == SLAVE2){
			return(I2C_Buffer_ESP2.position);
		}
	}

	uint8_t read(){//only slave
		if(I2C_MODE_COM == SLAVE){
			I2C_Buffer_ESP.position--;
			char data=I2C_Buffer_ESP.Buffer[0];
			memmove(I2C_Buffer_ESP.Buffer, &(I2C_Buffer_ESP.Buffer[1]), sizeof(I2C_Buffer_ESP.Buffer));
			I2C_Buffer_ESP.Buffer[I2C_Buffer_ESP.position]='\0';
			return(data);
		}
		if(I2C_MODE_COM == SLAVE2){
			I2C_Buffer_ESP2.position--;
			char data=I2C_Buffer_ESP2.Buffer[0];
			memmove(I2C_Buffer_ESP2.Buffer, &(I2C_Buffer_ESP2.Buffer[1]), sizeof(I2C_Buffer_ESP2.Buffer));
			I2C_Buffer_ESP2.Buffer[I2C_Buffer_ESP2.position]='\0';
			return(data);
		}
	}

	bool write(char* data){//only slave
		if(I2C_MODE_COM == SLAVE){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication, (uint8_t*)data, strlen(data)) == HAL_OK){
				return(true);
			}
		}
		if(I2C_MODE_COM == SLAVE2){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication2, (uint8_t*)data, strlen(data)) == HAL_OK){
				return(true);
			}
		}

		return(false);
	}
	bool write(char* data, uint16_t size){//only slave
		if(I2C_MODE_COM == SLAVE){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication, (uint8_t*)data, size) == HAL_OK){
				return(true);
			}
		}
		if(I2C_MODE_COM == SLAVE2){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication2, (uint8_t*)data, size) == HAL_OK){
				return(true);
			}
		}

		return(false);
	}
	bool write(uint8_t* data, uint8_t size){//only slave
		if(I2C_MODE_COM == SLAVE){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication, data, size) == HAL_OK){
				return(true);
			}
		}
		if(I2C_MODE_COM == SLAVE2){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication2, data, size) == HAL_OK){
				return(true);
			}
		}

		return(false);
	}
	bool write(uint8_t data_){//only slave
		uint8_t data[2];
		data[0]=data_;

		if(I2C_MODE_COM == SLAVE){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication, data, 1) == HAL_OK){
				return(true);
			}
		}
		if(I2C_MODE_COM == SLAVE2){
			if(HAL_I2C_Slave_Transmit_DMA(&hi2cEspCommunication2, data, 1) == HAL_OK){
				return(true);
			}
		}

		return(false);
	}

	SEMAPHORE getSemaphore(){
		return(I2C_Semaphore);
	}

	void setSemaphore(SEMAPHORE semaphore_){
		I2C_Semaphore=semaphore_;
	}
	void waitAndTakeSemaphore(){
		while(I2C_Semaphore==BUSY) osDelay(1);
		I2C_Semaphore=BUSY;
	}
	bool isReceiveModeAvailable(){
		if(I2C_MODE_COM == SLAVE){
			return(receiveMode);
		}
		if(I2C_MODE_COM == SLAVE2){
			return(receiveMode2);
		}
	}
	void EnableReceiveMode(){
		if(I2C_MODE_COM == SLAVE){
			HAL_I2C_Slave_Receive_DMA(&hi2cEspCommunication, I2C_Buffer_ESP.Buffer_raw, I2C_Buffer_ESP.numBytesToReceive);
			receiveMode = false;
		}
		if(I2C_MODE_COM == SLAVE2){
			HAL_I2C_Slave_Receive_DMA(&hi2cEspCommunication2, I2C_Buffer_ESP2.Buffer_raw, I2C_Buffer_ESP2.numBytesToReceive);
			receiveMode2 = false;
		}

	}
	bool isDataReceived(){
		if(I2C_MODE_COM == SLAVE){
			return(I2C_Buffer_ESP.bufferAvailable);
		}
		if(I2C_MODE_COM == SLAVE2){
			return(I2C_Buffer_ESP2.bufferAvailable);
		}
	}
	void refresh(){
		if(I2C_MODE_COM == SLAVE){
			I2C_Buffer_ESP.bufferAvailable = false;
			for(int i=0;i<I2C_Buffer_ESP.numBytesToReceive;i++){
				I2C_Buffer_ESP.Buffer[I2C_Buffer_ESP.position]=I2C_Buffer_ESP.Buffer_raw[i];
				I2C_Buffer_ESP.position++;
			}
		}
		if(I2C_MODE_COM == SLAVE2){
			I2C_Buffer_ESP2.bufferAvailable = false;
			for(int i=0;i<I2C_Buffer_ESP2.numBytesToReceive;i++){
				I2C_Buffer_ESP2.Buffer[I2C_Buffer_ESP2.position]=I2C_Buffer_ESP2.Buffer_raw[i];
				I2C_Buffer_ESP2.position++;
			}
		}
	}

};

void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *hi2c){//I2C1
#if defined(STM32F411xE)
	if(hi2c->Instance==I2C1){
		I2C_Buffer_ESP.bufferAvailable = true;
	}
	if(hi2c->Instance==I2C2){
		I2C_Buffer_ESP2.bufferAvailable = true;
	}
#endif
}

void HAL_I2C_SlaveTxCpltCallback(I2C_HandleTypeDef *hi2c){
#if defined(STM32F411xE)
	if(hi2c->Instance==I2C1){
		receiveMode = true;
		//HAL_I2C_Slave_Receive_DMA(hi2c, I2C_Buffer_ESP.Buffer_raw, I2C_Buffer_ESP.numBytesToReceive);
	}
	if(hi2c->Instance==I2C2){
		receiveMode2 = true;
		//HAL_I2C_Slave_Receive_DMA(hi2c, I2C_Buffer_ESP.Buffer_raw, I2C_Buffer_ESP.numBytesToReceive);
	}
#endif
}

#endif /* SRC_EXTENSIONS_WIRE_H_ */
