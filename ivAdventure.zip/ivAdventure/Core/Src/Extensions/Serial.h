/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : Serial.h
*	@funcion    : Librería dedicada a las comunicaciones Seriales.
*				  Incluye DMA y funciones de sobreescritura muy parecidas a las
*				  utilizadas en la plataforma de Arduino
*/

#ifndef SRC_CONFIG_PINES_SERIAL_H_
#define SRC_CONFIG_PINES_SERIAL_H_

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#ifdef create_task3
	#if defined(STM32F411xE)
		#include "../Extensions/Modbus/Modbus.h"
	#endif
#endif

typedef enum{
	DEC = 0,
	BIN,
	HEX,
	OCT
}Base;

typedef struct{
	uint8_t Buffer_raw[1];
	uint8_t Buffer[1024]={'\0'};
	uint32_t position=0;
}UART_Buffer;

UART_Buffer UART1_Buffer;
UART_Buffer UART2_Buffer;
UART_Buffer UART6_Buffer;

class Serial {
private:
	USART_TypeDef * uartUsed;
	UART_HandleTypeDef huartI;
	SEMAPHORE Serial_Semaphore=FREE;
public:
	Serial(USART_TypeDef * uart){
		uartUsed=uart;
	}
	bool begin(int BaudRate){
		huartI.Instance = uartUsed;
		huartI.Init.BaudRate = BaudRate;
		huartI.Init.WordLength = UART_WORDLENGTH_8B;
		huartI.Init.StopBits = UART_STOPBITS_1;
		huartI.Init.Parity = UART_PARITY_NONE;
		huartI.Init.Mode = UART_MODE_TX_RX;
		huartI.Init.HwFlowCtl = UART_HWCONTROL_NONE;
		huartI.Init.OverSampling = UART_OVERSAMPLING_16;

		#if defined(STM32F411xE)
		if(huartI.Instance==USART1){
			__HAL_RCC_DMA2_CLK_ENABLE();
			HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, 5, 0);//5,0
			HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);
		}

		if(huartI.Instance==USART6){
			__HAL_RCC_DMA2_CLK_ENABLE();
			HAL_NVIC_SetPriority(DMA2_Stream1_IRQn, 0, 0);
			HAL_NVIC_EnableIRQ(DMA2_Stream1_IRQn);
		}
		if (HAL_UART_Init(&huartI) != HAL_OK){
			return(false);
		}

		if(huartI.Instance==USART1){
			HAL_UART_Receive_DMA(&huartI, UART1_Buffer.Buffer_raw, 1);
		}
		if(huartI.Instance==USART6){
			HAL_UART_Receive_DMA(&huartI, UART6_Buffer.Buffer_raw, 1);
		}
		#endif

	#if defined(STM32F107xC)
		if(huartI.Instance==USART1){
			__HAL_RCC_DMA1_CLK_ENABLE();
			HAL_NVIC_SetPriority(DMA1_Channel5_IRQn, 5, 0);//5,0
			HAL_NVIC_EnableIRQ(DMA1_Channel5_IRQn);
		}
		if(huartI.Instance==USART2){
			__HAL_RCC_DMA1_CLK_ENABLE();
			HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 5, 0);//5,0
			HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);
		}
		if (HAL_UART_Init(&huartI) != HAL_OK){
			return(false);
		}
		if(huartI.Instance==USART1){
			HAL_UART_Receive_DMA(&huartI, UART1_Buffer.Buffer_raw, 1);
		}
		if(huartI.Instance==USART2){
			HAL_UART_Receive_DMA(&huartI, UART2_Buffer.Buffer_raw, 1);
		}
	#endif

		return(true);
	}
	void print(char* message){
		HAL_UART_Transmit(&huartI, (uint8_t*)message, strlen(message), 100);
	}
	void print(char* message, uint16_t size){
		HAL_UART_Transmit(&huartI, (uint8_t*)message, size, 10);
	}
	void printLonger(char* message){
		HAL_UART_Transmit(&huartI, (uint8_t*)message, (uint16_t)strlen(message), 1);
	}
	void print(char message){
		char data[2];
		data[0]=message;
		data[1]='\0';
		print(data);
	}
	void print(int number){
		char buffer[100];
		snprintf(buffer, 100, "%d", number);
		print(buffer);
	}
	void print(long number){
		char buffer[100];
		snprintf(buffer, 100, "%ld", number);
		print(buffer);
	}
	void print(float number){
		char buffer[100];
		sprintf(buffer,"%0.2f", number); // @suppress("Float formatting support")
		print(buffer);
	}
	void print(float number,int decimals){
		char buffer[100];
		char buf1[10]="%0.",buf2[10];
		sprintf(buf2,"%d", decimals);
		strcat(buf1,buf2);
		strcat(buf1,"f");

		sprintf(buffer,buf1, number); // @suppress("Float formatting support")
		print(buffer);
	}
	void print(double number){
		char buffer[100];
		sprintf(buffer,"%lf", number); // @suppress("Float formatting support")
		print(buffer);
	}
	void print(int number,Base base){
		char buffer[100];
		if(base==HEX){
			snprintf(buffer, 100, "%x", number);
		}
		else{
			snprintf(buffer, 100, "%d", number);
		}
		print(buffer);
	}
	void println(char* message){
		print(message);
		message = "\r\n";
		print(message);
	}
	void println(char message){
		char data[2];
		data[0]=message;
		data[1]='\0';
		println(data);
	}
	void println(int number){
		char buffer[100];
		snprintf(buffer, 100, "%d", number);
		println(buffer);
	}
	void println(uint32_t number){
		char buffer[100];
		snprintf(buffer, 100, "%lu", number);
		println(buffer);
	}
	void println(uint32_t number, Base base){
		char buffer[100];
		if(base==HEX){
			snprintf(buffer, 100, "%x", number);
		}
		else if(base==BIN){
			snprintf(buffer, 100, "%b", number);
		}
		else{
			snprintf(buffer, 100, "%lu", number);
		}
		println(buffer);
	}
	void println(long number){
		char buffer[100];
		snprintf(buffer, 100, "%ld", number);
		println(buffer);
	}
	void println(float number){
		char buffer[100];
		sprintf(buffer,"%0.2f", number);
		println(buffer);
	}
	void println(float number,int decimals){
		char buffer[100];
		char buf1[10]="%0.",buf2[10];
		sprintf(buf2,"%d", decimals);
		strcat(buf1,buf2);
		strcat(buf1,"f");

		sprintf(buffer,buf1, number);
		println(buffer);
	}
	void println(double number){
		print(number);
		println("");
	}
	uint32_t available(){ // implementado para uart1 y uart6 respectivamente

	#if defined(STM32F411xE)
		if(huartI.Instance==USART1){
			return(UART1_Buffer.position);
		}
		if(huartI.Instance==USART6){
			return(UART6_Buffer.position);
		}
	#elif defined(STM32F107xC)
		if(huartI.Instance==USART1){
			return(UART1_Buffer.position);
		}
		if(huartI.Instance==USART2){
			return(UART2_Buffer.position);
		}
	#endif
		return(0);
	}
	uint8_t read(){ // implementado para uart1 y uart6 respectivamente
	#if defined(STM32F411xE)
		if(huartI.Instance==USART1){
			UART1_Buffer.position--;
			char data=UART1_Buffer.Buffer[0];
			memmove(UART1_Buffer.Buffer, &(UART1_Buffer.Buffer[1]), sizeof(UART1_Buffer.Buffer));
			UART1_Buffer.Buffer[UART1_Buffer.position]='\0';
			return(data);
		}
		if(huartI.Instance==USART6){
			UART6_Buffer.position--;
			char data=UART6_Buffer.Buffer[0];
			memmove(UART6_Buffer.Buffer, &(UART6_Buffer.Buffer[1]), sizeof(UART6_Buffer.Buffer));
			UART6_Buffer.Buffer[UART6_Buffer.position]='\0';
			return(data);
		}
	#endif
	#if defined(STM32F107xC)
		if(huartI.Instance==USART1){
			UART1_Buffer.position--;
			char data=UART1_Buffer.Buffer[0];
			memmove(UART1_Buffer.Buffer, &(UART1_Buffer.Buffer[1]), sizeof(UART1_Buffer.Buffer));
			UART1_Buffer.Buffer[UART1_Buffer.position]='\0';
			return(data);
		}
		if(huartI.Instance==USART2){
			UART2_Buffer.position--;
			char data=UART2_Buffer.Buffer[0];
			memmove(UART2_Buffer.Buffer, &(UART2_Buffer.Buffer[1]), sizeof(UART2_Buffer.Buffer));
			UART2_Buffer.Buffer[UART2_Buffer.position]='\0';
			return(data);
		}
	#endif
		return(0);
	}
	UART_HandleTypeDef* getSerial(){
		return(&huartI);
	}
	SEMAPHORE getSemaphore(){
		return(Serial_Semaphore);
	}
	void setSemaphore(SEMAPHORE semaphore_){
		Serial_Semaphore=semaphore_;
	}
	void waitAndTakeSemaphore(){
		while(Serial_Semaphore==BUSY) osDelay(1);
		Serial_Semaphore=BUSY;
	}
};

	#if defined(STM32F411xE)
		UART_HandleTypeDef huart6;

		void MX_USART6_UART_Init(void)
		{
		  huart6.Instance = USART6;
		  huart6.Init.BaudRate = 115200;
		  huart6.Init.WordLength = UART_WORDLENGTH_8B;
		  huart6.Init.StopBits = UART_STOPBITS_1;
		  huart6.Init.Parity = UART_PARITY_NONE;
		  huart6.Init.Mode = UART_MODE_TX_RX;
		  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
		  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
		  if (HAL_UART_Init(&huart6) != HAL_OK)
		  {
			Error_Handler();
		  }
		}
	#endif
#endif /* SRC_CONFIG_PINES_SERIAL_H_ */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){//implementado para uart1 de momento
#if defined(STM32F411xE)
	if(huart->Instance==USART1){
		HAL_UART_Receive_DMA(huart, UART1_Buffer.Buffer_raw, 1);
		UART1_Buffer.Buffer[UART1_Buffer.position]=UART1_Buffer.Buffer_raw[0];
		UART1_Buffer.position++;
	}
	if(huart->Instance==USART6){
		HAL_UART_Receive_DMA(huart, UART6_Buffer.Buffer_raw, 1);
		UART6_Buffer.Buffer[UART6_Buffer.position]=UART6_Buffer.Buffer_raw[0];
		UART6_Buffer.position++;
	}
#endif
#if defined(STM32F107xC)
	if(huart->Instance==USART1){
		HAL_UART_Receive_DMA(huart, UART1_Buffer.Buffer_raw, 1);
		UART1_Buffer.Buffer[UART1_Buffer.position]=UART1_Buffer.Buffer_raw[0];
		UART1_Buffer.position++;
	}
	if(huart->Instance==USART2){
		HAL_UART_Receive_DMA(huart, UART2_Buffer.Buffer_raw, 1);
		UART2_Buffer.Buffer[UART2_Buffer.position]=UART2_Buffer.Buffer_raw[0];
		UART2_Buffer.position++;
	}
#endif
#if defined(STM32F411xE)
	#ifdef create_task3
		BaseType_t xHigherPriorityTaskWoken = pdFALSE;
		int i;

		for (i = 0; i < numberHandlers; i++ )
		{
			if (mHandlers[i]->port == huart  )
			{
				xQueueSendToBackFromISR( (QueueHandle_t)mHandlers[i]->QueueModbusHandle, &mHandlers[i]->dataRX, pdFALSE);
				HAL_UART_Receive_IT(mHandlers[i]->port, &mHandlers[i]->dataRX, 1);
				xTimerResetFromISR(mHandlers[i]->xTimerT35, &xHigherPriorityTaskWoken);
				break;
			}
		}
	#endif
#endif
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
#if defined(STM32F411xE)
	#ifdef create_task3
		BaseType_t xHigherPriorityTaskWoken = pdFALSE;
		int i;
		for (i = 0; i < numberHandlers; i++ )
		{
			if (mHandlers[i]->port == huart )
			{
				xTaskNotifyFromISR((TaskHandle_t)mHandlers[i]->myTaskModbusAHandle, 0, eNoAction, &xHigherPriorityTaskWoken);
				break;
			}
		}
	#endif
#endif

}
