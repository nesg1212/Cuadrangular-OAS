/*
 * 24LCxxx.h
 *
 *  Created on: 24 ago. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_EEPROM_24LCXXX_H_
#define SRC_EXTENSIONS_EEPROM_24LCXXX_H_

#define MIN_READ_TIME 1 //ms
#define MIN_WRITE_TIME 10 //ms

class EEPROM_24LCxxx{
private:
	uint8_t Address;
	I2C_HandleTypeDef *hi2cI;
public:
	EEPROM_24LCxxx(){}
	bool init(I2C_HandleTypeDef *hi2c, uint8_t Address_){
		Address=Address_ << 1;
		hi2cI = hi2c;

		if(!HAL_I2C_IsDeviceReady(hi2cI, Address, 1, 10) == HAL_OK){
				return(false);
		}
		return(true);
	}
	void write(uint16_t Memorycell, uint8_t data_) {//Metodo para 1 byte ->0 - 255
		uint8_t I2CBuff[3];

		I2CBuff[0]=Memorycell >> 8;
		I2CBuff[1]=Memorycell & 0xFF;
		I2CBuff[2]=data_;

		HAL_I2C_Master_Transmit(hi2cI, Address, I2CBuff, 3, 10);
		HAL_Delay(MIN_WRITE_TIME);
	}
	void writeBytes(uint16_t Memorycell, uint32_t data_, uint8_t numBytes){
		for(int i=0;i<numBytes;i++){
			write(Memorycell+i,(uint8_t)(data_>>(8*(numBytes-i-1))&0xFF));
		}
	}
	void write_float(uint16_t Memorycell, float data_){
		uint8_t dataLeft=(uint8_t)data_;
		uint8_t dataRight=(uint8_t)((float)(data_-dataLeft)*100);
		write(Memorycell,dataLeft);
		write(Memorycell+1, dataRight);
	}
	uint8_t read(uint32_t Memorycell){//Metodo para 1 byte ->0 - 255
		uint8_t data[1];
		uint8_t I2CBuff[2];

		I2CBuff[0]=Memorycell >> 8;
		I2CBuff[1]=Memorycell & 0xFF;

		HAL_I2C_Master_Transmit(hi2cI, Address, I2CBuff, 2, 10);
		//HAL_Delay(MIN_READ_TIME);
		if(HAL_I2C_Master_Receive(hi2cI, Address, data, 1, 10)==HAL_OK){
			//HAL_Delay(MIN_READ_TIME);
			return(data[0]);
		}
		return(0xFF);
	}
	uint32_t readBytes(uint32_t Memorycell, uint8_t numBytes){
		uint32_t response=0;
		for(int i=0;i<numBytes;i++){
			uint8_t temp = read(Memorycell+i);
			response |= temp<<(8*(numBytes-i-1));
		}
		return(response);
	}
	uint16_t read_16bits(uint32_t Memorycell){//lectura de 16 bits -> 2 celdas 0-65535
		uint16_t data;
		data=(uint16_t)(read(Memorycell)<<8)&0xFF00;
		data+=(uint16_t)read(Memorycell+1)&0xFF;
		return(data);
	}
	float read_float(uint32_t Memorycell){ //lectura float -> 2 celdas, 0.00 - 255.255 .. se debe utilizar solo 2 decimas
		float data;
		data=read(Memorycell);
		data+=(float)read(Memorycell+1)/100.0;
		return(data);
	}

};


#endif /* SRC_EXTENSIONS_EEPROM_24LCXXX_H_ */




