/*
 * Delay.h
 *
 *  Created on: 2 ago. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_TIME_H_
#define SRC_EXTENSIONS_TIME_H_

#include "main.h"
#include <stdint.h>

TIM_HandleTypeDef htim10;

uint16_t millisCountFlag=0;
uint32_t timeElapsed_ms=0;
uint32_t timeElapsed_us=0;

void init_TIM10_Delay(){
#if defined(STM32F411xE)
	htim10.Instance = TIM10;
#elif defined(STM32F107xC)
	htim10.Instance = TIM1;
#endif
	htim10.Init.Prescaler = 84;
	htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim10.Init.Period = 9;
	htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
	{
		Error_Handler();
	}
	HAL_TIM_Base_Start_IT(&htim10);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	#if defined(STM32F411xE)
	if(htim->Instance == TIM10){
		timeElapsed_us+=10;
		millisCountFlag+=10;
		if(millisCountFlag>=1000) {
			timeElapsed_ms++;
			millisCountFlag=0;
		}
		if(timeElapsed_us>=4294967290 || timeElapsed_us<0) timeElapsed_us=0;
		if(timeElapsed_ms>=4294967290 || timeElapsed_ms<0) timeElapsed_ms=0;
	}
	if(htim->Instance == TIM9){
	    HAL_IncTick();
	}
#elif defined(STM32F107xC)

#endif
}

uint32_t millis(){
	return(timeElapsed_ms);
}

uint32_t micros(){
	return(timeElapsed_us);
}

void delayMicroseconds(uint32_t delayTime){
	uint32_t freezeTime=micros();
	uint32_t currentTime=micros();
	uint32_t extraTime=0;
	if((currentTime+delayTime) >= 4294967290){
		extraTime = delayTime - (4294967290-currentTime);
	}
	while(1){
		currentTime=micros();
		if((currentTime-freezeTime)<0){
			delayTime=extraTime;
			freezeTime=currentTime;
		}
		if((currentTime-freezeTime)>=delayTime){
			break;
		}
	}
}

void delay(uint32_t delayTime){//no usar a no ser que sea estrictamente necesario!.
	uint32_t freezeTime=millis();
	uint32_t currentTime=micros();
	uint32_t extraTime=0;
	if((currentTime+delayTime) >= 4294967290){
		extraTime = delayTime - (4294967290-currentTime);
	}
	while(1){
		currentTime=micros();
		if((currentTime-freezeTime)<0){
			delayTime=extraTime;
			freezeTime=currentTime;
		}
		if((currentTime-freezeTime)>=delayTime){
			break;
		}
	}
}


#endif /* SRC_EXTENSIONS_TIME_H_ */
