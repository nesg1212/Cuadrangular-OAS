/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : SX1278_hw.h
*	@funcion    : Author Wojciech Domski
*				  Modificada y adaptada por ACTIONTRACKER© para el uso de LORA generico SX1278 y la libreria SX1278.h
*/

#ifndef __SX1278_HW_HEADER
#define __SX1278_HW_HEADER

#include <stdint.h>
#include <string.h>

typedef struct {
	int pin;
	GPIO_TypeDef *port;
} SX1278_hw_dio_t;

typedef struct {
	SX1278_hw_dio_t reset;
	SX1278_hw_dio_t dio0;
	SX1278_hw_dio_t nss;
	SPI_HandleTypeDef *spi;
} SX1278_hw_t;

/**
 * \brief ms delay
 * Milisecond delay.
 * \param[in]   msec 		Number of milliseconds to wait
 */
__weak void SX1278_hw_DelayMs(uint32_t msec) {
	osDelay(msec);
}

/**
 * \brief Control NSS
 * Clears and sets NSS according to passed value.
 * \param[in]   hw 		Pointer to hardware structure.
 * \param[in]   value   1 sets NSS high, other value sets NSS low.
 */
__weak void SX1278_hw_SetNSS(SX1278_hw_t *hw, int value) {
	HAL_GPIO_WritePin(hw->nss.port, hw->nss.pin,
	(value == 1) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/**
 * \brief Initialize hardware layer
 * Clears NSS and resets LoRa module.
 * \param[in]   hw 		Pointer to hardware structure
 */
__weak void SX1278_hw_init(SX1278_hw_t *hw) {
	SX1278_hw_SetNSS(hw, 1);
	HAL_GPIO_WritePin(hw->reset.port, hw->reset.pin, GPIO_PIN_SET);
}

/**
 * \brief Resets LoRa module
 * Resets LoRa module.
 * \param[in]   hw 		Pointer to hardware structure
 */
__weak void SX1278_hw_Reset(SX1278_hw_t *hw) {
	SX1278_hw_SetNSS(hw, 1);
	HAL_GPIO_WritePin(hw->reset.port, hw->reset.pin, GPIO_PIN_RESET);
	SX1278_hw_DelayMs(1);
	HAL_GPIO_WritePin(hw->reset.port, hw->reset.pin, GPIO_PIN_SET);
	SX1278_hw_DelayMs(100);
}
/**
 * \brief Send command via SPI.
 * Send single byte via SPI interface.
 * \param[in]   hw 		Pointer to hardware structure
 * \param[in]   cmd		Command
 */
__weak void SX1278_hw_SPICommand(SX1278_hw_t *hw, uint8_t cmd) {
	SX1278_hw_SetNSS(hw, 0);
	HAL_SPI_Transmit(hw->spi, &cmd, 1, 1000);
	while (HAL_SPI_GetState(hw->spi) != HAL_SPI_STATE_READY);
}
/**
 * \brief Reads data via SPI
 * Reads data via SPI interface.
 * \param[in]   hw 		Pointer to hardware structure
 * \return				Read value
 */
__weak uint8_t SX1278_hw_SPIReadByte(SX1278_hw_t *hw) {
	uint8_t txByte = 0x00;
	uint8_t rxByte = 0x00;

	SX1278_hw_SetNSS(hw, 0);
	HAL_SPI_TransmitReceive(hw->spi, &txByte, &rxByte, 1, 1000);
	while (HAL_SPI_GetState(hw->spi) != HAL_SPI_STATE_READY);

	return rxByte;
}

/**
 * \brief Reads DIO0 state
 * Reads LoRa DIO0 state using GPIO.
 * \param[in]   hw 		Pointer to hardware structure
 * \return				0 if DIO0 low, 1 if DIO high
 */
__weak int SX1278_hw_GetDIO0(SX1278_hw_t *hw) {
	return (HAL_GPIO_ReadPin(hw->dio0.port, hw->dio0.pin) == GPIO_PIN_SET);
}

#endif

