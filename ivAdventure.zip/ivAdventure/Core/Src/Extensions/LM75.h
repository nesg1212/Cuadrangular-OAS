/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : LM75.h
*	@funcion    : Librería utilizada para la lectura de sensores de temperatura LM75
*				  A través del bus I2C
*/
#ifndef SRC_EXTENSIONS_LM75_H_
#define SRC_EXTENSIONS_LM75_H_

#include "main.h"

//#define LM75_11BIT
#define LM75_9BIT
#define	LM75_TEMPERATURE		0x00
#define LM75_CONFIGURATION		0x01
#define LM75_THYST				0x02
#define LM75_TOS				0x03

#define ABS(x)   ((x) > 0 ? (x) : -(x))	

class LM75{

private:
	uint8_t Address;
	I2C_HandleTypeDef *hi2cI;
public:
	LM75(){}

	bool init(I2C_HandleTypeDef *hi2c, uint8_t Address_){
		Address=Address_ << 1;
		hi2cI = hi2c;

		if(!HAL_I2C_IsDeviceReady(hi2cI, Address, 1, 10) == HAL_OK){
				return(false);
		}
		return(true);
	}

	float temperature_9Bit_ReadReg( uint8_t reg ){
		uint16_t value;
		HAL_I2C_Master_Receive( hi2cI, Address, (uint8_t*)&value, 2, 500 );

		value = ((( value >> 8 ) | ( value << 8 )) >> 7) & 0x01FF;

		if( value & 0x0100 ){
			value = (0x01FE ^ value) + 2;
			return (float)( value * (-0.5f) );
		}
		else{
			return (float)( value * 0.5f );
		}
	}
	float temperature_11Bit_ReadReg( uint8_t reg ){
		HAL_I2C_Master_Transmit( hi2cI, Address, &reg, 1, 500 );

		uint16_t value;
		HAL_I2C_Master_Receive( hi2cI, Address, (uint8_t*)&value, 2, 500 );

		value = ((( value >> 8 ) | ( value << 8 )) >> 5 ) & 0x07FF;

		if(value & 0x04FF){
			value = (0x07FF ^ value) + 1;
			return  (float)(value * ( -0.125f ) );
		}
		else{
			return  (float)(value * 0.125f );
		}
	}
	void temperatureWriteReg( uint8_t reg, float Temperature ){//static
		int8_t value[3];
		value[0] = reg;
		value[1] = Temperature;

		if( ( ABS(Temperature) - ABS(value[1]) ) >= 0.5f ){
			value[2] = 0x80;
		}
		else{
			value[2] = 0x00;
		}
		HAL_I2C_Master_Transmit( hi2cI, Address, (uint8_t*)value, 3, 500 );
	}
	uint8_t readConfig(void){//static
		uint8_t reg = LM75_CONFIGURATION;
		HAL_I2C_Master_Transmit( hi2cI, Address, &reg, 1, 500 );
		//------------------------------------------------

		uint8_t conf;
		HAL_I2C_Master_Receive( hi2cI, Address, &conf, 1, 500 );

		return conf;
	}
	void sleepMode(bool mode){
		uint8_t buff[2];
		buff[0] = LM75_CONFIGURATION;
		buff[1] = readConfig();

		if( mode ){
			buff[1] = buff[1] | 0x01;
		}
		else{
			buff[1] = buff[1] & 0xFE;
		}

		HAL_I2C_Master_Transmit( hi2cI, Address, buff, 2, 500 );
	}
	void comparatorOrInterruptMode(uint8_t mode){
		uint8_t buff[2];
		buff[0] = LM75_CONFIGURATION;
		buff[1] = readConfig();

		if( mode ){
			buff[1] = buff[1] | 0x02;
		}
		else{
			buff[1] = buff[1] & 0xFD;
		}

		HAL_I2C_Master_Transmit( hi2cI, Address, buff, 2, 500 );
	}
	void levelOsMode(uint8_t mode){
		uint8_t buff[2];
		buff[0] = LM75_CONFIGURATION;
		buff[1] = readConfig();

		if( mode ){
			buff[1] = buff[1] | 0x04;
		}
		else{
			buff[1] = buff[1] & 0xFB;
		}

		HAL_I2C_Master_Transmit( hi2cI, Address, buff, 2, 500 );
	}
	void faultQueueMode(uint8_t mode){
		uint8_t buff[2];
		buff[0] = LM75_CONFIGURATION;
		buff[1] = readConfig();

		if( mode == 1 ){
			buff[1] = buff[1] & 0xE7;
		}
		else if( mode == 2 ){
			buff[1] = (buff[1] & 0xE7) | 0x08;
		}
		else if( mode == 4 ){
			buff[1] = (buff[1] & 0xE7) | 0x10;
		}
		else if( mode == 6 ){
			buff[1] = (buff[1] & 0xE7) | 0x18;
		}
		else{
			buff[1] = buff[1] & 0xE7;
		}

		HAL_I2C_Master_Transmit( hi2cI, Address, buff, 2, 500 );
	}
	float temperatureRead(void){
		#ifdef LM75_11BIT
			return temperature_11Bit_ReadReg( LM75_TEMPERATURE );
		#endif

		#ifdef LM75_9BIT
			return temperature_9Bit_ReadReg( LM75_TEMPERATURE );
		#endif
	}
	float THYST_Read(void){
		return temperature_9Bit_ReadReg( LM75_THYST );
	}

	float TOS_Read(void){
		return temperature_9Bit_ReadReg( LM75_TOS );
	}

	void THYST_Write(float TemperatureTHYST){
		temperatureWriteReg( LM75_THYST, TemperatureTHYST );
	}

	void TOS_Write(float TemperatureTOS){
		temperatureWriteReg( LM75_TOS, TemperatureTOS );
	}
};
#endif	/*	_LM75_H */

/************************ (C) COPYRIGHT ACTIONTRACKER *****END OF FILE****/
