/*
 * InputCapture.h
 *
 *  Created on: Aug 9, 2021
 *      Author: Ing.JoseBenitez
 */

#ifndef SRC_EXTENSIONS_INPUTCAPTURE_H_
#define SRC_EXTENSIONS_INPUTCAPTURE_H_

typedef struct{
	uint32_t IC_Value1 = 0;
	uint32_t IC_Value2 = 0;
	uint32_t Difference = 0;
	uint32_t Frequency = 0;
	uint8_t Is_First_Captured = 0;
	bool flag = false;
}ValueInputCapture;

ValueInputCapture IC[4];

class InputCapture{
private:
	TIM_TypeDef * TimUsed;
	TIM_IC_InitTypeDef sConfigIC = {0};
public:
	InputCapture(TIM_TypeDef* TIM){
		TimUsed=TIM;
	}
	bool init(){
		TIM_MasterConfigTypeDef sMasterConfig = {0};

		htim2.Instance = TimUsed;
		htim2.Init.Prescaler = 0;
		htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
		htim2.Init.Period = 4294967295;
		htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
		htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
		if (HAL_TIM_IC_Init(&htim2) != HAL_OK){
			Error_Handler();
			return(false);
		}
		sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
		sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
		if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK){
			Error_Handler();
			return(false);
		}
		sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
		sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
		sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
		sConfigIC.ICFilter = 0;

		return(true);
	}
	bool begin(uint32_t channel){
		if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, channel) != HAL_OK){
			Error_Handler();
			return(false);
		}

		return(true);
	}

	void startTimers(uint32_t channel){
		HAL_TIM_IC_Start_IT(&htim2, channel);
	}

	uint32_t getFrequency(uint32_t channel){
		if(channel == TIM_CHANNEL_1 && IC[0].flag){
			IC[0].flag = false;
			return(IC[0].Frequency);
		}
		if(channel == TIM_CHANNEL_2 && IC[1].flag){
			IC[1].flag = false;
			return(IC[1].Frequency);
		}
		if(channel == TIM_CHANNEL_3 && IC[2].flag){
			IC[2].flag = false;
			return(IC[2].Frequency);
		}
		if(channel == TIM_CHANNEL_4 && IC[3].flag){
			IC[3].flag = false;
			return(IC[3].Frequency);
		}
		return(0);
	}

};

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){
		if (IC[0].Is_First_Captured==0){
			IC[0].IC_Value1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			IC[0].Is_First_Captured =1;
		}
		else if (IC[0].Is_First_Captured){
			IC[0].IC_Value2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			IC[0].Difference = IC[0].IC_Value2-IC[0].IC_Value1;
			IC[0].Frequency = ((84000000UL/(IC[0].Difference))*1.02)+1;
			IC[0].Is_First_Captured = 0;
			IC[0].flag = true;
		}
	}
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2){
		if (IC[1].Is_First_Captured==0){
			IC[1].IC_Value1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
			IC[1].Is_First_Captured =1;
		}
		else if (IC[1].Is_First_Captured){
			IC[1].IC_Value2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
			IC[1].Difference = IC[1].IC_Value2-IC[1].IC_Value1;
			IC[1].Frequency = ((84000000UL/(IC[1].Difference))*1.02)+1;
			IC[1].Is_First_Captured = 0;
			IC[1].flag = true;
		}
	}
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_3){
		if (IC[2].Is_First_Captured==0){
			IC[2].IC_Value1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_3);
			IC[2].Is_First_Captured =1;
		}
		else if (IC[2].Is_First_Captured){
			IC[2].IC_Value2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_3);
			IC[2].Difference = IC[2].IC_Value2-IC[2].IC_Value1;
			IC[2].Frequency = ((84000000UL/(IC[2].Difference))*1.02)+1;
			IC[2].Is_First_Captured = 0;
			IC[2].flag = true;
		}
	}
	if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4){
		if (IC[3].Is_First_Captured==0){
			IC[3].IC_Value1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_4);
			IC[3].Is_First_Captured =1;
		}
		else if (IC[3].Is_First_Captured){
			IC[3].IC_Value2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_4);
			IC[3].Difference = IC[3].IC_Value2-IC[3].IC_Value1;
			IC[3].Frequency = ((84000000UL/(IC[3].Difference))*1.02)+1;
			IC[3].Is_First_Captured = 0;
			IC[3].flag = true;
		}
	}
}




#endif /* SRC_EXTENSIONS_INPUTCAPTURE_H_ */
