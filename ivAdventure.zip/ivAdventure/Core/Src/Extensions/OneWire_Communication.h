/*
 * OneWire_Comunication.h
 *
 *  Created on: 28 jul. 2020
 *      Author: JoseBenitez
 */
#include <stdint.h>
#include <stdio.h>

#ifndef SRC_CONFIG_PINES_ONEWIRE_COMUNICATION_H_
#define SRC_CONFIG_PINES_ONEWIRE_COMUNICATION_H_

class OneWire{
private:

public:
	OneWire(){}

	bool init(){
		bool Response=0;
		pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, OUTPUT);
		digitalWrite(ONEWIRE_GPIO_Port, ONEWIRE_Pin, LOW);
	    delayMicroseconds(480);

	    pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, INPUT);
	    delayMicroseconds(80);

	    if(!(digitalRead(ONEWIRE_GPIO_Port, ONEWIRE_Pin))) Response = true;
	    else Response = false;

	    delayMicroseconds(400);

	    delayMicroseconds(10);
	    return Response;
	}

	void write(uint8_t data){
		pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, OUTPUT);

		for(int i=0;i<8;i++){
			if((data & (1<<i))!=0){
				pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, OUTPUT);
				digitalWrite(ONEWIRE_GPIO_Port, ONEWIRE_Pin, LOW);
				delayMicroseconds(1);//1us

				pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, INPUT);
				delayMicroseconds(50);//60us
			}
			else{
				pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, OUTPUT);
				digitalWrite(ONEWIRE_GPIO_Port, ONEWIRE_Pin, LOW);
				delayMicroseconds(50);//60us

				pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, INPUT);
			}
		}
		delayMicroseconds(10);
	}

	uint8_t read(){
		uint8_t value=0;
		pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, INPUT);
		for(int i=0;i<8;i++){
			pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, OUTPUT);

			digitalWrite(ONEWIRE_GPIO_Port, ONEWIRE_Pin, LOW);
			delayMicroseconds(2);//2us

			pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, INPUT);
			if(digitalRead(ONEWIRE_GPIO_Port, ONEWIRE_Pin)){
				value |= 1<<i;
			}
			delayMicroseconds(60);//60us
		}
		delayMicroseconds(5);
		return value;
	}

	void waitOrder(){
		pinMode(ONEWIRE_GPIO_Port, ONEWIRE_Pin, OUTPUT);
		digitalWrite(ONEWIRE_GPIO_Port, ONEWIRE_Pin, HIGH);
	}
};

#endif /* SRC_CONFIG_PINES_ONEWIRE_COMUNICATION_H_ */
