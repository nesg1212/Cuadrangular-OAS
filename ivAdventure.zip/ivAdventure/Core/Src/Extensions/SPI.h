/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : SPI.h
*	@funcion    : Librería dedicada a las comunicaciones SPI
*/

#ifndef SRC_EXTENSIONS_SPI_H_
#define SRC_EXTENSIONS_SPI_H_

class SPI{
private:
	SPI_TypeDef* spiUsed;
	SPI_HandleTypeDef hspiI;
	uint8_t SPI_Mode_Selected;
public:
	SPI(SPI_TypeDef* spiUsed_, uint8_t SPI_Mode_Selected_){
		spiUsed=spiUsed_;
		SPI_Mode_Selected=SPI_Mode_Selected_;
	}
	bool begin(uint16_t baudrate){//21Mhz, dependiente de configuración del reloj segun STM32cubeMX
		hspiI.Instance = spiUsed;
		if(SPI_Mode_Selected==MASTER_MODE) hspiI.Init.Mode = SPI_MODE_MASTER;
		else hspiI.Init.Mode = SPI_MODE_SLAVE;
		hspiI.Init.Direction = SPI_DIRECTION_2LINES;
		hspiI.Init.DataSize = SPI_DATASIZE_8BIT;
		hspiI.Init.CLKPolarity = SPI_POLARITY_LOW;
		hspiI.Init.CLKPhase = SPI_PHASE_1EDGE;
		hspiI.Init.NSS = SPI_NSS_SOFT;
		//hspiI.Init.BaudRatePrescaler = baudrate;//18Mhz
		hspiI.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
		hspiI.Init.FirstBit = SPI_FIRSTBIT_MSB;
		hspiI.Init.TIMode = SPI_TIMODE_DISABLE;
		hspiI.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
		hspiI.Init.CRCPolynomial = 10;
		if (HAL_SPI_Init(&hspiI) != HAL_OK)
		{
		  return(false);
		}
		return(true);
	}
	uint8_t read(){
		uint8_t data[1];
		if(HAL_SPI_Receive(&hspiI, data, 1, 10)==HAL_OK){
			return(data[0]);
		}
		else(0);
	}
	SPI_HandleTypeDef* getSpi(){
		return(&hspiI);
	}


};

#endif /* SRC_EXTENSIONS_SPI_H_ */
