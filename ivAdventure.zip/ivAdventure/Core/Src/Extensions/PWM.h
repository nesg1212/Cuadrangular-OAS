/*
 * PWM.h
 *
 *  Created on: 12/10/2021
 *      Author: Ing.JoseBenitez
 */

#ifndef SRC_EXTENSIONS_PWM_H_
#define SRC_EXTENSIONS_PWM_H_

#include "main.h"

typedef enum {
	TIM_CHANNEL_1_SELECTED = 0,
	TIM_CHANNEL_2_SELECTED = 1,
	TIM_CHANNEL_3_SELECTED = 2
}CHANNEL_PWM;

class PWM{
private:
	TIM_TypeDef* timUsed;
	TIM_HandleTypeDef htimI;
public:
	PWM(TIM_TypeDef * tim){
		timUsed=tim;
	}
	bool begin(int freq){
		TIM_ClockConfigTypeDef sClockSourceConfig = {0};
		TIM_MasterConfigTypeDef sMasterConfig = {0};
		TIM_OC_InitTypeDef sConfigOC = {0};
#if defined(STM32F411xE)
		htimI.Instance = timUsed;
		htimI.Init.Prescaler = float(500*1680)/float(freq);
		htimI.Init.CounterMode = TIM_COUNTERMODE_UP;
		htimI.Init.Period = 100-1;
		htimI.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
		htimI.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
#elif defined(STM32F107xC)
		htimI.Instance = timUsed;
		htimI.Init.Prescaler = float(500*1440)/float(freq);
		htimI.Init.CounterMode = TIM_COUNTERMODE_UP;
		htimI.Init.Period = 100-1;
		htimI.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
		htimI.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
#endif

		if (HAL_TIM_Base_Init(&htimI) != HAL_OK){
			Error_Handler();
		}
		sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
		if (HAL_TIM_ConfigClockSource(&htimI, &sClockSourceConfig) != HAL_OK){
			Error_Handler();
		}
		if (HAL_TIM_PWM_Init(&htimI) != HAL_OK){
			Error_Handler();
		}
		sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
		sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
		if (HAL_TIMEx_MasterConfigSynchronization(&htimI, &sMasterConfig) != HAL_OK){
			Error_Handler();
		}
		sConfigOC.OCMode = TIM_OCMODE_PWM1;
		sConfigOC.Pulse = 0;
		sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
		sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
		if (HAL_TIM_PWM_ConfigChannel(&htimI, &sConfigOC, TIM_CHANNEL_1) != HAL_OK){
			Error_Handler();
		}
	    GPIO_InitTypeDef GPIO_InitStruct = {0};

/*
	    if(htimI.Instance==TIM5){
	      __HAL_RCC_GPIOA_CLK_ENABLE();
	      GPIO_InitStruct.Pin = GPIO_PIN_0;
	      GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	      GPIO_InitStruct.Pull = GPIO_NOPULL;
	      GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	      GPIO_InitStruct.Alternate = GPIO_AF2_TIM5;
	      HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	    }
*/
	}

	void write(int dutyCycle, CHANNEL_PWM cpwm){
		timUsed->CCR1 = dutyCycle;
		if(cpwm == TIM_CHANNEL_1_SELECTED)
			HAL_TIM_PWM_Start(&htimI, TIM_CHANNEL_1);
		if(cpwm == TIM_CHANNEL_2_SELECTED)
			HAL_TIM_PWM_Start(&htimI, TIM_CHANNEL_2);
		if(cpwm == TIM_CHANNEL_3_SELECTED)
			HAL_TIM_PWM_Start(&htimI, TIM_CHANNEL_3);
	}

};



#endif /* SRC_EXTENSIONS_PWM_H_ */
