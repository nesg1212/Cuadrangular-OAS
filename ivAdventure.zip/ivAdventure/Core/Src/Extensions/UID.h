/*
 * UID.h
 *
 *  Created on: 14/09/2021
 *      Author: Ing.JoseBenitez
 */

#ifndef SRC_EXTENSIONS_UID_H_
#define SRC_EXTENSIONS_UID_H_

#define STM32_UUID ((uint32_t *)0x1FFF7A10)

class UID{
private:
	char originalUID[30] = {'\0'};
	char processedUID[20] = {'\0'};
public:
	UID(){}
	void calculateUIDs(){
		uint32_t idPart;
		for(int i=0;i<3;i++){
			idPart = STM32_UUID[i];
			for(int j=0;j<8;j++){
				if(idPart <= uint32_t(pow(2, 4*j) - 1)) strcat(originalUID, "0");
			}
			strcat(originalUID, toChar(idPart, HEX));
		}

		idPart = STM32_UUID[2];
		for(int j=0;j<8;j++){
			if(idPart <= uint32_t(pow(2, 4*j) - 1)) strcat(processedUID, "0");
		}
		strcat(processedUID, toChar(idPart, HEX));

		idPart = (STM32_UUID[0] + STM32_UUID[1]) & 0xFFFFFFFF;
		for(int j=0;j<8;j++){
			if(idPart <= uint32_t(pow(2, 4*j) - 1)) strcat(processedUID, "0");
		}
		strcat(processedUID, toChar(idPart, HEX));

	}
	char* getOriginalUID(){
		return(originalUID);
	}
	char* getProcessedUID(){
		return(processedUID);
	}
};


#endif /* SRC_EXTENSIONS_UID_H_ */
