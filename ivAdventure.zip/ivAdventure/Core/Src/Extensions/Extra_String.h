/*
 * Extra_String.h
 *
 *  Created on: 9 sep. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_EXTRA_STRING_H_
#define SRC_EXTENSIONS_EXTRA_STRING_H_

#include <string.h>

int toInt(char* text){
	return((int)strtol(text, NULL, 10));
}
double toDouble(char* text){
	/*
	char* splitter=strtok_r(text, ".",&text);
	double integerPart=(double)toInt(splitter);
	splitter=strtok_r(text, ".",&text);
	double decimalPart=(double)toInt(splitter);
	while(decimalPart>1) decimalPart/=(double)10;
	double response=(double)integerPart+(double)decimalPart;
	*/
	return(atof(text));
}
char* toChar(int number){
	static char buffer[100];
	snprintf(buffer, 100, "%d", number);
	return((char*)buffer);
}
char* toChar(uint32_t number, Base base){
	static char buffer[100];
	if(base==HEX){
		snprintf(buffer, 100, "%x", number);
	}
	else{
		snprintf(buffer, 100, "%lu", number);
	}
	return((char*)buffer);
}
char* toChar(float number){
	static char buffer[100];
	snprintf(buffer, 100, "%.2f", number);
	return((char*)buffer);
}
char* toChar(double number){
	static char buffer[100];
	snprintf(buffer, 100, "%.2f", number);
	return((char*)buffer);
}
char* toChar(double number, int decimals){
	static char buffer[100];
	char buf1[10]="%0.",buf2[10];
	sprintf(buf2,"%d", decimals);
	strcat(buf1,buf2);
	strcat(buf1,"f");

	sprintf(buffer,buf1, number);
	return(buffer);
}
char* toChar(long number){
	static char buffer[100];
	snprintf(buffer, 100, "%lu", number);
	return((char*)buffer);
}

int indexOf(char* text, char* fragment){
	string data=text;
	return(data.find(fragment, 0));
}
char* substring(char* text, uint8_t start, uint8_t end){
	string data=text;
	string response=data.substr(start, end-start);
	return((char*)response.c_str());
}
char* split(char* text, char* fragment){

}

#endif /* SRC_EXTENSIONS_EXTRA_STRING_H_ */
