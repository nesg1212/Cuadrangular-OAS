/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : ADXL.h
*	@funcion    : Librería utilizada para la lectura de aceleraciones provenientes
*				  de sensores ADXL para la ivMini
*				  Librería en C encontrada en https://github.com/ImanHz/STM32-ADXL345
*/
#ifndef SRC_EXTENSIONS_ADXL_H_
#define SRC_EXTENSIONS_ADXL_H_

#include "main.h"

// Registers' Address 
#define DEVID 					0x0
#define BW_RATE					0x2C 
#define DATA_FORMAT 			0x31
#define FIFO_CTL 				0x38
#define DATA0					0x32
#define POWER_CTL 				0x2D
#define THRESH_TAP				0x1D
#define DUR						0x21
#define TAP_AXES				0x2A
#define INT_ENABLE				0x2E
#define INT_MAP					0x2F
#define LATENT					0x22
#define WINDOW					0x23
#define THRESH_ACT				0x24
#define THRESH_INACT			0x25
#define TIME_INAT				0x26
#define ACT_INACT_CTL			0x27
#define THRESH_FF 				0x28
#define TIME_FF					0x29
#define OFFX					0x1E
#define OFFY					0x1F
#define OFFZ					0x20
#define INT_SOURCE				0x30

// Init return values
typedef enum {ADXL_OK,ADXL_ERR} adxlStatus;
// ON/OFF enum
typedef enum {ON,OFF} Switch;
// Init. Definitions
#define SPIMODE_3WIRE 1
#define SPIMODE_4WIRE 0

#define LPMODE_NORMAL 0
#define LPMODE_LOWPOWER 1

#define BWRATE_6_25 	6
#define BWRATE_12_5 	7
#define BWRATE_25 		8
#define BWRATE_50 		9
#define BWRATE_100		10
#define BWRATE_200		11
#define BWRATE_400		12
#define BWRATE_800		13
#define BWRATE_1600   	14
#define BWRATE_3200   	15

#define BWRATE_12_5 	7
#define BWRATE_25 		8
#define BWRATE_50 		9
#define BWRATE_100		10
#define BWRATE_200		11
#define BWRATE_400		12

#define INT_ACTIVEHIGH 0
#define INT_ACTIVELOW  1

#define RESOLUTION_FULL  1
#define RESOLUTION_10BIT 0

#define JUSTIFY_MSB 	1
#define JUSTIFY_SIGNED  0
 
#define	SLEEP_RATE_1HZ 3
#define SLEEP_RATE_2HZ 2
#define SLEEP_RATE_4HZ 1
#define SLEEP_RATE_8HZ 0

#define RANGE_2G  0
#define RANGE_4G  1
#define RANGE_8G  2
#define RANGE_16G 3

#define AUTOSLEEPON  1
#define AUTOSLEEPOFF 0

#define LINKMODEON  1
#define LINKMODEOFF 0

float GAINX = 0.0f;
float GAINY = 0.0f;
float GAINZ = 0.0f;

// ADXL_getAccel function definitions
#define OUTPUT_FLOAT  0
#define OUTPUT_SIGNED 1

typedef enum {INT1=0,INT2=1} ADXL_IntOutput;
#define X_axes 4
#define Y_axes 2
#define Z_axes 1

#define ACTIVITY_AC 1
#define ACTIVITY_DC 0

// Init Type Def
typedef struct {
	uint8_t SPIMode;
	uint8_t IntMode;
	uint8_t LPMode;
	uint8_t Rate;
	uint8_t Range;
	uint8_t Resolution;
	uint8_t Justify;
	uint8_t AutoSleep;
	uint8_t LinkMode;
}ADXL_InitTypeDef;

SPI spiUsed(SPI2, MASTER_MODE);//por defecto
	
class ADXL{
private:
	uint8_t slavePin;
	GPIO_TypeDef* slavePort;
	SPI_HandleTypeDef* hspiUsed;
public:
	ADXL(){}

	bool begin(SPI spiUsed_, GPIO_TypeDef* slavePort_,uint16_t slavePin_){
		slavePin=slavePin_;
		slavePort=slavePort_;
		spiUsed=spiUsed_;
		hspiUsed=spiUsed.getSpi();
		pinMode(slavePort, slavePin, OUTPUT);
		digitalWrite(slavePort, slavePin, HIGH);
		return(true);
	}

	void writeRegister(uint8_t address,uint8_t value){
		if(address > 63)
			address = 63;

		// Setting R/W = 0, i.e.: Write Mode
	    address &= ~(0x80);

		digitalWrite(slavePort, slavePin, LOW);
		HAL_SPI_Transmit(hspiUsed, &address, 1, 10);
		HAL_SPI_Transmit(hspiUsed, &value, 1, 10);
		digitalWrite(slavePort, slavePin, HIGH);
	}

	void readRegister(uint8_t address,uint8_t * value, uint8_t num){
		if (address > 63)
			address = 63;
		if (num > 1)// Multiple Byte Read Settings
			address |= 0x40;
		else
			address &= ~(0x40);

		address |= (0x80);// Setting R/W = 1, i.e.: Read Mode

		digitalWrite(slavePort, slavePin, LOW);
		HAL_SPI_Transmit(hspiUsed,&address,1,10);
		HAL_SPI_Receive(hspiUsed,value,num,10);
		digitalWrite(slavePort, slavePin, HIGH);
	}

	void BW(ADXL_InitTypeDef * adxl){
		uint8_t bwreg=0;

		writeRegister(BW_RATE, bwreg);
		if (adxl->LPMode == LPMODE_LOWPOWER) {// Low power mode
			bwreg |= (1 << 4);
			if ( ((adxl->Rate) <7) && ((adxl->Rate)>12) ) bwreg += 7;
			else bwreg +=(adxl->Rate);
			writeRegister(BW_RATE,bwreg);
		}
		else{// Normal Mode
			if ( ((adxl->Rate) <6) && ((adxl->Rate)>15) ) bwreg += 6;
			else bwreg +=(adxl->Rate);
			writeRegister(BW_RATE,bwreg);
		}
	}

	void Format(ADXL_InitTypeDef * adxl){
		uint8_t formatreg=0;
		writeRegister(DATA_FORMAT,formatreg);
		formatreg = (adxl->SPIMode << 6) | (adxl->IntMode << 5) | (adxl->Justify << 2) | (adxl->Resolution << 3);
		formatreg += (adxl -> Range);
		writeRegister(DATA_FORMAT,formatreg);
	}

	adxlStatus Init(ADXL_InitTypeDef * adxl){
		digitalWrite(slavePort, slavePin, HIGH);// CS is active low. Here we deselect the chip. In each function the CS signal is asserted individually
		osDelay(5);
		uint8_t testval = 0;
		readRegister(DEVID,&testval,1);// The Device Address register is constant, i.e. = 0xE5
		if (testval != 0xE5)
			return ADXL_ERR;

		BW(adxl);// Init. of BW_RATE and DATAFORMAT registers
		Format(adxl);

		if (adxl->Resolution == RESOLUTION_10BIT){// Settings gains

			switch (adxl->Range) {
				case RANGE_2G:
					GAINX = GAINY = GAINZ = 1/255.0f;
					break;
				case RANGE_4G:
					GAINX = GAINY = GAINZ = 1/127.0f;
					break;
				case RANGE_8G:
					GAINX = GAINY = GAINZ = 1/63.0f;
					break;
				case RANGE_16G:
					GAINX = GAINY = GAINZ = 1/31.0f;
					break;
			}
		}
		else{
			GAINX = GAINY = GAINZ = 1/255.0f;
		}

		uint8_t reg;// Setting AutoSleep and Link bits
		readRegister(POWER_CTL,&reg,1);
		if ( (adxl->AutoSleep) == AUTOSLEEPON) reg |= (1 << 4); else reg &= ~(1 << 4);
		if ( (adxl->LinkMode) == LINKMODEON) reg |= (1 << 5); else reg &= ~(1 << 5);
		writeRegister(POWER_CTL,reg);

		return ADXL_OK;
	}

	void getAccel(void *Data , uint8_t outputType){
		uint8_t data[6]={0,0,0,0,0,0};
		readRegister(DATA0,data,6);

		if(outputType == OUTPUT_SIGNED){
			int16_t * acc = (int16_t*)Data;

			acc[0] = (int16_t) ((data[1]*256+data[0]));// Two's Complement
			acc[1] = (int16_t) ((data[3]*256+data[2]));
			acc[2] = (int16_t) ((data[5]*256+data[4]));
		}
		else if(outputType == OUTPUT_FLOAT){
			float * fdata = (float*)Data;
			fdata[0] = ( (int16_t) ((data[1]*256+data[0])))*GAINX;
			fdata[1] = ( (int16_t) ((data[3]*256+data[2])))*GAINY;
			fdata[2] = ( (int16_t) ((data[5]*256+data[4])))*GAINZ;
		}
	}

	void measure(Switch s){
		uint8_t reg;
		readRegister(POWER_CTL,&reg,1);
		switch (s) {
			case ON:
			reg &= ~(1<<2);
			reg |= (1<<3);
			writeRegister(POWER_CTL,reg);
			break;
			case OFF:
			reg &= ~(1<<3);
			writeRegister(POWER_CTL,reg);
			break;
		}
	}

	void sleep(Switch s,uint8_t rate){
		uint8_t reg;
		readRegister(POWER_CTL,&reg,1);
		switch (s){
			case ON:
			reg |= (1<<2);
			reg &= ~(1<<3);
			reg += rate;
			writeRegister(POWER_CTL,reg);
			break;
			case OFF:
			reg &= ~(1<<2);
			writeRegister(POWER_CTL,reg);
			break;
		}
	}

	void standby(Switch s){
		uint8_t reg;
		readRegister(POWER_CTL,&reg,1);
		switch (s) {
			case ON:
			reg &= ~(1<<2);
			reg &= ~(1<<3);
			writeRegister(POWER_CTL,reg);
			break;
			case OFF:
			reg |= (1<<2);
			writeRegister(POWER_CTL,reg);
			break;
		}
	}

	void test(uint8_t * regs){
		readRegister(BW_RATE,&regs[0],1);
		readRegister(DATA_FORMAT,&regs[1],1);
		readRegister(POWER_CTL,&regs[2],1);
	}


	void enableSelfTest(void){
		uint8_t formatreg=0;
		writeRegister(DATA_FORMAT,formatreg);
		formatreg |= (1<<7);
		writeRegister(DATA_FORMAT,formatreg);
	}

	void disableSelfTest(void){
		uint8_t formatreg=0;
		writeRegister(DATA_FORMAT,formatreg);
		formatreg &= ~(1<<7);
		writeRegister(DATA_FORMAT,formatreg);
	}

	void setOffset(int8_t off_x,int8_t off_y,int8_t off_z){
		writeRegister(OFFX,(uint8_t) off_x );
		writeRegister(OFFY,(uint8_t) off_y );
		writeRegister(OFFZ,(uint8_t) off_z );
	}


	void enableSingleTap(ADXL_IntOutput out, uint8_t axes, uint8_t Duration, uint8_t Threshold){
		uint8_t reg=0;

		writeRegister(DUR,Duration);
		writeRegister(THRESH_TAP,Threshold);

		//Setting the Axes
		readRegister(TAP_AXES,&reg,1);
		reg |= axes;

		writeRegister(TAP_AXES,reg);

		// Settings Int output
		readRegister(INT_MAP,&reg,1);
		if (out == INT1) reg &= ~(1<<6); else reg |= (1<<6);
		writeRegister(INT_MAP,reg);

		// Enabling the TAP interrupt
		readRegister(INT_ENABLE,&reg,1);
		reg |= (1<<6);
		writeRegister(INT_ENABLE,reg);
	}

	void disableSingleTap(void){
		uint8_t reg=0;
		// Disabling the TAP interrupt
		readRegister(INT_ENABLE,&reg,1);
		reg &= ~(1<<6);
		writeRegister(INT_ENABLE,reg);
	}

	void enableDoubleTap(ADXL_IntOutput out, uint8_t axes, uint8_t Duration, uint8_t Threshold, uint8_t Latent, uint8_t Window){
		uint8_t reg=0;

		writeRegister(DUR,Duration);
		writeRegister(THRESH_TAP,Threshold);
		writeRegister(LATENT,Latent);
		writeRegister(WINDOW,Window);

		//Setting the Axes
		readRegister(TAP_AXES,&reg,1);
		reg += axes;
		writeRegister(TAP_AXES,reg);

		// Settings Int output
		readRegister(INT_MAP,&reg,1);
		if (out == INT1) reg &= ~(1<<5); else reg |= (1<<5);
		writeRegister(INT_MAP,reg);

		// Enabling the TAP interrupt
		readRegister(INT_ENABLE,&reg,1);
		reg |= (1<<5);
		writeRegister(INT_ENABLE,reg);
	}

	void disableDoubleTap(void){
		uint8_t reg=0;
		// Disabling the Double TAP interrupt
		readRegister(INT_ENABLE,&reg,1);
		reg &= ~(1<<5);
		writeRegister(INT_ENABLE,reg);
	}

	void enableActivity(ADXL_IntOutput out, uint8_t axes, uint8_t Threshold, uint8_t AcDc){
		uint8_t reg=0;

		writeRegister(THRESH_ACT,Threshold);

		//Setting the Axes
		readRegister(ACT_INACT_CTL,&reg,1);
		reg += (axes << 4);
		if (AcDc == ACTIVITY_AC) reg |= (1<<7); else reg &= ~(1<<7);
			writeRegister(TAP_AXES,reg);

		// Settings Int output
		readRegister(INT_MAP,&reg,1);
		if (out == INT1) reg &= ~(1<<4); else reg |= (1<<4);
		writeRegister(INT_MAP,reg);

		// Enabling the TAP interrupt
		readRegister(INT_ENABLE,&reg,1);
		reg |= (1<<4);
		writeRegister(INT_ENABLE,reg);
	}

	void disableActivity(void){
		uint8_t reg=0;
		// Disabling the Double TAP interrupt
		readRegister(INT_ENABLE,&reg,1);
		reg &= ~(1<<4);
		writeRegister(INT_ENABLE,reg);
	}

	void enableFreeFall(ADXL_IntOutput out, uint8_t Threshold, uint8_t Time){
		uint8_t reg=0;
		writeRegister(TIME_FF,Time);
		writeRegister(THRESH_FF,Threshold);
		// Settings Int output
		readRegister(INT_MAP,&reg,1);
		if (out == INT1) reg &= ~(1<<2); else reg |= (1<<2);
		writeRegister(INT_MAP,reg);

		readRegister(INT_ENABLE,&reg,1);
		reg |= (1<<2);
		writeRegister(INT_ENABLE,reg);
	}


	void disableFreeFall(void){
		uint8_t reg=0;
		readRegister(INT_ENABLE,&reg,1);
		reg %= ~(1<<2);
		writeRegister(INT_ENABLE,reg);
	}

	void intProto(void){
		uint8_t reg=0;
		readRegister(INT_SOURCE,&reg,1);
	}

};

#endif
