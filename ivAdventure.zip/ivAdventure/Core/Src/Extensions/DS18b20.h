/*
 * DS18b20.h
 *
 *  Created on: 29 jul. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_DS18B20_H_
#define SRC_EXTENSIONS_DS18B20_H_

#include "../Extensions/OneWire_Communication.h"
#define SKYP_ROM 0xCC         //salta el proceso de lectura de ROM
#define MATCH_ROM 0x55		  //proceso de identificación segun la ROM
#define SEARCH_ROM 0xF0       //inicia la orden de busqueda
#define READ_ROM 0x33         //lee directamente al sensor con una ROM especifica
#define CONVERT_TEMP 0x44     //ordena medir la temperatura
#define READ_SCRATCHPAD 0xBE  // espacio de memoria donde está almacenada la temperatura
#define RESOLUTION_12bits 750 //tiempo de espera para obtener la maxima resolucion de temperatura

typedef enum{
	MODO_ESCANER,
	MODO_LECTURA
}DS18B20_modos;

OneWire OneWire1;
/*
uint8_t direcciones_prueba[5][8]={ {0x28,0xA4,0xC9,0x64,0x0B,0x00,0x00,0x10}, //unicos 2 sensores que tengo
		                           {0x28,0x00,0x09,0x00,0xCD,0xB8,0x21,0xA7},
								   {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00} };
								   */
class DS18B20{
private:
	uint8_t dir[numero_sensores_temperatura][8]={0};
	uint8_t offset[numero_sensores_temperatura]={0};
	float corrTemp=0;
public:
	DS18B20(){}
	bool init(){// inicializa Toda la red de sensores DS18B20
		//Proceso de lectura de ROMs almacenadas en EEPROM
		return(isSlaveConnected());
	}

	bool isSlaveConnected(){ // pregunta si existe algun esclavo en el canal
		bool val=OneWire1.init();
		return(val);
	}

	uint8_t getExistingROM(uint8_t* ROM){ //Retorna puerto donde ya está registrada la ROM
		for(uint8_t i=0;i<numero_sensores_temperatura;i++){
			if(ROM[0]==dir[i][0] && ROM[1]==dir[i][1] && ROM[2]==dir[i][2] && ROM[3]==dir[i][3] && ROM[4]==dir[i][4] && ROM[5]==dir[i][5] && ROM[6]==dir[i][6] && ROM[7]==dir[i][7]){
				return(i);
			}
		}
	}

	void getNewROM(uint8_t* RAW_ROM){ //Retorna con el puntero la ROM leida de un unico sensor DS18B20
		for(int j=0;j<5;j++){
			OneWire1.init();
			OneWire1.write(READ_ROM);
			for(int i=0;i<8;i++){
				RAW_ROM[i]=OneWire1.read();
			}
			if(RAW_ROM[0]==0x28) break;
			osDelay(5);
		}
		if(RAW_ROM[0]!=0x28) memcpy(RAW_ROM, 0, 8);
		init();
		osDelay(1);
	}

	float getTemperature(){ //Rutina para 1 solo sensor conectado a la red
		OneWire1.write(SKYP_ROM);
		OneWire1.write(CONVERT_TEMP);
		osDelay(750);

		OneWire1.init();
		osDelay(1);
		OneWire1.write(SKYP_ROM);
		OneWire1.write(READ_SCRATCHPAD);

		uint8_t tempByte1=OneWire1.read();
		uint8_t tempByte2=OneWire1.read();
		for(int i=0;i<7;i++){
			OneWire1.read();
		}
		return((float) (tempByte2<<8 | tempByte1)/16);
	}

	float getMuxTemperature(uint8_t* ROM_Temp){ //Lee la temperatura en la ROM especificada
		float temp=0;
		if(ROM_Temp[0] == 0) return(temp);
		for(int j=0;j<5;j++){
			OneWire1.init();
			OneWire1.write(MATCH_ROM);
			for(int i=0;i<8;i++){
				OneWire1.write(ROM_Temp[i]);
			}
			OneWire1.write(READ_SCRATCHPAD);
			uint8_t tempByte1=OneWire1.read();
			uint8_t tempByte2=OneWire1.read();
			temp = (float) (tempByte2<<8 | tempByte1)/16;
			if(temp<200){
				corrTemp = temp;
				return temp;
			}
			osDelay(5);
		}
		return(corrTemp);
	}

	float getMuxTemperature(uint8_t port){ //Lee la temperatura en un puerto especifico (ROM ya almacenada con antelacion)
		uint8_t ROM_Temp[8]={0};
		for(int i=0;i<8;i++){
			ROM_Temp[i] = dir[port][i];
		}

		float temp=0;
		if(ROM_Temp[0] == 0) return(temp);
		for(int j=0;j<5;j++){
			OneWire1.init();
			OneWire1.write(MATCH_ROM);
			for(int i=0;i<8;i++){
				OneWire1.write(ROM_Temp[i]);
			}
			OneWire1.write(READ_SCRATCHPAD);
			uint8_t tempByte1=OneWire1.read();
			uint8_t tempByte2=OneWire1.read();
			temp = (float) (tempByte2<<8 | tempByte1)/16;
			if(temp<200){
				return temp;
			}
			osDelay(5);
		}
		return(0);
	}

	float getOffset(uint8_t port){
		return(offset[port]);
	}

	void orderMeasure(){//orden de medicion global para todos los DS18B20
		OneWire1.init();
		osDelay(1);
		OneWire1.write(SKYP_ROM);
		osDelay(1);
		OneWire1.write(CONVERT_TEMP);
	}

	void orderMeasure(uint8_t* ROM_Temp){//orden de medición a ROM especifico
		OneWire1.init();
		osDelay(1);
		OneWire1.write(MATCH_ROM);
		for(int i=0;i<8;i++){
			OneWire1.write(ROM_Temp[i]);
		}
		OneWire1.write(CONVERT_TEMP);
	}

	void initAllMeasure(){//inicia proceso de medición (el tiempo de esta orden corresponde a la resolucion, >750ms es el valor maximo)
		OneWire1.waitOrder();
	}

	void storeInformation(uint8_t* ROM, uint8_t port, uint8_t offset){//almacena ROMs en puerto (luego debe guardarlo en EEPROM)
		for(uint8_t i=0;i<8;i++){
			dir[port][i]=ROM[i];
		}
		this->offset[port]=offset;
	}
	bool isValid(uint8_t port){//pregunta si el puerto tiene una ROM o está vacia
		if(dir[port][0] != 0) return(true);
		return(false);
	}
};

#endif /* SRC_EXTENSIONS_DS18B20_H_ */
