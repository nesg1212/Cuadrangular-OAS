/*
 * MAX31885.h
 *
 *  Created on: 29 ago. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_MAX31855_H_
#define SRC_EXTENSIONS_MAX31855_H_

typedef enum{
	NORMAL = 0,
	OPEN_CIRCUIT,
	SHORT_TO_GND,
	SHORT_TO_VCC,
	OTHER
}MAX31855_STATUS;

SPI spiUsed(SPI2,MASTER_MODE);//por defecto

class MAX31855{
private:
	uint8_t slavePin;
	GPIO_TypeDef* slavePort;
	SPI_HandleTypeDef* hspiUsed;
	uint8_t buffer_rx[4];
	MAX31855_STATUS Status;
public:
	MAX31855(){}

	bool init(SPI spiUsed_, GPIO_TypeDef* slavePort_,uint16_t slavePin_){
		slavePin=slavePin_;
		slavePort=slavePort_;
		spiUsed=spiUsed_;
		hspiUsed=spiUsed.getSpi();
		pinMode(slavePort,slavePin,OUTPUT);
		digitalWrite(slavePort,slavePin,HIGH);
		return(true);
	}
	bool read(){
		  digitalWrite(slavePort,slavePin,LOW);
		  buffer_rx[0]=spiUsed.read();
		  buffer_rx[1]=spiUsed.read();
		  buffer_rx[2]=spiUsed.read();
		  buffer_rx[3]=spiUsed.read();
		  digitalWrite(slavePort,slavePin,HIGH);

		  if(getStatus()==NORMAL) return(true);
		  return(false);
	}
	float getInternal(){//solo valores positivos
		uint16_t data;
		data = buffer_rx[2]<<4 | ((buffer_rx[3]>>4));
		float internal = data & 0x7FF;
		if (data & 0x800){
			internal = 0xF800 | (data & 0x7FF);
		}
		internal *= 0.0625;
		return(internal);
	}
	float getCelsius(void) {
	    int16_t data;

	    data = (buffer_rx[0]<<6) | ((buffer_rx[1]>>2)&0x3F);

	    if (data & 0x800) {
	      data = 0xFFFFC000 | (data & 0x3FFF);
	    }

	    float centigrade = data*0.25;
	    return(centigrade);
	}

	MAX31855_STATUS getStatus(){
		uint8_t status=buffer_rx[3] & 0x0F;
		if(status==0x00) return(NORMAL);
		if(status==0x01) return(OPEN_CIRCUIT);
		if(status==0x02) return(SHORT_TO_GND);
		if(status==0x04) return(SHORT_TO_VCC);
		return(OTHER);
	}



};



#endif /* SRC_EXTENSIONS_MAX31855_H_ */
