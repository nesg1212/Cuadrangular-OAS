/*
 * GPS_NEO.h
 *
 *  Created on: 1 sep. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_GPS_NEO_H_
#define SRC_EXTENSIONS_GPS_NEO_H_

typedef enum{
	GNGGA = 0,
	GNRMC
}NMEA_TYPE;

typedef enum{
	CONECTED = 0,
	WAITING_FOR_SATELLITE,
	ISNT_VALID,
	ISNT_DATA
}GNSS_RESPONSE;

typedef struct{
	int validationState = 0;
	char time[6]={'\0'};
	int numSatellites=0;
	double latitude=0;
	double longitude=0;
	double seaLevel=0;
}GGA;

#if defined(STM32F411xE)
	Serial serialUsed(USART6);//por defecto
#elif defined(STM32F107xC)
	Serial serialUsed(USART2);//por defecto
#endif

GGA Gngga;

class GPS_NEO{
private:
public:
	GPS_NEO(){}

	bool init(Serial serialUsed_){
		serialUsed=serialUsed_;
		serialUsed.begin(9600);

		return(true);
	}

	GNSS_RESPONSE encode(NMEA_TYPE nmeaFormat){
		char bufferTx[200];
		int pos=0;
		if(nmeaFormat==GNGGA){//solo para prueba de William
		//if(nmeaFormat==GNGGA && serialUsed.available()>0){
			//while(serialUsed.available()>0) bufferTx[pos++]=serialUsed.read();
			memcpy(bufferTx, "$GNGGA,142952.00,0706.02647,N,07307.31980,W,1,05,2.16,944.7,M,-1.1,M,,*4C\n",75);//solo para prueba de William
			//Serial2.println(bufferTx);
			char* temp = bufferTx;

			if(indexOf(bufferTx, "$GNGGA")>=0){
				strtok_r(temp, ",",&temp);
				char* timeRaw=strtok_r(temp, ",",&temp);
				char* latitudeRaw=strtok_r(temp, ",",&temp);
				char* lat_ori=strtok_r(temp, ",",&temp);
				char* longitudeRaw=strtok_r(temp, ",",&temp);
				char* lon_ori=strtok_r(temp, ",",&temp);
				char* validation=strtok_r(temp, ",",&temp);
				char* numSat=strtok_r(temp, ",",&temp);
				strtok_r(temp, ",",&temp);//dilusion horizontal
				char* seaLevel=strtok_r(temp, ",",&temp);

				Gngga.validationState=toInt(validation);
				if(Gngga.validationState>0){
					for(int i=0;i<6;i++) Gngga.time[i]=(char)timeRaw[i];
					Gngga.latitude=degrees2decimal(toDouble(latitudeRaw), (char)lat_ori[0]);
					Gngga.longitude=degrees2decimal(toDouble(longitudeRaw), (char)lon_ori[0]);
					Gngga.numSatellites=toInt(numSat);
					Gngga.seaLevel=toDouble(seaLevel);
					return(CONECTED);
				}
				else{
					return(WAITING_FOR_SATELLITE);
				}
			}
			else{
				return(ISNT_VALID);
			}
		}
		return(ISNT_DATA);
	}
	double degrees2decimal(double degrees, char orientation){
		int integerPart = (int) degrees;
		integerPart/=100;
		double decimalPart=(degrees-double(integerPart*100))/double(60);
		degrees=double(integerPart) + decimalPart;
		if(orientation=='S' || orientation=='W') degrees*=-1;
		return(degrees);
	}
	uint8_t getValidationState(){
		return(Gngga.validationState);
	}
	char* getTime(){
		return(Gngga.time);
	}
	uint8_t getNumSatellites(){
		return(Gngga.numSatellites);
	}
	double getLatitude(){
		return(Gngga.latitude);
	}
	double getLongitude(){
		return(Gngga.longitude);
	}
	double getHeightAboveSeaLevel(){
		return(Gngga.seaLevel);
	}
};


#endif /* SRC_EXTENSIONS_GPS_NEO_H_ */
