/*
 * digitalPins.h
 *
 *  Created on: 28 jul. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_DIGITALPINS_H_
#define SRC_EXTENSIONS_DIGITALPINS_H_

#define OUTPUT 0
#define INPUT 1
#define INPUT_EXTIN 2
#define HIGH 1
#define LOW 0

void pinMode(GPIO_TypeDef *GPIOx, uint8_t GPIO_Pin, bool GPIO_Mode_State){
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	if(GPIO_Mode_State==OUTPUT){
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
	}
	if(GPIO_Mode_State==INPUT){
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
	}
	if(GPIO_Mode_State==INPUT_EXTIN){
		GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
	}
	//GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOx,&GPIO_InitStruct);
}

void digitalWrite(GPIO_TypeDef *GPIOx, uint8_t GPIO_Pin, bool GPIO_State){
	GPIO_PinState GPIO_Output_State;
	if(GPIO_State) GPIO_Output_State=GPIO_PIN_SET;
	else GPIO_Output_State=GPIO_PIN_RESET;
	HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_Output_State);
}

bool digitalRead(GPIO_TypeDef *GPIOx, uint8_t GPIO_Pin){
	GPIO_PinState bitstatus = HAL_GPIO_ReadPin(GPIOx, GPIO_Pin);
	if(bitstatus == (uint32_t)GPIO_PIN_SET){
		return true;
	}else{
		return false;
	}
}

void digitalToogle(GPIO_TypeDef *GPIOx, uint8_t GPIO_Pin){
	//digitalToogle(GPIOx, GPIO_Pin);
	HAL_GPIO_TogglePin(GPIOx, GPIO_Pin);
}



#endif /* SRC_EXTENSIONS_DIGITALPINS_H_ */
