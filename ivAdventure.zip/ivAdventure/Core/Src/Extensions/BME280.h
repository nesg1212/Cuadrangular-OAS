/*
 * BME280.h
 *
 *  Created on: 27 ago. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_BME280_H_
#define SRC_EXTENSIONS_BME280_H_

#define BME280_REG_CONFIG      0xF5 /* bits: 7-5 t_sb; 4-2 filter; 0 spi3w_en */
#define BME280_REG_CTRL        0xF4 /* bits: 7-5 osrs_t; 4-2 osrs_p; 1-0 mode */
#define BME280_REG_STATUS      0xF3 /* bits: 3 measuring; 0 im_update */
#define BME280_REG_CTRL_HUM    0xF2 /* bits: 2-0 osrs_h; */
#define BME280_REG_RESET       0xE0
#define BME280_RESET_VALUE     0xB6
#define BME280_REG_ID          0xD0
#define BME280_STANDBY_250    0x03 //standby measurement

class BME280{
private:
	uint8_t Address;
	I2C_HandleTypeDef *hi2cI;
    uint16_t dig_T1,dig_P1;
    int16_t  dig_T2,dig_T3,dig_P2,dig_P3,dig_P4,dig_P5,dig_P6,dig_P7,dig_P8,dig_P9,dig_H2,dig_H4,dig_H5;
	uint8_t  dig_H1,dig_H3,dig_H6;
	float temperature, humidity,pressure,altitude;
public:
	bool read_register16(uint8_t addr, uint16_t *value) {
		uint8_t rx_buff[2];

		if (HAL_I2C_Mem_Read(hi2cI, Address, addr, 1, rx_buff, 2, 5000) == HAL_OK) {
			*value = (uint16_t) ((rx_buff[1] << 8) | rx_buff[0]);
			return true;
		} else
			return false;
	}

	int read_data(uint8_t addr, uint8_t *value, uint8_t len) {
		if (HAL_I2C_Mem_Read(hi2cI, Address, addr, 1, value, len, 5000) == HAL_OK)
			return 0;
		else
			return 1;
	}

	bool read_calibration_data() {
		if (read_register16(0x88, &dig_T1)
				&& read_register16(0x8a, (uint16_t *) &dig_T2)
				&& read_register16(0x8c, (uint16_t *) &dig_T3)
				&& read_register16(0x8e, &dig_P1)
				&& read_register16(0x90, (uint16_t *) &dig_P2)
				&& read_register16(0x92, (uint16_t *) &dig_P3)
				&& read_register16(0x94, (uint16_t *) &dig_P4)
				&& read_register16(0x96, (uint16_t *) &dig_P5)
				&& read_register16(0x98, (uint16_t *) &dig_P6)
				&& read_register16(0x9a, (uint16_t *) &dig_P7)
				&& read_register16(0x9c, (uint16_t *) &dig_P8)
				&& read_register16(0x9e, (uint16_t *) &dig_P9)) {
			return true;
		}
		return false;
	}

	bool read_hum_calibration_data() {
		uint16_t h4, h5;

		if (!read_data(0xa1, &dig_H1, 1)
				&& read_register16(0xe1, (uint16_t *) &dig_H2)
				&& !read_data(0xe3, &dig_H3, 1)
				&& read_register16(0xe4, &h4)
				&& read_register16(0xe5, &h5)
				&& !read_data(0xe7, (uint8_t *) &dig_H6, 1)) {
			dig_H4 = (h4 & 0x00ff) << 4 | (h4 & 0x0f00) >> 8;
			dig_H5 = h5 >> 4;
			return true;
		}
		return false;
	}

	int write_register8(uint8_t addr, uint8_t value) {
		if (HAL_I2C_Mem_Write(hi2cI, Address, addr, 1, &value, 1, 10000) == HAL_OK)
			return false;
		else
			return true;
	}

	bool init(I2C_HandleTypeDef *hi2c, uint8_t Address_) {

		Address=(Address_<<1);
		hi2cI = hi2c;
		uint8_t mode=0x03;//Normal mode
		uint8_t filter=0x00;//filter off
		uint8_t oversampling_pressure=0x03;//standard
		uint8_t oversampling_temperature=0x03;//standard
		uint8_t oversampling_humidity=0x03;//standard
		uint8_t standby=BME280_STANDBY_250;//250ms standby

		if(!HAL_I2C_IsDeviceReady(hi2cI, Address, 1, 10) == HAL_OK) return(false);
		osDelay(1);
		if(read_data(BME280_REG_ID, (uint8_t *) 0x60, 1)) return(false);
		osDelay(1);
		if(write_register8(BME280_REG_RESET, BME280_RESET_VALUE)) return(false);// Soft reset.
		osDelay(1);

		while(1){
			uint8_t status;
			if(!read_data(BME280_REG_STATUS, &status, 1) && (status & 1) == 0) break;
			osDelay(1);
		}

		uint8_t config = (standby << 5) | (filter << 2);
		uint8_t ctrl = (oversampling_temperature << 5) | (oversampling_pressure << 2) | (mode);
		uint8_t ctrl_hum = oversampling_humidity;

		if(!read_calibration_data()) return(false);
		osDelay(1);
		if(!read_hum_calibration_data()) return(false);
		osDelay(1);
		if(write_register8(BME280_REG_CONFIG, config)) return(false);
		osDelay(1);
		if (write_register8(BME280_REG_CTRL_HUM, ctrl_hum)) return(false);
		osDelay(1);
		if (write_register8(BME280_REG_CTRL, ctrl)) return(false);
		osDelay(1);
		return(true);
	}

	bool isMeasuring() {
		uint8_t status;
		if (read_data(BME280_REG_STATUS, &status, 1))
			return false;
		if (status & (1 << 3)) {
			return true;
		}
		return false;
	}

	int32_t compensate_temperature(int32_t adc_temp, int32_t *fine_temp) {
		int32_t var1, var2;

		var1 = ((((adc_temp >> 3) - ((int32_t) dig_T1 << 1)))
				* (int32_t) dig_T2) >> 11;
		var2 = (((((adc_temp >> 4) - (int32_t) dig_T1)
				* ((adc_temp >> 4) - (int32_t) dig_T1)) >> 12)
				* (int32_t) dig_T3) >> 14;

		*fine_temp = var1 + var2;
		return (*fine_temp * 5 + 128) >> 8;
	}

 uint32_t compensate_pressure(int32_t adc_press, int32_t fine_temp) {
	int64_t var1, var2, p;

	var1 = (int64_t) fine_temp - 128000;
	var2 = var1 * var1 * (int64_t) dig_P6;
	var2 = var2 + ((var1 * (int64_t) dig_P5) << 17);
	var2 = var2 + (((int64_t) dig_P4) << 35);
	var1 = ((var1 * var1 * (int64_t) dig_P3) >> 8)
			+ ((var1 * (int64_t) dig_P2) << 12);
	var1 = (((int64_t) 1 << 47) + var1) * ((int64_t) dig_P1) >> 33;

	if (var1 == 0) {
		return 0;  // avoid exception caused by division by zero
	}

	p = 1048576 - adc_press;
	p = (((p << 31) - var2) * 3125) / var1;
	var1 = ((int64_t) dig_P9 * (p >> 13) * (p >> 13)) >> 25;
	var2 = ((int64_t) dig_P8 * p) >> 19;

	p = ((p + var1 + var2) >> 8) + ((int64_t) dig_P7 << 4);
	return p;
}

uint32_t compensate_humidity(int32_t adc_hum,
		int32_t fine_temp) {
	int32_t v_x1_u32r;

	v_x1_u32r = fine_temp - (int32_t) 76800;
	v_x1_u32r = ((((adc_hum << 14) - ((int32_t) dig_H4 << 20)
			- ((int32_t) dig_H5 * v_x1_u32r)) + (int32_t) 16384) >> 15)
			* (((((((v_x1_u32r * (int32_t) dig_H6) >> 10)
					* (((v_x1_u32r * (int32_t) dig_H3) >> 11)
							+ (int32_t) 32768)) >> 10) + (int32_t) 2097152)
					* (int32_t) dig_H2 + 8192) >> 14);
	v_x1_u32r = v_x1_u32r
			- (((((v_x1_u32r >> 15) * (v_x1_u32r >> 15)) >> 7)
					* (int32_t) dig_H1) >> 4);
	v_x1_u32r = v_x1_u32r < 0 ? 0 : v_x1_u32r;
	v_x1_u32r = v_x1_u32r > 419430400 ? 419430400 : v_x1_u32r;
	return v_x1_u32r >> 12;
}

bool read_fixed(int32_t *temperature, uint32_t *pressure,
		uint32_t *humidity) {
	int32_t adc_pressure;
	int32_t adc_temp;
	uint8_t data[8];

	// Need to read in one sequence to ensure they match.
	size_t size = humidity ? 8 : 6;
	if (read_data(0xf7, data, size)) {
		return false;
	}

	adc_pressure = data[0] << 12 | data[1] << 4 | data[2] >> 4;
	adc_temp = data[3] << 12 | data[4] << 4 | data[5] >> 4;

	int32_t fine_temp;
	*temperature = compensate_temperature(adc_temp, &fine_temp);
	*pressure = compensate_pressure(adc_pressure, fine_temp);

	int32_t adc_humidity = data[6] << 8 | data[7];
	*humidity = compensate_humidity(adc_humidity, fine_temp);

	return true;
}

bool read() {
	int32_t fixed_temperature;
	uint32_t fixed_pressure;
	uint32_t fixed_humidity;
	if (read_fixed(&fixed_temperature, &fixed_pressure, &fixed_humidity)) {
		temperature = (float) fixed_temperature / 100;
		pressure = (float)((float) fixed_pressure / 256) / 100.0;
		humidity = (float) fixed_humidity / 1024;

		float seaLevelhPa = 1013.25;
		altitude = 44330 * (1.0 - pow(pressure / seaLevelhPa, 0.1903));

		return true;
	}

	return false;
}

float getTemperature(){
	return(temperature);
}
float getHumidity(){
	return(humidity);
}
float getPressure(){
	return(pressure);
}
float getAltitude(){
	return(altitude);
}
};



#endif /* SRC_EXTENSIONS_BME280_H_ */
