/*
 * CD4067.h
 *
 *  Created on: 20 ago. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_CD4067_H_
#define SRC_EXTENSIONS_CD4067_H_

class CD4067 {
private:
	uint32_t channel_ADC;
	uint8_t SA,SB,SC,SD,ENABLE;
	GPIO_TypeDef *PORT_SA,*PORT_SB,*PORT_SC,*PORT_SD,*PORT_ENABLE;
public:
	CD4067(uint32_t channel_ADC_,uint8_t SA_,GPIO_TypeDef *PORT_SA_,uint8_t SB_,GPIO_TypeDef *PORT_SB_,uint8_t SC_,GPIO_TypeDef *PORT_SC_,uint8_t SD_,GPIO_TypeDef *PORT_SD_,uint8_t ENABLE_,GPIO_TypeDef *PORT_ENABLE_){
		SA=SA_;PORT_SA=PORT_SA_;
		SB=SB_;PORT_SB=PORT_SB_;
		SC=SC_;PORT_SC=PORT_SC_;
		SD=SD_;PORT_SD=PORT_SD_;
		ENABLE=ENABLE_;PORT_ENABLE=PORT_ENABLE_;
		channel_ADC=channel_ADC_;
	}
	virtual ~CD4067(){}
	void init(){
	  pinMode(PORT_SA,SA,OUTPUT);
	  pinMode(PORT_SB,SB,OUTPUT);
	  pinMode(PORT_SC,SC,OUTPUT);
	  pinMode(PORT_SD,SD,OUTPUT);
	  pinMode(PORT_ENABLE,ENABLE,OUTPUT);
	  digitalWrite(PORT_ENABLE, ENABLE, HIGH);
	}
	void setChannel(int number){
	  setEnable(false);
	  digitalWrite(PORT_SA, SA, number & 1);
	  digitalWrite(PORT_SB, SB, number>>1 & 1);
	  digitalWrite(PORT_SC, SC, number>>2 & 1);
	  digitalWrite(PORT_SD, SD, number>>3 & 1);
	  setEnable(true);
	  osDelay(1);
	}
	void setEnable(bool action){
	  if(action){digitalWrite(PORT_ENABLE, ENABLE, LOW);}
	  else{digitalWrite(PORT_ENABLE, ENABLE, HIGH);}
	  osDelay(1);
	}
	double getVoltage(){
		uint16_t adc_Value=analogRead(channel_ADC);
		double voltage=(double)((double)adc_Value*3.3/4095.0);
		return(voltage);
	}
	uint16_t getADC(){
		return(analogRead(channel_ADC));
	}
};

#endif /* SRC_EXTENSIONS_CD4067_H_*/



