/*
 * ModbusTable.h
 *
 *  Created on: 9 oct. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_MODBUS_MODBUSTABLE_H_
#define SRC_EXTENSIONS_MODBUS_MODBUSTABLE_H_

/*
 * COIL     -- bin output      0  -   9
 * DISCRETE -- bin input      10  -  19
 * INPUT    -- uint16 REGOUT  20  - 119
 * HOLDING  -- uint16 REGIN  120  - 219
 * EXTRA    -- uint16 REGOUT 220  - 299
 */

uint16_t ModbusDATA[220];//vector != 300, puede ser menor o mayor, solo que con 300 no funciona

typedef enum{
	COIL = 0,
	DISCRETE = 10,
	INPUTR = 20,
	HOLDING = 120,
	EXTRA = 220
}Modbus_Registers;




#endif /* SRC_EXTENSIONS_MODBUS_MODBUSTABLE_H_ */
