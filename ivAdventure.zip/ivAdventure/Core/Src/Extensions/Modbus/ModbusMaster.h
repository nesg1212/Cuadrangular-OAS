/*
 * ModbusMaster.h
 *
 *  Created on: 12 oct. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_MODBUS_MODBUSMASTER_H_
#define SRC_EXTENSIONS_MODBUS_MODBUSMASTER_H_

#include <math.h>

#include "../../Extensions/Modbus/Modbus.h"
#include "../../Extensions/Modbus/ModbusTable.h"

typedef enum{
    READ_COILS               = 0x01,
    READ_DISCRETE_INPUT      = 0x02,
    READ_HOLDING_REGISTERS   = 0x03,
    READ_INPUT_REGISTERS     = 0x04,
    WRITE_SINGLE_COIL        = 0x05,
    WRITE_SINGLE_REGISTER    = 0x06,
    WRITE_MULTIPLE_COILS     = 0x0F,
    WRITE_MULTIPLE_REGISTERS = 0x10
}FunctionCode;

class ModbusMaster{
private:
	modbusHandler_t ModbusH;
	modbus_t telegram[2];
	SEMAPHORE Modbus_Semaphore=FREE;
public:
	ModbusMaster(){}
	void init(UART_HandleTypeDef* uartUsed){
		MX_USART6_UART_Init();
		pinMode(RS485_EN_PORT,RS485_EN_PIN,OUTPUT);
		ModbusH.uiModbusType = MASTER_RTU;
		ModbusH.port =  uartUsed;
		ModbusH.u8id = ID_MASTER; //master ID, siempre debe ser 0
		ModbusH.u16timeOut = 1000;
		ModbusH.EN_Port = RS485_EN_PORT;
		ModbusH.EN_Pin = RS485_EN_PIN;
		ModbusH.u32overTime = 0;
		ModbusH.au16regs = ModbusDATA;
		ModbusH.u8regsize= sizeof(ModbusDATA)/sizeof(ModbusDATA[0]);
		ModbusInit(&ModbusH);
		ModbusStart(&ModbusH);
	}
/*
	void readCoilsRegisters(uint8_t slaveID, uint16_t startAdd, uint8_t numRegisters,bool *arrayModbusPointer){
		FunctionCode functionCode = READ_COILS;
		uint8_t blockStart = (startAdd>>4) & 0xFFFF;
		uint8_t blockEnd   = ((startAdd+numRegisters)>>4) & 0xFFFF;

		telegram[0].u8id = slaveID;
		telegram[0].u8fct = functionCode;
		telegram[0].u16RegAdd = startAdd;
		telegram[0].u16CoilsNo = (blockEnd-blockStart)+1;
		telegram[0].au16reg = ModbusDATA;

		ModbusQuery(&ModbusH, telegram[0]);
	}
*/

	void readHoldingRegister(uint8_t slaveID, uint16_t startAdd, uint8_t numRegisters){
		FunctionCode functionCode = READ_HOLDING_REGISTERS;

		telegram[0].u8id = slaveID;
		telegram[0].u8fct = functionCode;
		telegram[0].u16RegAdd = startAdd;
		telegram[0].u16CoilsNo = numRegisters;
		telegram[0].au16reg = ModbusDATA;

		ModbusQuery(&ModbusH, telegram[0]);
	}

	void update(uint8_t numRegisters, uint16_t *arrayModbusPointer){
		for(int i=0;i<numRegisters;i++){
			arrayModbusPointer[i]=ModbusDATA[i];
		}
	}





/*
	void setCoilRegister(uint16_t coilPos, bool coilValue){
		uint16_t coilPosRegister = (coilPos>>4) & 0xFFFF;
		uint16_t coilPosU16 = coilPos & 0x0F;

		ModbusH.au16regs[coilPosRegister]&= (uint16_t)(0xFF - pow(2,coilPosU16));
		ModbusH.au16regs[coilPosRegister]|= (uint16_t)(coilValue<<coilPosU16);
	}
	bool getCoilRegister(uint16_t coilPos){
		uint16_t coilPosRegister = (coilPos>>4) & 0xFFFF;
		uint16_t coilPosU16 = coilPos & 0x0F;

		if(((ModbusH.au16regs[coilPosRegister]>>coilPosU16) & 0x01) == 1){
			return(true);
		}
		return(false);
	}
	void setDiscreteRegister(uint16_t DiscretePos, bool DiscreteValue){
		setCoilRegister((DISCRETE*16)+DiscretePos, DiscreteValue);
	}
	bool getDiscreteRegister(uint16_t DiscretePos){
		return(getCoilRegister((DISCRETE*16)+DiscretePos));
	}
	void setInputRegister(uint16_t inputPos, uint16_t inputValue){
		uint16_t inputPosRegister = INPUTR + inputPos;
		ModbusH.au16regs[inputPosRegister] = inputValue;
	}
	uint16_t getInputRegister(uint16_t inputPos){
		uint16_t inputPosRegister = INPUTR + inputPos;
		return(ModbusH.au16regs[inputPosRegister]);
	}
	void setHoldingRegister(uint16_t holdingPos, uint16_t holdingValue){
		uint16_t holdingPosRegister = HOLDING + holdingPos;
		ModbusH.au16regs[holdingPosRegister] = holdingValue;
	}
	uint16_t getHoldingRegister(uint16_t holdingPos){
		uint16_t holdingPosRegister = HOLDING + holdingPos;
		return(ModbusH.au16regs[holdingPosRegister]);
	}
	void giveSemaphore(){
		xSemaphoreGive(ModbusH.ModBusSphrHandle);
	}
	void waitAndTakeSemaphore(){
		xSemaphoreTake((QueueHandle_t)ModbusH.ModBusSphrHandle , portMAX_DELAY);
	}
*/
};



#endif /* SRC_EXTENSIONS_MODBUS_MODBUSMASTER_H_ */
