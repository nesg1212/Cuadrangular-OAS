/*
 * ADS1115.h
 *
 *  Created on: 10 sep. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_ADS1115_H_
#define SRC_EXTENSIONS_ADS1115_H_

typedef enum{
	Differential_A0_A1 = 0b1000,
	Differential_A0_A3 = 0b1001,
	Differential_A1_A3 = 0b1010,
	Differential_A2_A3 = 0b1011,
	SINGLE_A0 = 0b1100,
	SINGLE_A1 = 0b1101,
	SINGLE_A2 = 0b1110,
	SINGLE_A3 = 0b1111,
}ADS1115_MODE;

typedef enum{
	V_6_144 = 0b0000,
	V_4_096 = 0b0010,
	V_2_048 = 0b0100,
	V_1_024 = 0b0110,
	V_0_512 = 0b1000,
	V_0_256 = 0b1010
}ADS1115_GAIN;

class ADS1115{
private:
	uint8_t Address;
	I2C_HandleTypeDef *hi2cI;
	ADS1115_GAIN gain=V_6_144;
public:
	ADS1115(){}
	bool init(I2C_HandleTypeDef *hi2c, uint8_t Address_){
		Address=Address_<<1;
		hi2cI = hi2c;

		if(!HAL_I2C_IsDeviceReady(hi2cI, Address, 1, 10) == HAL_OK){
				return(false);
		}
		return(true);
	}
	uint16_t read_bits(ADS1115_MODE mode){
		uint8_t I2CBuff[3];
		uint16_t reading;

		I2CBuff[0] = 0x01;
		I2CBuff[1] = (mode<<4) | gain;
		I2CBuff[2] = 0xA3;

		HAL_I2C_Master_Transmit(hi2cI, Address, I2CBuff, 3, 100);
		I2CBuff[0] = 0x00;
		HAL_I2C_Master_Transmit(hi2cI, Address, I2CBuff, 1 ,100);
		osDelay(20);

		HAL_I2C_Master_Receive(hi2cI, Address, I2CBuff, 2, 100);
		reading = (I2CBuff[0] << 8 | I2CBuff[1] );

		return(reading);
	}
	void setGain(ADS1115_GAIN gain_){
		gain=gain_;
	}
	float read_Voltage(ADS1115_MODE mode){
		uint16_t reading=read_bits(mode);
		bool sign = false;
		float reference=0;
		if(gain==V_6_144) reference=6.144;
		if(gain==V_4_096) reference=4.096;
		if(gain==V_2_048) reference=2.048;
		if(gain==V_0_512) reference=0.512;
		if(gain==V_0_256) reference=0.256;
		if(reading>>15){
			reading = (~reading + 1) & 0x7FFF;
			sign = true;
		}

		float voltage=float(reading)*reference/float(32767);
		if(sign) voltage*=-1;
		return(voltage);
	}

};

#endif /* SRC_EXTENSIONS_ADS1115_H_ */
