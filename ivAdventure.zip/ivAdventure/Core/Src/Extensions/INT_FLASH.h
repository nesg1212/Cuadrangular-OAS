/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : EEPROM.h
*	@funcion    : define las funciones necesarias para manejo de la EEPROM
*				  de caracter independiente a los ticks de las tareas, es decir
*				  que se convierte en una ejecución que todas las tareas pueden llamar
*				  en cualquier momento.
*/

/********************  FLASH_Error_Codes   ***********************//*
HAL_FLASH_ERROR_NONE      0x00U  // No error
HAL_FLASH_ERROR_PROG      0x01U  // Programming error
HAL_FLASH_ERROR_WRP       0x02U  //  protection error
HAL_FLASH_ERROR_OPTV      0x04U  // Option validity error
*/

#ifndef SRC_EXTENSIONS_INT_FLASH_H_
#define SRC_EXTENSIONS_INT_FLASH_H_

#include "main.h"

class INT_FLASH{
private:
	uint8_t bytes_temp[4];
public:
	INT_FLASH(){}

	uint32_t getPage(uint32_t Address){
	  for (int indx=0; indx<128; indx++){
		  if((Address < (0x08000000 + (FLASH_PAGE_SIZE *(indx+1))) ) && (Address >= (0x08000000 + FLASH_PAGE_SIZE*indx))){
			  return (0x08000000 + FLASH_PAGE_SIZE*indx);
		  }
	  }
	  return 0;
	}

	void float2Bytes(uint8_t * ftoa_bytes_temp,float float_variable){
	    union{
	      float a;
	      uint8_t bytes[4];
	    } thing;

	    thing.a = float_variable;

	    for (uint8_t i = 0; i < 4; i++) {
	      ftoa_bytes_temp[i] = thing.bytes[i];
	    }
	}

	float Bytes2float(uint8_t * ftoa_bytes_temp){
	    union {
	      float a;
	      uint8_t bytes[4];
	    } thing;

	    for (uint8_t i = 0; i < 4; i++) {
	    	thing.bytes[i] = ftoa_bytes_temp[i];
	    }

	   float float_variable =  thing.a;
	   return float_variable;
	}

	uint32_t write(uint32_t StartPageAddress, uint32_t *Data, uint16_t numberofwords){
		static FLASH_EraseInitTypeDef EraseInitStruct;
		uint32_t PAGEError;
		int sofar=0;

		HAL_FLASH_Unlock();

		uint32_t StartPage = getPage(StartPageAddress);
		uint32_t EndPageAdress = StartPageAddress + numberofwords*4;
		uint32_t EndPage = getPage(EndPageAdress);

		EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
		EraseInitStruct.PageAddress = StartPage;
		EraseInitStruct.NbPages     = ((EndPage - StartPage)/FLASH_PAGE_SIZE) +1;

		if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK){
		  return HAL_FLASH_GetError ();
		}

		while (sofar<numberofwords){
		 if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, StartPageAddress, Data[sofar]) == HAL_OK){
			 StartPageAddress += 4;  // use StartPageAddress += 2 for half word and 8 for double word
			 sofar++;
		 }
		 else{
			 return HAL_FLASH_GetError ();
		 }
		}

		HAL_FLASH_Lock();
		return 0;
	}


	void read(uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords){
		while (1){
			*RxBuf = *(__IO uint32_t *)StartPageAddress;
			StartPageAddress += 4;
			RxBuf++;
			if (!(numberofwords--)) break;
		}
	}

	void Convert_To_Str(uint32_t *Data, char *Buf){
		int numberofbytes = ((strlen((char *)Data)/4) + ((strlen((char *)Data) % 4) != 0)) *4;

		for (int i=0; i<numberofbytes; i++){
			Buf[i] = Data[i/4]>>(8*(i%4));
		}
	}

	void write_NUM (uint32_t StartSectorAddress, float Num){
		float2Bytes(bytes_temp, Num);
		write(StartSectorAddress, (uint32_t *)bytes_temp, 1);
	}

	float read_NUM (uint32_t StartSectorAddress){
		uint8_t buffer[4];
		float value;

		read(StartSectorAddress, (uint32_t *)buffer, 1);
		value = Bytes2float(buffer);
		return value;
	}

};



#endif /* SRC_EXTENSIONS_FLASH_H_ */
