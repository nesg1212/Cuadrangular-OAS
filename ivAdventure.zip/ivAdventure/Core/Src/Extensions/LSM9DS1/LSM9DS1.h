/*
 * LSM9DS1.h
 *
 *  Created on: 18/11/2020
 *      Author: Ing.JoseBenitez
 */

#ifndef SRC_EXTENSIONS_LSM9DS1_LSM9DS1_H_
#define SRC_EXTENSIONS_LSM9DS1_LSM9DS1_H_

#include "main.h"

#include "../../Extensions/LSM9DS1/LSM9DS1_Types.h"

#define LSM9DS1_AG_ADDR(sa0)	((sa0) == 0 ? 0x6A : 0x6B)
#define LSM9DS1_M_ADDR(sa1)		((sa1) == 0 ? 0x1C : 0x1E)

#define SENSITIVITY_ACCELEROMETER_2  0.000061
#define SENSITIVITY_ACCELEROMETER_4  0.000122
#define SENSITIVITY_ACCELEROMETER_8  0.000244
#define SENSITIVITY_ACCELEROMETER_16 0.000732
#define SENSITIVITY_GYROSCOPE_245    0.00875
#define SENSITIVITY_GYROSCOPE_500    0.0175
#define SENSITIVITY_GYROSCOPE_2000   0.07
#define SENSITIVITY_MAGNETOMETER_4   0.00014
#define SENSITIVITY_MAGNETOMETER_8   0.00029
#define SENSITIVITY_MAGNETOMETER_12  0.00043
#define SENSITIVITY_MAGNETOMETER_16  0.00058

typedef enum lsm9ds1_axis {
	X_AXIS,
	Y_AXIS,
	Z_AXIS,
	ALL_AXIS
}lsm9ds1_axis;

typedef struct accelSettings
{
	uint8_t enabled;
	uint8_t scale;
	uint8_t sampleRate;
	uint8_t enableX;
	uint8_t enableY;
	uint8_t enableZ;
	int8_t bandwidth;
	uint8_t highResEnable;
	uint8_t highResBandwidth;
}accelSettings;

typedef struct gyroSettings
{
	uint8_t enabled;
	uint16_t scale;
	uint8_t sampleRate;
	uint8_t bandwidth;
	uint8_t lowPowerEnable;
	uint8_t HPFEnable;
	uint8_t HPFCutoff;
	uint8_t flipX;
	uint8_t flipY;
	uint8_t flipZ;
	uint8_t orientation;
	uint8_t enableX;
	uint8_t enableY;
	uint8_t enableZ;
	uint8_t latchInterrupt;
}gyroSettings;

typedef struct deviceSettings
{
	uint8_t commInterface;
	uint8_t agAddress;
	uint8_t mAddress;
	I2C_HandleTypeDef *hi2c1;
}deviceSettings;

typedef struct magSettings
{
	uint8_t enabled;
	uint8_t scale;
	uint8_t sampleRate;
	uint8_t tempCompensationEnable;
	uint8_t XYPerformance;
	uint8_t ZPerformance;
	uint8_t lowPowerEnable;
	uint8_t operatingMode;
}magSettings;

typedef struct temperatureSettings
{
	uint8_t enabled;
}temperatureSettings;

typedef struct IMUSettings
{
	struct deviceSettings device;
	struct gyroSettings gyro;
	struct accelSettings accel;
	struct magSettings mag;

	struct temperatureSettings temp;
}IMUSettings;

typedef enum interrupt_select
{
	XG_INT1 = INT1_CTRL,
	XG_INT2 = INT2_CTRL
}interrupt_select;


class LSM9DS1 {
public:
	LSM9DS1();

	bool begin(uint8_t agAddress, uint8_t mAddress, I2C_HandleTypeDef *hi2c1);
	uint16_t beginSPI(uint8_t ag_CS_pin, uint8_t m_CS_pin);

	void calibrate(uint8_t autoCalc);
	void calibrateMag(uint8_t loadIn);
	void magOffset(uint8_t axis, int16_t offset);

	uint8_t accelAvailable();
	uint8_t gyroAvailable();
	uint8_t tempAvailable();
	uint8_t magAvailable(enum lsm9ds1_axis); //ALL_AXIS

	void readGyro(float *x, float *y, float *z);
	void readAccel(float *x, float *y, float *z);
	void readMag(float *x, float *y, float *z);
	float readTemp();

	float calcGyro(float gyro);
	float calcAccel(float accel);
	float calcMag(float mag);

	void setGyroScale(uint16_t gScl);
	void setAccelScale(uint8_t aScl);
	void setMagScale(uint8_t mScl);

	void setGyroODR(uint8_t gRate);
	void setAccelODR(uint8_t aRate);
	void setMagODR(uint8_t mRate);

	void configInactivity(uint8_t duration, uint8_t threshold, uint8_t sleepOn);
	void configAccelInt(uint8_t generator, uint8_t andInterrupts);
	void configAccelThs(uint8_t threshold, enum lsm9ds1_axis axis, uint8_t duration, uint8_t wait);
	void configGyroInt(uint8_t generator, uint8_t aoi, uint8_t latch);

	void configGyroThs(int16_t threshold, enum lsm9ds1_axis axis, uint8_t duration, uint8_t wait);

	void configInt();
	void configMagInt(uint8_t generator, enum h_lactive activeLow, uint8_t latch);

	void configMagThs(uint16_t threshold);

	uint8_t getGyroIntSrc();
	uint8_t getAccelIntSrc();
	uint8_t getMagIntSrc();
	uint8_t getInactivity();

	void sleepGyro(uint8_t enable);
	void enableFIFO(uint8_t enable);

	void setFIFO(enum fifoMode_type fifoMode, uint8_t fifoThs);
	uint8_t getFIFOSamples();

	uint8_t _mAddress, _xgAddress;
	uint8_t _autoCalc;

	void init();
	void initGyro();
	void initAccel();
	void initMag();

	uint8_t mReadByte(uint8_t subAddress);
	uint8_t mReadBytes(uint8_t subAddress, uint8_t * dest, uint8_t count);
	void mWriteByte(uint8_t subAddress, uint8_t data);
	uint8_t xgReadByte(uint8_t subAddress);
	uint8_t xgReadBytes(uint8_t subAddress, uint8_t * dest, uint8_t count);
	void xgWriteByte(uint8_t subAddress, uint8_t data);

	void calcgRes();
	void calcmRes();
	void calcaRes();

	void constrainScales();

	///////////////////
	// SPI Functions //
	///////////////////
	void initSPI();
	void SPIwriteByte(uint8_t csPin, uint8_t subAddress, uint8_t data);
	uint8_t SPIreadByte(uint8_t csPin, uint8_t subAddress);
	uint8_t SPIreadBytes(uint8_t csPin, uint8_t subAddress,uint8_t * dest, uint8_t count);

	///////////////////
	// I2C Functions //
	///////////////////

	void I2CwriteByte(uint8_t address, uint8_t subAddress, uint8_t data);
	uint8_t I2CreadByte(uint8_t address, uint8_t subAddress);
	uint8_t I2CreadBytes(uint8_t address, uint8_t subAddress, uint8_t * dest, uint8_t count);
};

#endif /* SRC_EXTENSIONS_LSM9DS1_LSM9DS1_H_ */
