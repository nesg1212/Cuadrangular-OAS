/*
 * LSM9DS1.cpp
 *
 *  Created on: 18/11/2020
 *      Author: Ing.JoseBenitez
 */

#include "../../Extensions/LSM9DS1/LSM9DS1.h"

LSM9DS1::LSM9DS1() {}

float gRes, aRes, mRes;

struct IMUSettings settings;

void LSM9DS1::init()
{
	int16_t gBiasRaw[3], aBiasRaw[3], mBiasRaw[3];
	float gBias[3], aBias[3], mBias[3];
	settings.gyro.enabled = 1;
	settings.gyro.enableX = 1;
	settings.gyro.enableY = 1;
	settings.gyro.enableZ = 1;
	settings.gyro.scale = 245;
	settings.gyro.sampleRate = 6;
	settings.gyro.bandwidth = 0;
	settings.gyro.lowPowerEnable = 0;
	settings.gyro.HPFEnable = 0;
	settings.gyro.HPFCutoff = 0;
	settings.gyro.flipX = 0;
	settings.gyro.flipY = 0;
	settings.gyro.flipZ = 0;
	settings.gyro.orientation = 0;
	settings.gyro.latchInterrupt = 1;

	settings.accel.enabled = 1;
	settings.accel.enableX = 1;
	settings.accel.enableY = 1;
	settings.accel.enableZ = 1;
	settings.accel.scale = 2;
	settings.accel.sampleRate = 6;
	settings.accel.bandwidth = -1;
	settings.accel.highResEnable = 0;
	settings.accel.highResBandwidth = 0;

	settings.mag.enabled = 1;
	settings.mag.scale = 4;
	settings.mag.sampleRate = 7;
	settings.mag.tempCompensationEnable = 0;
	settings.mag.XYPerformance = 3;
	settings.mag.ZPerformance = 3;
	settings.mag.lowPowerEnable = 0;
	settings.mag.operatingMode = 0;

	settings.temp.enabled = 1;

	for (int i=0; i<3; i++)
	{
		gBias[i] = 0;
		aBias[i] = 0;
		mBias[i] = 0;
		gBiasRaw[i] = 0;
		aBiasRaw[i] = 0;
		mBiasRaw[i] = 0;
	}
	_autoCalc = 0;
}

bool LSM9DS1::begin(uint8_t agAddress, uint8_t mAddress, I2C_HandleTypeDef *hi2c1)
{
	settings.device.commInterface = IMU_MODE_I2C;
	settings.device.agAddress = agAddress;
	settings.device.mAddress = mAddress;
	settings.device.hi2c1 = hi2c1;

	_xgAddress = settings.device.agAddress;
	_mAddress = settings.device.mAddress;

	init();

	constrainScales();
	calcgRes();
	calcmRes();
	calcaRes();

	uint8_t mTest = mReadByte(WHO_AM_I_M);
	uint8_t xgTest = xgReadByte(WHO_AM_I_XG);
	uint16_t whoAmICombined = (xgTest << 8) | mTest;

	if (whoAmICombined != ((WHO_AM_I_AG_RSP << 8) | WHO_AM_I_M_RSP))
		return false;

	initGyro();
	initAccel();
	initMag();

	return true;
}

void LSM9DS1::initGyro()
{
	uint8_t tempRegValue = 0;

	if (settings.gyro.enabled)
	{
		tempRegValue = (settings.gyro.sampleRate & 0x07) << 5;
	}
	switch (settings.gyro.scale)
	{
		case 500:
			tempRegValue |= (0x1 << 3);
			break;
		case 2000:
			tempRegValue |= (0x3 << 3);
			break;
	}
	tempRegValue |= (settings.gyro.bandwidth & 0x3);
	xgWriteByte(CTRL_REG1_G, tempRegValue);
	xgWriteByte(CTRL_REG2_G, 0x00);

	tempRegValue = settings.gyro.lowPowerEnable ? (1<<7) : 0;
	if (settings.gyro.HPFEnable)
	{
		tempRegValue |= (1<<6) | (settings.gyro.HPFCutoff & 0x0F);
	}
	xgWriteByte(CTRL_REG3_G, tempRegValue);

	tempRegValue = 0;
	if (settings.gyro.enableZ) tempRegValue |= (1<<5);
	if (settings.gyro.enableY) tempRegValue |= (1<<4);
	if (settings.gyro.enableX) tempRegValue |= (1<<3);
	if (settings.gyro.latchInterrupt) tempRegValue |= (1<<1);
	xgWriteByte(CTRL_REG4, tempRegValue);

	tempRegValue = 0;
	if (settings.gyro.flipX) tempRegValue |= (1<<5);
	if (settings.gyro.flipY) tempRegValue |= (1<<4);
	if (settings.gyro.flipZ) tempRegValue |= (1<<3);
	xgWriteByte(ORIENT_CFG_G, tempRegValue);
}

void LSM9DS1::initAccel()
{
	uint8_t tempRegValue = 0;

	if (settings.accel.enableZ) tempRegValue |= (1<<5);
	if (settings.accel.enableY) tempRegValue |= (1<<4);
	if (settings.accel.enableX) tempRegValue |= (1<<3);

	xgWriteByte(CTRL_REG5_XL, tempRegValue);

	tempRegValue = 0;
	if (settings.accel.enabled)
	{
		tempRegValue |= (settings.accel.sampleRate & 0x07) << 5;
	}
	switch (settings.accel.scale)
	{
		case 4:
			tempRegValue |= (0x2 << 3);
			break;
		case 8:
			tempRegValue |= (0x3 << 3);
			break;
		case 16:
			tempRegValue |= (0x1 << 3);
			break;
	}
	if (settings.accel.bandwidth >= 0)
	{
		tempRegValue |= (1<<2); // Set BW_SCAL_ODR
		tempRegValue |= (settings.accel.bandwidth & 0x03);
	}
	xgWriteByte(CTRL_REG6_XL, tempRegValue);

	tempRegValue = 0;
	if (settings.accel.highResEnable)
	{
		tempRegValue |= (1<<7); // Set HR bit
		tempRegValue |= (settings.accel.highResBandwidth & 0x3) << 5;
	}
	xgWriteByte(CTRL_REG7_XL, tempRegValue);
}

void LSM9DS1::calibrate(uint8_t autoCalc)
{

}

void LSM9DS1::calibrateMag(uint8_t loadIn)
{

}
void LSM9DS1::magOffset(uint8_t axis, int16_t offset)
{
	if (axis > 2)
		return;
	uint8_t msb, lsb;
	msb = (offset & 0xFF00) >> 8;
	lsb = offset & 0x00FF;
	mWriteByte(OFFSET_X_REG_L_M + (2 * axis), lsb);
	mWriteByte(OFFSET_X_REG_H_M + (2 * axis), msb);
}

void LSM9DS1::initMag()
{
	uint8_t tempRegValue = 0;

	if (settings.mag.tempCompensationEnable) tempRegValue |= (1<<7);
	tempRegValue |= (settings.mag.XYPerformance & 0x3) << 5;
	tempRegValue |= (settings.mag.sampleRate & 0x7) << 2;
	mWriteByte(CTRL_REG1_M, tempRegValue);

	tempRegValue = 0;
	switch (settings.mag.scale)
	{
	case 8:
		tempRegValue |= (0x1 << 5);
		break;
	case 12:
		tempRegValue |= (0x2 << 5);
		break;
	case 16:
		tempRegValue |= (0x3 << 5);
		break;
	}
	mWriteByte(CTRL_REG2_M, tempRegValue); // +/-4Gauss

	tempRegValue = 0;
	if (settings.mag.lowPowerEnable) tempRegValue |= (1<<5);
	tempRegValue |= (settings.mag.operatingMode & 0x3);
	mWriteByte(CTRL_REG3_M, tempRegValue); // Continuous conversion mode

	tempRegValue = 0;
	tempRegValue = (settings.mag.ZPerformance & 0x3) << 2;
	mWriteByte(CTRL_REG4_M, tempRegValue);

	tempRegValue = 0;
	mWriteByte(CTRL_REG5_M, tempRegValue);
}

uint8_t LSM9DS1::accelAvailable()
{
	uint8_t status = xgReadByte(STATUS_REG_1);

	return (status & (1<<0));
}

uint8_t LSM9DS1::gyroAvailable()
{
	uint8_t status = xgReadByte(STATUS_REG_1);

	return ((status & (1<<1)) >> 1);
}

uint8_t LSM9DS1::tempAvailable()
{
	uint8_t status = xgReadByte(STATUS_REG_1);

	return ((status & (1<<2)) >> 2);
}

uint8_t LSM9DS1::magAvailable(enum lsm9ds1_axis axis)
{
	uint8_t status;
	status = mReadByte(STATUS_REG_M);

	return ((status & (1<<axis)) >> axis);
}

void LSM9DS1::readAccel(float *x, float *y, float *z)
{

	int16_t ax, ay, az;
	uint8_t temp[6];
	if ( xgReadBytes(OUT_X_L_XL, temp, 6) == 6 )
	{
		ax = (temp[1] << 8) | temp[0];
		ay = (temp[3] << 8) | temp[2];
		az = (temp[5] << 8) | temp[4];
	}
	*x = calcAccel(ax);
	*y = calcAccel(ay);
	*z = calcAccel(az);

}

void LSM9DS1::readMag(float *x, float *y, float *z)
{
	int16_t mx, my, mz;
	uint8_t temp[6];
	if ( mReadBytes(OUT_X_L_M, temp, 6) == 6)
	{
		mx = (temp[1] << 8) | temp[0];
		my = (temp[3] << 8) | temp[2];
		mz = (temp[5] << 8) | temp[4];
	}
	*x = calcMag(mx);
	*y = calcMag(my);
	*z = calcMag(mz);
}

float LSM9DS1::readTemp()
{
	int16_t temperature;
	uint8_t temp[2];
	if ( xgReadBytes(OUT_TEMP_L, temp, 2) == 2 )
	{
		int16_t offset = 25;
		temperature = offset + ((((int16_t)temp[1] << 8) | temp[0]) >> 8) ;
	}
	return temperature;
}

void LSM9DS1::readGyro(float *x, float *y, float *z)
{
	int16_t gx, gy, gz;
	uint8_t temp[6];
	if ( xgReadBytes(OUT_X_L_G, temp, 6) == 6)
	{
		gx = (temp[1] << 8) | temp[0];
		gy = (temp[3] << 8) | temp[2];
		gz = (temp[5] << 8) | temp[4];
	}
	*x = calcGyro(gx);
	*y = calcGyro(gy);
	*z = calcGyro(gz);
}

float LSM9DS1::calcGyro(float gyro)
{
	return gyro*gRes;
}

float LSM9DS1::calcAccel(float accel)
{
	return accel*aRes;
}

float LSM9DS1::calcMag(float mag)
{
	return mag * mRes;
}

void LSM9DS1::setGyroScale(uint16_t gScl)
{
	uint8_t ctrl1RegValue = xgReadByte(CTRL_REG1_G);
	ctrl1RegValue &= 0xE7;
	switch (gScl)
	{
		case 500:
			ctrl1RegValue |= (0x1 << 3);
			settings.gyro.scale = 500;
			break;
		case 2000:
			ctrl1RegValue |= (0x3 << 3);
			settings.gyro.scale = 2000;
			break;
		default:
			settings.gyro.scale = 245;
			break;
	}
	xgWriteByte(CTRL_REG1_G, ctrl1RegValue);

	calcgRes();
}

void LSM9DS1::setAccelScale(uint8_t aScl)
{
	uint8_t tempRegValue = xgReadByte(CTRL_REG6_XL);
	tempRegValue &= 0xE7;

	switch (aScl)
	{
		case 4:
			tempRegValue |= (0x2 << 3);
			settings.accel.scale = 4;
			break;
		case 8:
			tempRegValue |= (0x3 << 3);
			settings.accel.scale = 8;
			break;
		case 16:
			tempRegValue |= (0x1 << 3);
			settings.accel.scale = 16;
			break;
		default:
			settings.accel.scale = 2;
			break;
	}
	xgWriteByte(CTRL_REG6_XL, tempRegValue);

	calcaRes();
}

void LSM9DS1::setMagScale(uint8_t mScl)
{
	uint8_t temp = mReadByte(CTRL_REG2_M);
	temp &= 0xFF^(0x3 << 5);
	switch (mScl)
	{
	case 8:
		temp |= (0x1 << 5);
		settings.mag.scale = 8;
		break;
	case 12:
		temp |= (0x2 << 5);
		settings.mag.scale = 12;
		break;
	case 16:
		temp |= (0x3 << 5);
		settings.mag.scale = 16;
		break;
	default:
		settings.mag.scale = 4;
		break;
	}

	mWriteByte(CTRL_REG2_M, temp);
	calcmRes();
}

void LSM9DS1::setGyroODR(uint8_t gRate)
{
	if ((gRate & 0x07) != 0)
	{
		uint8_t temp = xgReadByte(CTRL_REG1_G);
		temp &= 0xFF^(0x7 << 5);
		temp |= (gRate & 0x07) << 5;
		settings.gyro.sampleRate = gRate & 0x07;
		xgWriteByte(CTRL_REG1_G, temp);
	}
}

void LSM9DS1::setAccelODR(uint8_t aRate)
{
	if ((aRate & 0x07) != 0)
	{
		uint8_t temp = xgReadByte(CTRL_REG6_XL);
		temp &= 0x1F;
		temp |= ((aRate & 0x07) << 5);
		settings.accel.sampleRate = aRate & 0x07;
		xgWriteByte(CTRL_REG6_XL, temp);
	}
}

void LSM9DS1::setMagODR(uint8_t mRate)
{
	uint8_t temp = mReadByte(CTRL_REG1_M);
	temp &= 0xFF^(0x7 << 2);
	temp |= ((mRate & 0x07) << 2);
	settings.mag.sampleRate = mRate & 0x07;
	mWriteByte(CTRL_REG1_M, temp);
}

void LSM9DS1::calcgRes()
{
	switch (settings.gyro.scale)
	{
	case 245:
		gRes = SENSITIVITY_GYROSCOPE_245;
		break;
	case 500:
		gRes = SENSITIVITY_GYROSCOPE_500;
		break;
	case 2000:
		gRes = SENSITIVITY_GYROSCOPE_2000;
		break;
	default:
		break;
	}
}

void LSM9DS1::calcaRes()
{
	switch (settings.accel.scale)
	{
	case 2:
		aRes = SENSITIVITY_ACCELEROMETER_2;
		break;
	case 4:
		aRes = SENSITIVITY_ACCELEROMETER_4;
		break;
	case 8:
		aRes = SENSITIVITY_ACCELEROMETER_8;
		break;
	case 16:
		aRes = SENSITIVITY_ACCELEROMETER_16;
		break;
	default:
		break;
	}
}

void LSM9DS1::calcmRes()
{
	switch (settings.mag.scale)
	{
	case 4:
		mRes = SENSITIVITY_MAGNETOMETER_4;
		break;
	case 8:
		mRes = SENSITIVITY_MAGNETOMETER_8;
		break;
	case 12:
		mRes = SENSITIVITY_MAGNETOMETER_12;
		break;
	case 16:
		mRes = SENSITIVITY_MAGNETOMETER_16;
		break;
	}
}


void LSM9DS1::configInactivity(uint8_t duration, uint8_t threshold, uint8_t sleepOn)
{
	uint8_t temp = 0;

	temp = threshold & 0x7F;
	if (sleepOn) temp |= (1<<7);
	xgWriteByte(ACT_THS, temp);

	xgWriteByte(ACT_DUR, duration);
}

uint8_t LSM9DS1::getInactivity()
{
	uint8_t temp = xgReadByte(STATUS_REG_0);
	temp &= (0x10);
	return temp;
}

void LSM9DS1::configAccelInt(uint8_t generator, uint8_t andInterrupts)
{
	uint8_t temp = generator;
	if (andInterrupts) temp |= 0x80;
	xgWriteByte(INT_GEN_CFG_XL, temp);
}

void LSM9DS1::configAccelThs(uint8_t threshold, enum lsm9ds1_axis axis, uint8_t duration, uint8_t  wait)
{
	xgWriteByte(INT_GEN_THS_X_XL + axis, threshold);

	uint8_t temp;
	temp = (duration & 0x7F);
	if (wait) temp |= 0x80;
	xgWriteByte(INT_GEN_DUR_XL, temp);
}

uint8_t LSM9DS1::getAccelIntSrc()
{
	uint8_t intSrc = xgReadByte(INT_GEN_SRC_XL);

	if (intSrc & (1<<6))
	{
		return (intSrc & 0x3F);
	}

	return 0;
}

void LSM9DS1::configGyroInt(uint8_t generator, uint8_t aoi, uint8_t latch)
{
	uint8_t temp = generator;
	if (aoi) temp |= 0x80;
	if (latch) temp |= 0x40;
	xgWriteByte(INT_GEN_CFG_G, temp);
}

void LSM9DS1::configGyroThs(int16_t threshold, enum lsm9ds1_axis axis, uint8_t duration, uint8_t wait)
{
	uint8_t buffer[2];
	buffer[0] = (threshold & 0x7F00) >> 8;
	buffer[1] = (threshold & 0x00FF);
	xgWriteByte(INT_GEN_THS_XH_G + (axis * 2), buffer[0]);
	xgWriteByte(INT_GEN_THS_XH_G + 1 + (axis * 2), buffer[1]);

	uint8_t temp;
	temp = (duration & 0x7F);
	if (wait) temp |= 0x80;
	xgWriteByte(INT_GEN_DUR_G, temp);
}

uint8_t LSM9DS1::getGyroIntSrc()
{
	uint8_t intSrc = xgReadByte(INT_GEN_SRC_G);

	if (intSrc & (1<<6))
	{
		return (intSrc & 0x3F);
	}

	return 0;
}

void LSM9DS1::configMagInt(uint8_t generator, enum h_lactive activeLow, uint8_t latch)
{
	uint8_t config = (generator & 0xE0);
	if (activeLow == INT_ACTIVE_HIGH) config |= (1<<2);
	if (!latch) config |= (1<<1);
	if (generator != 0) config |= (1<<0);

	mWriteByte(INT_CFG_M, config);
}

void LSM9DS1::configMagThs(uint16_t threshold)
{
	mWriteByte(INT_THS_H_M, (uint8_t)((threshold & 0x7F00) >> 8));
	mWriteByte(INT_THS_L_M, (uint8_t)(threshold & 0x00FF));
}

uint8_t LSM9DS1::getMagIntSrc()
{
	uint8_t intSrc = mReadByte(INT_SRC_M);

	if (intSrc & (1<<0))
	{
		return (intSrc & 0xFE);
	}

	return 0;
}

void LSM9DS1::sleepGyro(uint8_t enable)
{
	uint8_t temp = xgReadByte(CTRL_REG9);
	if (enable) temp |= (1<<6);
	else temp &= ~(1<<6);
	xgWriteByte(CTRL_REG9, temp);
}

void LSM9DS1::enableFIFO(uint8_t enable)
{
	uint8_t temp = xgReadByte(CTRL_REG9);
	if (enable) temp |= (1<<1);
	else temp &= ~(1<<1);
	xgWriteByte(CTRL_REG9, temp);
}

void LSM9DS1::setFIFO(enum fifoMode_type fifoMode, uint8_t fifoThs)
{
	uint8_t threshold = fifoThs <= 0x1F ? fifoThs : 0x1F;
	xgWriteByte(FIFO_CTRL, ((fifoMode & 0x7) << 5) | (threshold & 0x1F));
}

uint8_t LSM9DS1::getFIFOSamples()
{
	return (xgReadByte(FIFO_SRC) & 0x3F);
}

void LSM9DS1::constrainScales()
{
	if ((settings.gyro.scale != 245) && (settings.gyro.scale != 500) &&
		(settings.gyro.scale != 2000))
	{
		settings.gyro.scale = 245;
	}

	if ((settings.accel.scale != 2) && (settings.accel.scale != 4) &&
		(settings.accel.scale != 8) && (settings.accel.scale != 16))
	{
		settings.accel.scale = 2;
	}

	if ((settings.mag.scale != 4) && (settings.mag.scale != 8) &&
		(settings.mag.scale != 12) && (settings.mag.scale != 16))
	{
		settings.mag.scale = 4;
	}
}

void LSM9DS1::xgWriteByte(uint8_t subAddress, uint8_t data)
{
	if (settings.device.commInterface == IMU_MODE_I2C)
		I2CwriteByte(_xgAddress, subAddress, data);
	else if (settings.device.commInterface == IMU_MODE_SPI)
		SPIwriteByte(_xgAddress, subAddress, data);
}

void LSM9DS1::mWriteByte(uint8_t subAddress, uint8_t data)
{
	if (settings.device.commInterface == IMU_MODE_I2C)
		I2CwriteByte(_mAddress, subAddress, data);
	else if (settings.device.commInterface == IMU_MODE_SPI)
		SPIwriteByte(_mAddress, subAddress, data);
}

uint8_t LSM9DS1::xgReadByte(uint8_t subAddress)
{
	if (settings.device.commInterface == IMU_MODE_I2C)
		return I2CreadByte(_xgAddress, subAddress);
	else if (settings.device.commInterface == IMU_MODE_SPI)
		return SPIreadByte(_xgAddress, subAddress);
	return -1;
}

uint8_t LSM9DS1::xgReadBytes(uint8_t subAddress, uint8_t * dest, uint8_t count)
{
	if (settings.device.commInterface == IMU_MODE_I2C)
		return I2CreadBytes(_xgAddress, subAddress, dest, count);
	else if (settings.device.commInterface == IMU_MODE_SPI)
		return SPIreadBytes(_xgAddress, subAddress, dest, count);
	return -1;
}

uint8_t LSM9DS1::mReadByte(uint8_t subAddress)
{
	if (settings.device.commInterface == IMU_MODE_I2C)
		return I2CreadByte(_mAddress, subAddress);
	else if (settings.device.commInterface == IMU_MODE_SPI)
		return SPIreadByte(_mAddress, subAddress);
	return -1;
}

uint8_t LSM9DS1::mReadBytes(uint8_t subAddress, uint8_t * dest, uint8_t count)
{
	if (settings.device.commInterface == IMU_MODE_I2C)
		return I2CreadBytes(_mAddress, subAddress, dest, count);
	else if (settings.device.commInterface == IMU_MODE_SPI)
		return SPIreadBytes(_mAddress, subAddress, dest, count);
	return -1;
}

void LSM9DS1::initSPI()
{
	return;
}

void LSM9DS1::SPIwriteByte(uint8_t csPin, uint8_t subAddress, uint8_t data)
{
	return;
}

uint8_t LSM9DS1::SPIreadByte(uint8_t csPin, uint8_t subAddress)
{
return 0;
}

uint8_t LSM9DS1::SPIreadBytes(uint8_t csPin, uint8_t subAddress,
							uint8_t * dest, uint8_t count)
{
return 0;
}

void LSM9DS1::I2CwriteByte(uint8_t address, uint8_t subAddress, uint8_t data)
{
	uint8_t buffer[2] = {subAddress, data};
	HAL_I2C_Master_Transmit(settings.device.hi2c1, address<<1, buffer, 2, 100);
}

uint8_t LSM9DS1::I2CreadByte(uint8_t address, uint8_t subAddress)
{
	uint8_t buffer = subAddress;
	uint8_t readBuffer; // `data` will store the register data
	HAL_I2C_Master_Transmit(settings.device.hi2c1, address<<1, &buffer, 1, 100);
	HAL_I2C_Master_Receive(settings.device.hi2c1, address<<1, &readBuffer, 1,100);
	return readBuffer;
}

uint8_t LSM9DS1::I2CreadBytes(uint8_t address, uint8_t subAddress, uint8_t * dest, uint8_t count)
{
	uint8_t buffer = subAddress; //subAddress | 0x80
	HAL_I2C_Master_Transmit(settings.device.hi2c1, address<<1, &buffer, 1, 100);
	HAL_I2C_Master_Receive(settings.device.hi2c1, address<<1, dest, count,100);
	return count;
}
