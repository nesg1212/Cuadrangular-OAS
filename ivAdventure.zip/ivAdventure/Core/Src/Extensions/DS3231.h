/*
 * DS3231.h
 *
 *  Created on: 26 ago. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_EXTENSIONS_DS3231_H_
#define SRC_EXTENSIONS_DS3231_H_

typedef struct{
	uint8_t seconds;
	uint8_t minutes;
	uint8_t hour;
	uint8_t dayWeek;
	uint8_t dayMonth;
	uint8_t month;
	uint8_t year;
	bool isValid;
}TIME;

typedef enum{
	LUNES,
	MARTES,
	MIERCOLES,
	JUEVES,
	VIERNES,
	SABADO,
	DOMINGO
}DAY_OF_WEEK;

class DS3231{
private:
	uint8_t Address;
	I2C_HandleTypeDef *hi2cI;
	TIME time;

	uint8_t decToBcd(int val){
	  return (uint8_t)( (val/10*16) + (val%10) );
	}

	int bcdToDec(uint8_t val){
	  return (int)( (val/16*10) + (val%16) );
	}

public:
	DS3231(){}

	bool init(I2C_HandleTypeDef *hi2c, uint8_t Address_){
		Address=Address_<<1;
		hi2cI = hi2c;

		if(!HAL_I2C_IsDeviceReady(hi2cI, Address, 1, 10) == HAL_OK){
				return(false);
		}
		return(true);
	}

	void setTime(uint8_t hour, uint8_t min, uint8_t sec, DAY_OF_WEEK dayW, uint8_t dayM, uint8_t month, uint8_t year)
	{
		uint8_t set_time[7];

		set_time[0] = decToBcd(sec);
		set_time[1] = decToBcd(min);
		set_time[2] = decToBcd(hour);
		set_time[3] = decToBcd((uint8_t)dayW);
		set_time[4] = decToBcd(dayM);
		set_time[5] = decToBcd(month);
		set_time[6] = decToBcd(year);

		HAL_I2C_Mem_Write(hi2cI, Address, 0x00, 1, set_time, 7, 50);
	}

	TIME getTime(void)
	{
		uint8_t get_time[7];

		if(!HAL_I2C_IsDeviceReady(hi2cI, Address, 1, 10) == HAL_OK){
			time.isValid = false;
			return(time);
		}
		HAL_I2C_Mem_Read(hi2cI, Address, 0x00, 1, get_time, 7, 1000);
		time.isValid = true;
		time.seconds = bcdToDec(get_time[0]);
		time.minutes = bcdToDec(get_time[1]);
		time.hour = bcdToDec(get_time[2]);
		time.dayWeek = bcdToDec(get_time[3]);
		time.dayMonth = bcdToDec(get_time[4]);
		time.month = bcdToDec(get_time[5]);
		time.year = bcdToDec(get_time[6]);

		return(time);
	}

};

#endif /* SRC_EXTENSIONS_DS3231_H_ */
