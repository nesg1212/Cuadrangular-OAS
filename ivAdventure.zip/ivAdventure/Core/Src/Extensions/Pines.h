/*
 * Pines.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

/* Private defines -----------------------------------------------------------*/

#ifndef SRC_EXTENSIONS_PINES_H_
#define SRC_EXTENSIONS_PINES_H_



#ifdef __cplusplus
extern "C"
{
#endif


#if defined(STM32F411xE)

#include "stm32f4xx_hal.h"

#define MASTER_MODE 0
#define SLAVE_MODE 1
/*
 ************************** DIRECCIONES I2C ***************************
 */
#define STM32_MASTER_ADDRESS 0x01
#define STM32_SLAVE_ADDRESS 0x12
#define OLED1_ADDRESS 0x78	   // default, por hardware se puede cambiar a 0x7A con address selector
#define EEPROM1_ADDRESS 0x50   // Direccion seleccionada por hardware ivAdventure
#define RTC1_ADDRESS 0x68	   // Direccion seleccionada por hardware ivAdventure
#define BME280_1_ADDRESS 0x76  // default, por hardware se puede cambiar a 0x77 con SDO en LOW
#define ADS1115_1_ADDRESS 0x48 // con ADDR - GND ...

#define ACC_GIRO_ADDRESS 0x6B
#define MAG_ADDRESS 0x1E
/*
 ************************* DEFINICIONES SPI ***************************
 */
#define SPI_SPEED_21MHZ SPI_BAUDRATEPRESCALER_2
/*
 ************************ DEFINICIONES MODBUS *************************
 */
#define ID_MASTER 0
#define ID_SLAVE 1
#define RS485_EN_PIN GPIO_PIN_0
#define RS485_EN_PORT GPIOC
/*
 ***************************** PINES **********************************
 */
#define UART1_TX_Pin GPIO_PIN_9	 // Definicion no utilizada, solo para referencia;
#define UART1_RX_Pin GPIO_PIN_10 // Definicion no utilizada, solo para referencia;
#define UART1_GPIO_PORT GPIOA	 // Definicion no utilizada, solo para referencia;

#define UART2_TX_Pin GPIO_PIN_2 // Definicion no utilizada, solo para referencia
#define UART2_RX_Pin GPIO_PIN_3 // Definicion no utilizada, solo para referencia
#define UART2_GPIO_PORT GPIOA	// Definicion no utilizada, solo para referencia

#define UART6_TX_Pin GPIO_PIN_11 // Definicion no utilizada, solo para referencia
#define UART6_RX_Pin GPIO_PIN_12 // Definicion no utilizada, solo para referencia
#define UART6_GPIO_PORT GPIOA	 // Definicion no utilizada, solo para referencia

#define SPI2_MISO_PIN GPIO_PIN_11 // Definicion no utilizada, solo para referencia
#define SPI2_MISO_PORT GPIOC	  // Definicion no utilizada, solo para referencia
#define SPI2_MOSI_PIN GPIO_PIN_12 // Definicion no utilizada, solo para referencia
#define SPI2_MOSI_PORT GPIOC	  // Definicion no utilizada, solo para referencia
#define SPI2_SCK_PIN GPIO_PIN_10  // Definicion no utilizada, solo para referencia
#define SPI2_SCK_PORT GPIOC		  // Definicion no utilizada, solo para referencia

#define I2C1_SCL_PIN GPIO_PIN_8
#define I2C1_SDA_PIN GPIO_PIN_9
#define I2C1_PORT GPIOB

#define I2C3_SCL_PIN GPIO_PIN_8
#define I2C3_SCL_PORT GPIOA
#define I2C3_SDA_PIN GPIO_PIN_9
#define I2C3_SDA_PORT GPIOC

#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA

#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA

#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB

#define ONEWIRE_Pin GPIO_PIN_6
#define ONEWIRE_GPIO_Port GPIOB

#define MUX1_PIN_SA GPIO_PIN_0
#define MUX1_PORT_SA GPIOC
#define MUX1_PIN_SB GPIO_PIN_1
#define MUX1_PORT_SB GPIOC
#define MUX1_PIN_SC GPIO_PIN_0
#define MUX1_PORT_SC GPIOB
#define MUX1_PIN_SD GPIO_PIN_4
#define MUX1_PORT_SD GPIOA
#define MUX1_PIN_ENABLE GPIO_PIN_1
#define MUX1_PORT_ENABLE GPIOA
#define MUX1_PIN_OUT GPIO_PIN_0 // Definicion no utilizada, solo para referencia; ADC_CHANNEL_0
#define MUX1_PORT_OUT GPIOA		// Definicion no utilizada, solo para referencia; ADC_CHANNEL_0

#define THERMOCOUPLE1_PIN_SS GPIO_PIN_4
#define THERMOCOUPLE1_PORT_SS GPIOB

#define DIGITAL_INPUT_1_PIN GPIO_PIN_13
#define DIGITAL_INPUT_1_PORT GPIOB
#define DIGITAL_INPUT_2_PIN GPIO_PIN_14
#define DIGITAL_INPUT_2_PORT GPIOB
#define DIGITAL_INPUT_3_PIN GPIO_PIN_15
#define DIGITAL_INPUT_3_PORT GPIOB
#define DIGITAL_INPUT_4_PIN GPIO_PIN_1
#define DIGITAL_INPUT_4_PORT GPIOB

#define RPM_INPUT_1_PIN GPIO_PIN_15
#define RPM_INPUT_1_PORT GPIOA
#define RPM_INPUT_2_PIN GPIO_PIN_3
#define RPM_INPUT_2_PORT GPIOB
#define RPM_INPUT_3_PIN GPIO_PIN_10
#define RPM_INPUT_3_PORT GPIOB
#define RPM_INPUT_4_PIN GPIO_PIN_1
#define RPM_INPUT_4_PORT GPIOB

#define DIGITAL_OUTPUT_1_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_1_PORT GPIOA
#define DIGITAL_OUTPUT_2_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_2_PORT GPIOA
#define DIGITAL_OUTPUT_3_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_3_PORT GPIOA
#define DIGITAL_OUTPUT_4_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_4_PORT GPIOA
#define DIGITAL_OUTPUT_5_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_5_PORT GPIOA
#define DIGITAL_OUTPUT_6_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_6_PORT GPIOA
#define DIGITAL_OUTPUT_7_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_7_PORT GPIOA
#define DIGITAL_OUTPUT_8_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_8_PORT GPIOA
#define DIGITAL_OUTPUT_9_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_9_PORT GPIOA
#define DIGITAL_OUTPUT_10_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_10_PORT GPIOA
#define DIGITAL_OUTPUT_11_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_11_PORT GPIOA
#define DIGITAL_OUTPUT_12_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_12_PORT GPIOA
#define DIGITAL_OUTPUT_13_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_13_PORT GPIOA
#define DIGITAL_OUTPUT_14_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_14_PORT GPIOA
#define DIGITAL_OUTPUT_15_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_15_PORT GPIOA
#define DIGITAL_OUTPUT_16_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_16_PORT GPIOA
#define DIGITAL_OUTPUT_17_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_17_PORT GPIOA
#define DIGITAL_OUTPUT_18_PIN GPIO_PIN_1
#define DIGITAL_OUTPUT_18_PORT GPIOA

#define ELECTROVENTILADOR_OUTPUT_1_PIN GPIO_PIN_5
#define ELECTROVENTILADOR_OUTPUT_1_PORT GPIOA
#define ELECTROVENTILADOR_OUTPUT_2_PIN GPIO_PIN_1
#define ELECTROVENTILADOR_OUTPUT_2_PORT GPIOA
#define ELECTROVENTILADOR_OUTPUT_3_PIN GPIO_PIN_1
#define ELECTROVENTILADOR_OUTPUT_3_PORT GPIOA
#define ELECTROVENTILADOR_OUTPUT_4_PIN GPIO_PIN_1
#define ELECTROVENTILADOR_OUTPUT_4_PORT GPIOA

#define LORA_DIO0_PIN GPIO_PIN_0
#define LORA_DIO0_GPIO_PORT GPIOB
#define LORA_RESET_PIN GPIO_PIN_1
#define LORA_RESET_GPIO_PORT GPIOB
#define LORA_NSS_PIN GPIO_PIN_2
#define LORA_NSS_GPIO_PORT GPIOB
#define LORA_MODE_PIN GPIO_PIN_3
#define LORA_MODE_GPIO_PORT GPIOB

#define MICRO_SD_PIN GPIO_PIN_2
#define MICRO_SD_GPIO_PORT GPIOD

#define RST_SYNC_PIN GPIO_PIN_7
#define RST_SYNC_PORT GPIOC

#elif defined(STM32F107xC)

#include "stm32f1xx_hal.h"
#define MASTER_MODE 0
#define SLAVE_MODE 1
/*
 ************************** DIRECCIONES I2C ***************************
 */
#define STM32_MASTER_ADDRESS 0x01
#define STM32_SLAVE_ADDRESS 0x12
#define OLED1_ADDRESS 0x78	   // default, por hardware se puede cambiar a 0x7A con address selector
#define EEPROM1_ADDRESS 0x50   // Direccion seleccionada por hardware ivAdventure
#define RTC1_ADDRESS 0x68	   // Direccion seleccionada por hardware ivAdventure
#define BME280_1_ADDRESS 0x76  // default, por hardware se puede cambiar a 0x77 con SDO en LOW
#define ADS1115_1_ADDRESS 0x48 // con ADDR - GND ...
#define LM75_ADDRESS 0x48 // MINI ---> A0->GND, A1->GND and A2->GND

#define ACC_GIRO_ADDRESS 0x6B
#define MAG_ADDRESS 0x1E
/*
 ************************* DEFINICIONES SPI ***************************
 */
#define SPI_SPEED_18MHZ SPI_BAUDRATEPRESCALER_2
#define SPI_ADXL_ADDRESS 0x53
/*
 ************************ DEFINICIONES MODBUS *************************
 */
#define ID_MASTER 0
#define ID_SLAVE 1
#define RS485_EN_PIN GPIO_PIN_0
#define RS485_EN_PORT GPIOC
/*
 ***************************** PINES **********************************
 */

/*UART1 Actualizado ivMini*/
#define UART1_TX_Pin GPIO_PIN_6	 // Definicion no utilizada, solo para referencia;
#define UART1_RX_Pin GPIO_PIN_7 // Definicion no utilizada, solo para referencia;
#define UART1_GPIO_PORT GPIOB	 // Definicion no utilizada, solo para referencia;

/*UART2 Actualizado ivMini*/
#define UART2_TX_Pin GPIO_PIN_6 // Definicion no utilizada, solo para referencia
#define UART2_RX_Pin GPIO_PIN_7 // Definicion no utilizada, solo para referencia
#define UART2_GPIO_PORT GPIOB	// Definicion no utilizada, solo para referencia

/*UART3 creado ivMini*/
#define UART3_TX_Pin GPIO_PIN_10 // Definicion no utilizada, solo para referencia;
#define UART3_RX_Pin GPIO_PIN_11 // Definicion no utilizada, solo para referencia;
#define UART3_GPIO_PORT GPIOB	 // Definicion no utilizada, solo para referencia;

#define UART6_TX_Pin GPIO_PIN_11 // Definicion no utilizada, solo para referencia
#define UART6_RX_Pin GPIO_PIN_12 // Definicion no utilizada, solo para referencia
#define UART6_GPIO_PORT GPIOA	 // Definicion no utilizada, solo para referencia

/*SPI Actualizado ivMini*/
#define SPI2_MISO_PIN GPIO_PIN_14 // Definicion no utilizada, solo para referencia
#define SPI2_MISO_PORT GPIOB	 // Definicion no utilizada, solo para referencia
#define SPI2_MOSI_PIN GPIO_PIN_15 // Definicion no utilizada, solo para referencia
#define SPI2_MOSI_PORT GPIOB	 // Definicion no utilizada, solo para referencia
#define SPI2_SCK_PIN GPIO_PIN_13	 // Definicion no utilizada, solo para referencia
#define SPI2_SCK_PORT GPIOB		 // Definicion no utilizada, solo para referencia
#define SPI2_ADXL_PIN GPIO_PIN_12
#define SPI2_ADXL_PORT GPIOB

/*I2C1 Actualizado ivMini*/
#define I2C1_SCL_PIN GPIO_PIN_8
#define I2C1_SDA_PIN GPIO_PIN_9
#define I2C1_PORT GPIOB

#define I2C3_SCL_PIN GPIO_PIN_8
#define I2C3_SCL_PORT GPIOA
#define I2C3_SDA_PIN GPIO_PIN_9
#define I2C3_SDA_PORT GPIOC

#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA

#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA

#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB

#define ONEWIRE_Pin GPIO_PIN_6
#define ONEWIRE_GPIO_Port GPIOB

#define MUX1_PIN_SA GPIO_PIN_0
#define MUX1_PORT_SA GPIOC
#define MUX1_PIN_SB GPIO_PIN_1
#define MUX1_PORT_SB GPIOC
#define MUX1_PIN_SC GPIO_PIN_0
#define MUX1_PORT_SC GPIOB
#define MUX1_PIN_SD GPIO_PIN_4
#define MUX1_PORT_SD GPIOA
#define MUX1_PIN_ENABLE GPIO_PIN_1
#define MUX1_PORT_ENABLE GPIOA
#define MUX1_PIN_OUT GPIO_PIN_0 // Definicion no utilizada, solo para referencia; ADC_CHANNEL_0
#define MUX1_PORT_OUT GPIOA		// Definicion no utilizada, solo para referencia; ADC_CHANNEL_0

/*TANQUES creado ivMini*/
#define TANQUE1_PIN_ENABLE GPIO_PIN_4
#define TANQUE1_PORT_ENABLE GPIOC
#define TANQUE2_PIN_ENABLE GPIO_PIN_5
#define TANQUE2_PORT_ENABLE GPIOC
#define TANQUE3_PIN_ENABLE GPIO_PIN_2
#define TANQUE3_PORT_ENABLE GPIOA
#define TANQUE4_PIN_ENABLE GPIO_PIN_3
#define TANQUE4_PORT_ENABLE GPIOA

#define THERMOCOUPLE1_PIN_SS GPIO_PIN_4
#define THERMOCOUPLE1_PORT_SS GPIOB

/*DIGITALES INPUT creado ivMini*/
#define DIGITAL_INPUT_1_PIN GPIO_PIN_10
#define DIGITAL_INPUT_1_PORT GPIOA
#define DIGITAL_INPUT_2_PIN GPIO_PIN_11
#define DIGITAL_INPUT_2_PORT GPIOA
#define DIGITAL_INPUT_3_PIN GPIO_PIN_12
#define DIGITAL_INPUT_3_PORT GPIOA
#define DIGITAL_INPUT_4_PIN GPIO_PIN_13
#define DIGITAL_INPUT_4_PORT GPIOA

/*DIGITALES OUTPUT creado ivMini*/
#define DIGITAL_OUTPUT_3_PIN GPIO_PIN_10 //Baja pot
#define DIGITAL_OUTPUT_3_PORT GPIOD
#define DIGITAL_OUTPUT_4_PIN GPIO_PIN_11 //Baja pot
#define DIGITAL_OUTPUT_4_PORT GPIOD

/*DIGITALES ELECTROVENTILADOR creado ivMini*/
#define ELECTROVENTILADOR_OUTPUT_1_PIN GPIO_PIN_6//Alta pot -- PID + PWM
#define ELECTROVENTILADOR_OUTPUT_1_PORT GPIOC
#define ELECTROVENTILADOR_OUTPUT_2_PIN GPIO_PIN_7//Alta pot -- PID + PWM
#define ELECTROVENTILADOR_OUTPUT_2_PORT GPIOC

#define SWITCH_1_ADC_PIN GPIO_PIN_9
#define SWITCH_1_ADC_PORT GPIOE
#define SWITCH_2_ADC_PIN GPIO_PIN_10
#define SWITCH_2_ADC_PORT GPIOE
#define SWITCH_3_ADC_PIN GPIO_PIN_1
#define SWITCH_3_ADC_PORT GPIOD
#define SWITCH_4_ADC_PIN GPIO_PIN_0
#define SWITCH_4_ADC_PORT GPIOD


#define LORA_DIO0_PIN GPIO_PIN_0
#define LORA_DIO0_GPIO_PORT GPIOB
#define LORA_RESET_PIN GPIO_PIN_1
#define LORA_RESET_GPIO_PORT GPIOB
#define LORA_NSS_PIN GPIO_PIN_2
#define LORA_NSS_GPIO_PORT GPIOB
#define LORA_MODE_PIN GPIO_PIN_3
#define LORA_MODE_GPIO_PORT GPIOB

#define RST_SYNC_PIN GPIO_PIN_7
#define RST_SYNC_PORT GPIOC
#else
#error "Please select the ivAdventure target device "
#endif

#ifdef __cplusplus
}
#endif

#endif /* SRC_EXTENSIONS_PINES_H_ */
