/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : config.h
*	@funcion    : Lista configuraciones y valores iniciales del STM32
*/

#ifndef SRC_CONFIG_H_
#define SRC_CONFIG_H_

/****************** CONFIGURACION DE PROYECTO Y VERSIONES *******************/


#define VERSION "2.2.0.0"
#define VERSION_FECHA "2021/10/27"
#define MENSAJE_BIENVENIDA "***********  Copyright ACTIONTRACKER ©  ***********"
#define DEBUG_COMPILATION	true

#define TEMPERATURA_PT100_SAMPLE_TIME 1000
#define TEMPERATURA_TERMOCUPLA_SAMPLE_TIME 1000
#define DIGITAL_INPUT_SAMPLE_TIME 200
#define AFORADOR_SAMPLE_TIME 500
#define TEMPORIZADORES_SAMPLE_TIME 1000
#define DATALOGGER_SAMPLE_TIME 1000

/*Definiciones para MicroSD*/
#define DIR_ROOT "/"
#define SENSOR_HISTORY "Sensor_History.txt"
#define ALARM_HISTORY "Alarm_History.txt"
#define SENSOR_PENDING_HISTORY "Sensor_Pending_History.txt"
#define ALARM_PENDING_HISTORY "Alarm_Pending_History.txt"


#endif /* SRC_CONFIG_H_ */
