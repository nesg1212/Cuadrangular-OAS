/*
*	Copyright ACTIONTRACKER SOLUTIONS LA ©
*	@Archivo    : task.h
*	@funcion    : Tarea #0 :: Esta tarea se encarga de entablar la comunicación con el
*				  microcontrolador ESP32 bajo el protocolo de comunicaciones I2C y el
*				  Formato de datos construido por ActionTracker Solutions ©
*				  Adjunto a esta tarea se encuentra el modelo ModuleSensorsRequest.h
*				  Para mayor información, consulte el manual interno.
*/

#ifndef SRC_TASKS_TASK0_TASK_H_
#define SRC_TASKS_TASK0_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task0

#include "../SemaphoreData/MapeoHardware.h"
#include "moduleSensorsRequests.h"

#define STM32_UUID ((uint32_t *)0x1FFF7A10)
void ProcessSinc();

uint8_t RXS[7];

bool banceraComunicaciones = false;
bool rf=false;

#if defined(STM32F411xE)
void CapturarDatosRecibidosESP32()
	{
		if(Serial1.available()>=7){
			//SerialSTM.print("recibe->");
			for(uint8_t i=0;i<7;i++){
				RXS[i]=Serial1.read();
				//SerialSTM.print(RXS[i]);
			}
			while(Serial1.available()>0) Serial1.read();

			//SerialSTM.println("");
			if(RXS[0] != 0xFF){
				dataReceived.tipoSolicitud = (TipoSolicitud)(RXS[0]);
				dataReceived.Port = RXS[1];
				dataReceived.SlaveNumber = RXS[2];
				dataReceived.new_value = RXS[3];
				dataReceived.new_value2 = RXS[4];
				dataReceived.new_value3 = RXS[5];
				dataReceived.modulo = (ModulosApp)(RXS[6]);
				banceraComunicaciones = true;
				transmitMessageToESP(CLEAN_BUF_I2C);
			}
			else{
				transmitMessageToESP(RESTO);
			}
		}
	}



/*
	void CapturarDatosRecibidosESP32()
	{
		if(Wire1.available()>=7){
			for(uint8_t i=0;i<7;i++){
				RXS[i] = Wire1.read();
			}
			if(RXS[0] != 0xFF){
				dataReceived.tipoSolicitud = (TipoSolicitud)(RXS[0]);
				dataReceived.Port = RXS[1];
				dataReceived.SlaveNumber = RXS[2];
				dataReceived.new_value = RXS[3];
				dataReceived.new_value2 = RXS[4];
				dataReceived.new_value3 = RXS[5];
				dataReceived.modulo = (ModulosApp)(RXS[6]);
				banceraComunicaciones = true;
				transmitMessageToESP(CLEAN_BUF_I2C);
			}
			else{
				transmitMessageToESP(RESTO);
			}
		}
	}

	*/



/*
void CapturarDatosRecibidosESP32()
	{
		if(rf){
			rf=false;
			SerialSTM.print("recibe->");
			for(uint8_t i=0;i<7;i++){
				SerialSTM.print(RXS[i]);
			}

			SerialSTM.println("");
			if(RXS[0] != 0xFF){
				dataReceived.tipoSolicitud = (TipoSolicitud)(RXS[0]);
				dataReceived.Port = RXS[1];
				dataReceived.SlaveNumber = RXS[2];
				dataReceived.new_value = RXS[3];
				dataReceived.new_value2 = RXS[4];
				dataReceived.new_value3 = RXS[5];
				dataReceived.modulo = (ModulosApp)(RXS[6]);
				banceraComunicaciones = true;
				transmitMessageToESP(CLEAN_BUF_I2C);
			}
			else{
				transmitMessageToESP(RESTO);
			}
		}
	}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	HAL_UART_Receive_IT(&huart1, RXS, 7);
	rf=true;
	__enable_irq();
}*/

#elif defined(STM32F107xC)
	void CapturarDatosRecibidosESP32()
	{
		if(rf){
			SerialSTM.print("recibe->");
			for(uint8_t i=0;i<7;i++){
				SerialSTM.print(RXS[i]);
			}
			while(Serial1.available()>0) Serial1.read();

			SerialSTM.println("");
			if(RXS[0] != 0xFF){
				dataReceived.tipoSolicitud = (TipoSolicitud)(RX[0]);
				dataReceived.Port = RXS[1];
				dataReceived.SlaveNumber = RXS[2];
				dataReceived.new_value = RXS[3];
				dataReceived.new_value2 = RXS[4];
				dataReceived.new_value3 = RXS[5];
				dataReceived.modulo = (ModulosApp)(RXS[6]);
				banceraComunicaciones = true;
				transmitMessageToESP(CLEAN_BUF_I2C);
			}
			else{
				transmitMessageToESP(RESTO);
			}
		}
	}
#endif

void ProcessReceived()
{
	CapturarDatosRecibidosESP32();
	if(banceraComunicaciones)
	{banceraComunicaciones=false;
		//Serial1.print("recibido");

		//banceraComunicaciones = false;
		if (dataReceived.tipoSolicitud == READ_PORT)
		{
			if (dataReceived.modulo == NONE_MODULE)
			{
				RequestNoneModule();
			}

			else if (dataReceived.modulo == LIQUIDO_SENSORS)
			{
				RequestModuleLiquidSensor();
			}
			else if (dataReceived.modulo == GPS_SENSORS)
			{
				RequestModuleGPS_Sensor();
			}
			else if (dataReceived.modulo == TEMPORIZADORES_SENSORS)
			{
				RequestModuleTemporizadoresSensor();
			}
			else if (dataReceived.modulo == SYSGO_SENSORS)
			{
				RequestModuleSysgoSensor();
			}
			else if (dataReceived.modulo == DIGITAL_OUTPUT_SENSORS)
			{
				RequestModuleDigitalOutputSensor();
			}
			else if (dataReceived.modulo == VENTILADOR_SENSORS)
			{
				RequestModuleVentiladorSensor();
			}
			else if (dataReceived.modulo == WINCHE_SENSORS)
			{
				RequestModuleWincheSensor();
			}

			else
			{
			if(	!RequestModuleSensor(dataReceived.new_value,dataReceived.new_value2, dataReceived.modulo)){
				addMessage("{p[]d[]m[");
				addMessage(dataReceived.modulo);
				addMessage("]}");
				addMessage("\r\n");
				transmitMessageToESP(INICIAL);}
			}
		}

		//proceso:
		//1 - SCAN_DS18B20
		//2 - SET_SCAN_DS18B20
		//3 - FINISH_SCAN_DS18B20
		else if(dataReceived.tipoSolicitud == SCAN_DS18B20){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			ds18b20_matricula.puerto = puerto;
			ds18b20_matricula.scanner = true;
			ds18b20_matricula.offset = 0;

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

			SerialSTM.println("Entra en modo scanner DS18B20");
		}else if (dataReceived.tipoSolicitud == DATA_SCAN_DS18B20){
			SerialSTM.println("******************************************************");
			addMessage("{");
			addMessage("'id' : ");
			addMessage("[");
			for(uint8_t i=0; i<8; i++)
			{
				uint8_t value = ds18b20_matricula.ROM[i];
				addMessage(value);
				addMessage(",");
			}
			addMessage("]");

			addMessage(", 't' : ");
			addMessage(ds18b20_matricula.Temperatura);
			addMessage("}");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

		}else if (dataReceived.tipoSolicitud == OFFSET_SCAN_DS18B20){
			uint8_t parte_entera = dataReceived.new_value;
			ds18b20_matricula.offset = (float)(parte_entera);

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

			SerialSTM.println("Se configura el offset que requiera el sensor por parte del usuario");
		}
		else if (dataReceived.tipoSolicitud == FINISH_SCAN_DS18B20){
			ds18b20_matricula.scanner = false;
			ds18b20_matricula.almacenar = true;
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_TANKS_TIPO_SOLICITUD)
		{
			uint8_t indice_posicion_vector = dataReceived.SlaveNumber;
			uint32_t valor =  (dataReceived.new_value<<16) | (dataReceived.new_value2<<8) | (dataReceived.new_value3);
			double valorTanque = double(valor)/10.0;

			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t tipo_tanque = (uint8_t)(dataReceived.modulo);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].valores_depositos[indice_posicion_vector] = valorTanque;
					sensoresLiquidoTanques[i].tipo_tanque = tipo_tanque;
					if(indice_posicion_vector==100){
						sensoresLiquidoTanques[i].valores_depositos_disponible=true;
					}
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		//TANQUES IRREGULARES 1
		else if (dataReceived.tipoSolicitud == ALMACENAR_MINIMO_TANQUES){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t largo = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].medidas_tanque_inferior.largo = largo;
					sensoresLiquidoTanques[i].orden_almacenar_resistencia.zero_absoluto = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_MAXIMO_TANQUES){
			uint8_t ancho = dataReceived.new_value;
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].medidas_tanque_superior.ancho = ancho;
					sensoresLiquidoTanques[i].orden_almacenar_resistencia.maximo_absoluto = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MINIMO_TANQUES){
			uint8_t ancho = dataReceived.new_value;
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho = ancho;
					sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_minimo = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MAXIMO_TANQUES){
			uint8_t largo = dataReceived.new_value;
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].medidas_tanque_superior.largo = largo;
					sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_maximo = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == MATRICULAR_TANQUE_IRREGULAR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t alto = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].tipo_tanque=1;
					sensoresLiquidoTanques[i].medidas_tanque_inferior.alto = alto;
					sensoresLiquidoTanques[i].medidas_tanque_superior.alto = alto;
					sensoresLiquidoTanques[i].matricular_tanque=true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == DESMATRICULAR_TANQUE_IRREGULAR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t alto = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].desmatricular_tanque=true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_INFLEXION_TANQUES2_CIERRE){//MOD-JOSE
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint16_t alto = (dataReceived.new_value<<8) | (dataReceived.new_value2);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].punto_inflexion.alto = alto;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_INFLEXION_TANQUES2_APERTURA){//MOD-JOSE
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint16_t largo = (dataReceived.new_value<<8) | (dataReceived.new_value2);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].punto_inflexion.largo = largo;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_INFLEXION_TANQUES2_ORDEN){///MOD-JOSE
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint16_t ancho = (dataReceived.new_value<<8) | (dataReceived.new_value2);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].punto_inflexion.ancho = ancho;
					sensoresLiquidoTanques[i].orden_almacenar_resistencia.inflexion=true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MINIMO_TANQUES2){//OK, falta probar
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t new_value = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_minimo = true;
					SerialSTM.println("*****************************************************************************");
					SerialSTM.println("umbMin");
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MAXIMO_TANQUES2){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t new_value = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_maximo = true;
					SerialSTM.println("*****************************************************************************");
					SerialSTM.println("umbMax");
					break;
				}
			}

			// funcion para matricular tanques irregulares 2
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == MATRICULAR_TANQUE_IRREGULAR_2){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t new_value = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].matricular_tanque_2=true;
					SerialSTM.println("*****************************************************************************");
					SerialSTM.println("matricula");
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		//TANQUES IRREGULARES 3:
		else if (dataReceived.tipoSolicitud == SEND_TANKS_TIPO_SOLICITUD)//OJO, PUEDE BORRARSE... NO HACE NADA AHORITA
		{
			uint8_t valor = dataReceived.SlaveNumber; //valor medido en el tanque
			uint8_t indice_posicion_vector = dataReceived.new_value;

			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t tipo_tanque = (uint8_t)(dataReceived.modulo);

			SerialSTM.println("****************************");
			SerialSTM.println("****************************");
			SerialSTM.println("            TANQ      ");
			SerialSTM.println("****************************");
			SerialSTM.print(puerto);
			SerialSTM.print("-");
			SerialSTM.print(indice_posicion_vector);
			SerialSTM.print("-");
			SerialSTM.println(valor);
			SerialSTM.println("****************************");

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (sensoresLiquidoTanques[i].port == puerto)
				{
					sensoresLiquidoTanques[i].valores_depositos[indice_posicion_vector] = valor;
					sensoresLiquidoTanques[i].tipo_tanque = tipo_tanque;
					break;
				}
			}
		}

		// BORRAR TANQUE
		else if (dataReceived.tipoSolicitud == BORRAR_TANQUE){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			SerialSTM.print("Borrar tanque irregular con puerto: ");
			SerialSTM.println(puerto);
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

		}

		else if (dataReceived.tipoSolicitud == STATUS_INTERRUPTOR){
			uint8_t puerto = dataReceived.Port;
			uint8_t nuevo_valor = dataReceived.new_value;

			for (uint8_t var = 0; var < numero_actuadores_interruptor; ++var){
				if(salidasDigital[var].port == puerto){
					salidasDigital[var].value = nuevo_valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == STATUS_ELECTROVENTILADOR){
			uint8_t puerto = dataReceived.Port;
			uint8_t nuevo_valor = dataReceived.new_value;

			for (uint8_t var = 0; var < numero_ventiladores; ++var){
				if(actuadoresVentiladores[var].port == puerto){
					actuadoresVentiladores[var].value = nuevo_valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_LINEALIZACION_A){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			double valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3)) / 100.0;

			for(int i=0;i<numero_sensores_analogicos;i++){
				if(sensoresAnalogicos[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					setDouble_eeprom(valor, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(PENDIENTE_A));
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_LINEALIZACION_B){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			double valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2 & 0xFF)<<8) + ((dataReceived.new_value3) & 0xFF)) / 100.0;

			for(int i=0;i<numero_sensores_analogicos;i++){
				if(sensoresAnalogicos[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					setDouble_eeprom(valor, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(INTERSECCION_A));
					setInt_eeprom((int)true, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == INHABILITAR_LINEALIZACION){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for(int i=0;i<numero_sensores_analogicos;i++){
				if(sensoresAnalogicos[i].port == puerto){
					setInt_eeprom((int)false, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == HABILITA_TEMPORIZADOR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for(int i=0;i<numero_sensores_temporizadores;i++){
				if(sensoresTemporizadores[i].port == puerto){
					sensoresTemporizadores[i].orden_habilitado=true;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == REMOVE_TEMPORIZADOR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for(int i=0;i<numero_sensores_temporizadores;i++){
				if(sensoresTemporizadores[i].port == puerto){
					sensoresTemporizadores[i].orden_remove=true;
					//setInt_eeprom((int)false, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));
					SerialSTM.println("***REMOVE_TEMPORIZADOR***");
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == RESET_TEMPORIZADOR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for(int i=0;i<numero_sensores_temporizadores;i++){
				if(sensoresTemporizadores[i].port == puerto){
					sensoresTemporizadores[i].orden_reset=true;
					//setInt_eeprom((int)false, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));
					SerialSTM.println("***RESET_TEMPORIZADOR***");
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == PAUSE_TEMPORIZADOR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for(int i=0;i<numero_sensores_temporizadores;i++){
				if(sensoresTemporizadores[i].port == puerto){
					sensoresTemporizadores[i].orden_pause=true;
					//setInt_eeprom((int)false, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));
					SerialSTM.println("***PAUSE_TEMPORIZADOR***");
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == PLAY_TEMPORIZADOR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for(int i=0;i<numero_sensores_temporizadores;i++){
				if(sensoresTemporizadores[i].port == puerto){
					sensoresTemporizadores[i].orden_play=true;
					//setInt_eeprom((int)false, ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));
					SerialSTM.println("***PLAY_TEMPORIZADOR***");
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == READ_UID_STM32){
			int modulo = UID_RESPONSE;
			SerialSTM.println("UID_RESPONSE");

			addMessage(PORT_HEADER);
			addMessage("0-0");

			addMessage(DATA_HEADER);
			addMessage(uid.getProcessedUID());

			addMessage(MODULE_HEADER);
			addMessage(modulo);
			addMessage(CLOSE_HEADER);
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_VALOR_KP){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			double valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3)) / 1000.0;

			for(int i=0;i<numero_ventiladores;i++){
				SerialSTM.print("PUERTO-");
				SerialSTM.println(actuadoresVentiladores[i].port);

				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.kp = true;
					actuadoresVentiladores[i].pid.kp = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_VALOR_KI){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			double valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3)) / 1000.0;

			for(int i=0;i<numero_ventiladores;i++){
				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.ki = true;
					actuadoresVentiladores[i].pid.ki = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_VALOR_KD){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			double valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3)) / 1000.0;

			for(int i=0;i<numero_ventiladores;i++){
				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.kd = true;
					actuadoresVentiladores[i].pid.kd = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == HABILITA_PID){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			int valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3));

			for(int i=0;i<numero_ventiladores;i++){
				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.available = true;
					if(valor == 0 || valor == 1)
						actuadoresVentiladores[i].pid.available = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_TM_PID){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			int valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3));

			for(int i=0;i<numero_ventiladores;i++){
				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.tm = true;
					if(valor > 0)
						actuadoresVentiladores[i].pid.tm = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_OUTPUT_PID){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			int valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3));

			for(int i=0;i<numero_ventiladores;i++){
				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.output = true;
					actuadoresVentiladores[i].pid.output = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_SETPOINT_PID){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			int valor = (((dataReceived.new_value & 0x7F)<<16) + ((dataReceived.new_value2)<<8) + (dataReceived.new_value3));

			for(int i=0;i<numero_ventiladores;i++){
				if(actuadoresVentiladores[i].port == puerto){
					if((dataReceived.new_value>>7) & 0x01)
						valor *= -1;
					actuadoresVentiladores[i].pid.pid_flag.setpoint = true;
					actuadoresVentiladores[i].pid.setpoint = valor;
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == SEND_RS485)
		{
			SerialSTM.println("SEND_RS485");

			addMessage("Rx: ");
			addMessage("hola mundo 3");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SCAN_CANBUS)
		{
			SerialSTM.println("SCAN_CANBUS");

			addMessage("Rx: ");
			addMessage("hola mundo 4");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_CANBUS)
		{
			SerialSTM.println("SEND_CANBUS");

			addMessage("Rx: ");
			addMessage("hola mundo 5");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SCAN_LORA)
		{
			SerialSTM.println("SCAN_LORA");

			addMessage("Rx: ");
			addMessage("hola mundo 6");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_LORA)
		{
			SerialSTM.println("SEND_LORA");

			addMessage("Rx: ");
			addMessage("hola mundo 7");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}

		else
		{
			SerialSTM.print("Received: ");
			SerialSTM.println((int)dataReceived.tipoSolicitud);

			addMessage("Rx: ");
			addMessage("hola mundo 8");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
	}
	else
	{
		//SerialSTM.println("Dato repetido");
	}
}

void SettingsTask0(){
	dataReceived.tipoSolicitud = READ_PORT;
}

#if defined(STM32F411xE)
	void StartDefaultTask(void *argument)
	{
		SerialSTM.println("INICIALIZA LA TAREA 0");
		Wire1.setBytesToReceive(7);
		if(Wire1.begin(STM32_SLAVE_ADDRESS, 400000)){
			SerialSTM.println("INICIALIZO BIEN EL I2C1");
		}
		else{
			SerialSTM.println("Error en inicialización");
		}
		pinMode(RST_SYNC_PORT, RST_SYNC_PIN, INPUT);
		SettingsTask0();
		HAL_UART_Receive_IT(&huart1, RXS, 7);//agregado

		for (;;){
			ProcessReceived();
			ProcessSinc();
			osDelay(1);
		}
	}

	void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c){
		SerialSTM.println("!!!ERROR_CALLBACK_I2C!!!");
		while(Wire1.available()) Wire1.read();
		HAL_I2C_Slave_Receive_DMA(hi2c, I2C_Buffer_ESP.Buffer_raw, I2C_Buffer_ESP.numBytesToReceive);
	}

	void ProcessSinc(){
		if(digitalRead(RST_SYNC_PORT, RST_SYNC_PIN)) NVIC_SystemReset();
	    if(Wire1.isReceiveModeAvailable()) Wire1.EnableReceiveMode();
		if(Wire1.isDataReceived()) Wire1.refresh();
	}
#elif defined(STM32F107xC)
	void StartDefaultTask(void *argument)
	{
		Serial1.begin(115200);
		SerialSTM.println("INICIALIZA LA TAREA 0");
		pinMode(RST_SYNC_PORT, RST_SYNC_PIN, INPUT);
		SettingsTask0();

		for (;;){
			ProcessReceived();
			ProcessSinc();
			osDelay(1);
		}
	}

	void ProcessSinc(){
		if(digitalRead(RST_SYNC_PORT, RST_SYNC_PIN)) NVIC_SystemReset();
	}
#endif

#endif
#endif /* SRC_TASKS_TASK0_TASK_H_ */
