/*
*	Copyright ACTIONTRACKER SOLUTIONS L.A. ©
*	@Archivo    : moduleSensorsRequest.h
*	@funcion    : Tarea #0 :: Este archivo se encarga de realizar un barrido entre
*				  los diferentes vectores del mapeo de puertos. Este proceso se ejecuta
*				  unicamente cuando un nuevo dato es recibido en la tarea por I2C.
*/

#ifndef SRC_TASKS_TASK0_MODULESENSORSREQUESTS_H_
#define SRC_TASKS_TASK0_MODULESENSORSREQUESTS_H_



char joinMessagePrint[2000]={'\0'};
uint16_t size=0;


DataESP32 dataReceived;
#if defined(STM32F411xE)
	#define SerialSTM Serial2
	Wire Wire1(I2C1, SLAVE);
#elif defined(STM32F107xC)
	#define SerialSTM Serial3
	Serial Serial1(USART1);
#endif



char PORT_HEADER[1] = {'p'};
char DATA_HEADER[1] = {'d'};
char MODULE_HEADER[1] = {'m'};
char CLOSE_HEADER[1] = {';'};

void addMessage(char* message);
void addMessage(int value);
void transmitMessageToESP(TRAMA_I2C tipoTransmision);

void RequestNoneModule(){
	int numero_sensores = 1;
	int modulo = NONE_MODULE;
	//SerialSTM.println("NO MODULO");

	addMessage(PORT_HEADER);
	if(numero_sensores > 0){
		addMessage((int)mapeoPuertos[dataReceived.Port].port);
		addMessage("-");
		addMessage((int)mapeoPuertos[dataReceived.Port].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = (int)mapeoPuertos[dataReceived.Port].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

bool RequestModuleSensor(uint8_t s_inicio, uint8_t s_fin, ModulosApp mod){
Sensor* array;
int numero_sensores;

switch (mod){
/*case NONE_MODULE:
	array=&mapeoPuertos[0].value;
	numero_sensores=1;
	break;*/
case TEMPERATURE_SENSORS:
	array=&sensoresTemperatura[0];
	numero_sensores = numero_sensores_temperatura;
	break;
case HUMEDAD_SENSORS:
	array=&sensoresHumedad[0];
	numero_sensores = numero_sensores_humedad;
	break;
case VELOCIDAD_SENSORS:
array=&sensoresVelocidad[0];
numero_sensores = numero_sensores_velocidad;
	break;
case VOLTAJE_SENSORS:
	array=&sensoresVoltaje[0];
	numero_sensores = numero_sensores_voltaje;
	break;
case DIGITAL_INPUT_SENSORS:
	numero_sensores = numero_entradas_digitales;
	array=&sensoresDigitales[0]; ///revisar si el buffer es correcto
	break;
case PROXIMIDAD_SENSORS:
	array=&sensoresProximidad[0];
	numero_sensores = numero_sensores_proximidad;
	break;
/*case LIQUIDO_SENSORS:
	array=&sensoresLiquidoTanques[0];
	numero_sensores = numero_sensores_liquido;
	break;*/
case PRESION_SENSORS:
	array=&sensoresPresion[0];
	numero_sensores = numero_sensores_presion;
	break;
case RPM_SENSORS:
	array=&sensoresRPM[0];
	numero_sensores = numero_sensores_rpm;
	break;
case SUSPENSION_SENSORS:
	array=&sensoresSuspension[0];
	numero_sensores = numero_suspensiones;
	break;
case ALTURA_SENSORS:
	array=&sensoresAltura[0];
	numero_sensores = numero_alturas;
	break;
case REBOTE_SENSORS:
	array=&sensoresRebotes[0];
	numero_sensores = numero_rebotes;
	break;
case INCLINACION_SENSORS:
	array=&sensoresInclinaciones[0];
	numero_sensores = numero_sensores_inclinaciones;
	break;
case MARCHA_SENSORS:
	array=&sensoresMarchas[0];
	numero_sensores = numero_marchas_instaladas;
	break;
case TORQUE_SENSORS:
	numero_sensores = numero_sensores_torque;
	array=&sensoresTorque[0];
	break;
case POTENCIA_SENSORS:
	array=&sensoresPotencia[0];
	numero_sensores = numero_sensores_potencia;
	break;
	/*
case GPS_SENSORS:
	array=&sensoresGPS[0].value;
	numero_sensores = numero_sensores_gps;
	break;*/
case NEUMATICO_SENSORS:
	array=&sensoresNeumaticos[0];
	numero_sensores = numero_neumaticos;
	break;
case ANALOGICO_SENSORS:
	array=&sensoresAnalogicos[0];
	numero_sensores = numero_sensores_analogicos;
	break;
	/*
case TEMPORIZADORES_SENSORS:
	array=&sensoresTemporizadores[0].value;
	numero_sensores = numero_sensores_temporizadores;
	break;
case SYSGO_SENSORS:
	array=&sensoresSysgo[0];
	break;
case DIGITAL_OUTPUT_SENSORS:
	array=&sensores[0];
	break;
case VENTILADOR_SENSORS:
	array=&sensores[0];
	break;
case WINCHE_SENSORS:
	array=&actuadoresWinches[0];
	break;
case SEND_TANKS_MODULE:
	array=&sensores[0];
	break;
case UID_RESPONSE:
	array=&sensores[0];
	break;*/

default:
	numero_sensores = -1;
	break;
}

if(numero_sensores!=-1){

if(s_inicio==0&&s_fin==0xff){

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(array[0].port);
		addMessage("-");
		addMessage(array[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = array[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	}
	else if(s_inicio<=s_fin&&s_fin<=numero_sensores){
		int numero_sensores = s_fin-s_inicio+1;

			addMessage(PORT_HEADER);
			if(numero_sensores >0){
				addMessage(array[s_inicio].port);
				addMessage("-");
				addMessage(array[s_fin].port);
			}

			addMessage(DATA_HEADER);
			for (int var = 0; var < numero_sensores; ++var)
			{
				int value = array[var+s_inicio].value;
				addMessage(value);
				if(var < (numero_sensores-1)) addMessage(",");
			}
	}


	addMessage(MODULE_HEADER);
	addMessage(mod);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
	return true;
}
return false;
}
/*
void RequestModuleTemperatureSensor(uint8_t s_inicio, uint8_t s_fin)
{int modulo = TEMPERATURE_SENSORS;

	if(s_inicio==0&&s_fin==0xff){

	int numero_sensores = numero_sensores_temperatura;

	SerialSTM.println("TEMPERATURE_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(sensoresTemperatura[0].port);
		addMessage("-");
		addMessage(sensoresTemperatura[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresTemperatura[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	}
	else if(s_inicio<=s_fin&&s_fin<=numero_sensores_temperatura){
		int numero_sensores = s_fin-s_inicio+1;

			SerialSTM.println("TEMPERATURE_SENSORS");

			addMessage(PORT_HEADER);
			if(numero_sensores >0){
				addMessage(sensoresTemperatura[s_inicio].port);
				addMessage("-");
				addMessage(sensoresTemperatura[s_fin].port);
			}

			addMessage(DATA_HEADER);
			for (int var = 0; var < numero_sensores; ++var)
			{
				int value = sensoresTemperatura[var+s_inicio].value;
				addMessage(value);
				if(var < (numero_sensores-1)) addMessage(",");
			}
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}


void RequestModuleHumditySensor(uint8_t s_inicio, uint8_t s_fin)
{
	int modulo = HUMEDAD_SENSORS;
	if(s_inicio==0&&s_fin==0xff){
	int numero_sensores = numero_sensores_humedad;

	SerialSTM.println("HUMEDAD_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresHumedad[0].port);
		addMessage("-");
		addMessage(sensoresHumedad[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);

	for (int var = 0; var < numero_sensores; ++var){
		int value = sensoresHumedad[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	}
		else if(s_inicio<=s_fin&&s_fin<=numero_sensores_humedad){

			int numero_sensores = s_fin-s_inicio+1;

						SerialSTM.println("HUMEDAD_SENSORS");

						addMessage(PORT_HEADER);
						if(numero_sensores >0){
							addMessage(sensoresHumedad[s_inicio].port);
							addMessage("-");
							addMessage(sensoresHumedad[s_fin].port);
						}

						addMessage(DATA_HEADER);
						for (int var = 0; var < numero_sensores; ++var)
						{
							int value = sensoresHumedad[var+s_inicio].value;
							addMessage(value);
							if(var < (numero_sensores-1)) addMessage(",");
						}


		}
	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleSpeedSensor()
{
	int numero_sensores = numero_sensores_velocidad;
	int modulo = VELOCIDAD_SENSORS;
	SerialSTM.println("VELOCIDAD_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(sensoresVelocidad[0].port);
		addMessage("-");
		addMessage(sensoresVelocidad[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresVelocidad[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleVoltageSensor()
{
	int numero_sensores = numero_sensores_voltaje;
	int modulo = VOLTAJE_SENSORS;
	SerialSTM.println("VOLTAJE_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresVoltaje[0].port);
		addMessage("-");
		addMessage(sensoresVoltaje[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresVoltaje[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}
void RequestModuleDitalInputSensor()
{
	int numero_sensores = numero_entradas_digitales;
	int modulo = DIGITAL_INPUT_SENSORS;
	SerialSTM.println("DIGITAL_INPUT_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresDigitales[0].port);
		addMessage("-");
		addMessage(sensoresDigitales[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresDigitales[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleProximitySensor()
{
	int numero_sensores = numero_sensores_proximidad;
	int modulo = PROXIMIDAD_SENSORS;
	SerialSTM.println("PROXIMIDAD_SENSORS");
	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresProximidad[0].port);
		addMessage("-");
		addMessage(sensoresProximidad[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresProximidad[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");
	transmitMessageToESP(INICIAL);
}
*/
void RequestModuleLiquidSensor()
{
	int numero_sensores = numero_sensores_liquido;
	int modulo = LIQUIDO_SENSORS;
	//SerialSTM.println("LIQUIDO_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(sensoresLiquidoTanques[0].port);
		addMessage("-");
		addMessage(sensoresLiquidoTanques[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresLiquidoTanques[var].value;
		addMessage(value);
		addMessage(":");
		value = sensoresLiquidoTanques[var].value2;
		addMessage(value);
		addMessage(":");
		value = sensoresLiquidoTanques[var].value3;
		addMessage(value);
		addMessage(":");
		value = sensoresLiquidoTanques[var].value4;
		addMessage(value);
		addMessage(":");
		value = sensoresLiquidoTanques[var].value5;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}
/*
void RequestModulePressureSensor()
{
	int numero_sensores = numero_sensores_presion;
	int modulo = PRESION_SENSORS;
	SerialSTM.println("PRESION_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresPresion[0].port);
		addMessage("-");
		addMessage(sensoresPresion[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresPresion[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleRpmSensor()
{
	int numero_sensores = numero_sensores_rpm;// + numeroTotalVentiladores;
	int modulo = RPM_SENSORS;
	SerialSTM.println("RPM_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresRPM[0].port);
		addMessage("-");
		addMessage(sensoresRPM[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresRPM[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleSuspensionSensor()
{
	int numero_sensores = numero_suspensiones;
	int modulo = SUSPENSION_SENSORS;
	SerialSTM.println("SUSPENCION_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresSuspension[0].port);
		addMessage("-");
		addMessage(sensoresSuspension[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresSuspension[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleHeightSensor()
{
	int numero_sensores = numero_alturas;
	int modulo = ALTURA_SENSORS;
	SerialSTM.println("ALTURA_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresAltura[0].port);
		addMessage("-");
		addMessage(sensoresAltura[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresAltura[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleReboundSensor()
{
	int modulo = REBOTE_SENSORS;
	SerialSTM.println("REBOTE_SENSORS");
	int numero_sensores = numero_rebotes;

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresRebotes[0].port);
		addMessage("-");
		addMessage(sensoresRebotes[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresRebotes[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleInclinationSensor()
{
	int modulo = INCLINACION_SENSORS;
	SerialSTM.println("INCLINACION_SENSORS");
	int numero_sensores = numero_sensores_inclinaciones;

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresInclinaciones[0].port);
		addMessage("-");
		addMessage(sensoresInclinaciones[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresInclinaciones[var].value;
		addMessage(value);
		addMessage(":");
		int value2 = sensoresInclinaciones[var].value2;
		addMessage(value2);
		addMessage(":");
		int value3 = sensoresInclinaciones[var].value3;
		addMessage(value3);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleMarchSensor()
{
	int modulo = MARCHA_SENSORS;
	SerialSTM.println("MARCHA_SENSORS");
	int numero_sensores = numero_marchas_instaladas;

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresMarchas[0].port);
		addMessage("-");
		addMessage(sensoresMarchas[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresMarchas[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleTorqueSensor()
{
	int modulo = TORQUE_SENSORS;
	SerialSTM.println("TORQUE_SENSORS");
	int numero_sensores = numero_sensores_torque;

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresTorque[0].port);
		addMessage("-");
		addMessage(sensoresTorque[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresTorque[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModulePowerSensor()
{
	int modulo = POTENCIA_SENSORS;
	SerialSTM.println("POTENCIA_SENSORS");
	int numero_sensores = numero_sensores_potencia;

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresPotencia[0].port);
		addMessage("-");
		addMessage(sensoresPotencia[numero_sensores-1].port);
	}


	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresPotencia[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}


	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}
*/
void RequestModuleGPS_Sensor()
{
	int modulo = GPS_SENSORS;
	//SerialSTM.println("GPS_SENSORS");
	int numero_sensores = numero_sensores_gps;

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresGPS[0].port);
		addMessage("-");
		addMessage(sensoresGPS[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var){
		addMessage((int)sensoresGPS[var].validez);
		addMessage(":");
		addMessage(sensoresGPS[var].hora);
		addMessage(":");
		addMessage(toChar(sensoresGPS[var].latitud,7));
		addMessage(":");
		addMessage(toChar(sensoresGPS[var].logitud,7));
		addMessage(":");
		addMessage((int)sensoresGPS[var].numSat);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}
/*
void RequestModuleNeumatico_Sensor()
{
	int numero_sensores = numero_neumaticos;
	int modulo = NEUMATICO_SENSORS;
	SerialSTM.println("NEUMATICO_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(sensoresNeumaticos[0].port);
		addMessage("-");
		addMessage(sensoresNeumaticos[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresNeumaticos[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleAnalogSensor()
{
	int numero_sensores = numero_sensores_analogicos;
	int modulo = ANALOGICO_SENSORS;
	SerialSTM.println("ANALOGICO_SENSORS");

	addMessage(PORT_HEADER);

	if(numero_sensores >0){
		addMessage(sensoresAnalogicos[0].port);
		addMessage("-");
		addMessage(sensoresAnalogicos[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var){
		double value = sensoresAnalogicos[var].value / 10.0;
		if(value < 0 || value >0)
			addMessage(toChar(value, 1));
		else
			addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}
*/
void RequestModuleTemporizadoresSensor()
{
	int numero_sensores = numero_sensores_temporizadores;
	int modulo = TEMPORIZADORES_SENSORS;
	//SerialSTM.println("TEMPORIZADORES_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(sensoresTemporizadores[0].port);
		addMessage("-");
		addMessage(sensoresTemporizadores[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		addMessage(sensoresTemporizadores[var].minutosTranscurridos);
		addMessage(":");
		addMessage(sensoresTemporizadores[var].segundosTranscurridos);
		addMessage(":");
		addMessage(sensoresTemporizadores[var].fechaReg);
		addMessage(":");
		addMessage(sensoresTemporizadores[var].horaReg);
		addMessage(":");
		addMessage((int)sensoresTemporizadores[var].pause);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleSysgoSensor()
{
	int numero_sensores = numero_maximo_sensores_sysgo;
	int modulo = SYSGO_SENSORS;
	//SerialSTM.println("SYSGO_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(sensoresSysgo[0].port);
		addMessage("-");
		addMessage(sensoresSysgo[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = sensoresSysgo[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);

}

void RequestModuleDigitalOutputSensor()
{
	int numero_sensores = numero_actuadores_interruptor;
	int modulo = DIGITAL_OUTPUT_SENSORS;
	//SerialSTM.println("DIGITAL_OUTPUT_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(salidasDigital[0].port);
		addMessage("-");
		addMessage(salidasDigital[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = salidasDigital[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleVentiladorSensor()
{
	int numero_sensores = numero_ventiladores;
	int modulo = VENTILADOR_SENSORS;
	//SerialSTM.println("VENTILADOR_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(actuadoresVentiladores[0].port);
		addMessage("-");
		addMessage(actuadoresVentiladores[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = actuadoresVentiladores[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleWincheSensor()
{
	int numero_sensores = numero_winches;
	int modulo = WINCHE_SENSORS;
	//SerialSTM.println("WINCHE_SENSORS");

	addMessage(PORT_HEADER);
	if(numero_sensores >0){
		addMessage(actuadoresWinches[0].port);
		addMessage("-");
		addMessage(actuadoresWinches[numero_sensores-1].port);
	}

	addMessage(DATA_HEADER);
	for (int var = 0; var < numero_sensores; ++var)
	{
		int value = actuadoresWinches[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}

	addMessage(MODULE_HEADER);
	addMessage(modulo);
	addMessage(CLOSE_HEADER);
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

//----------------------------------------------------------------------------------------------------------------

void addMessage(char* message){
	size+=strlen(message);
	strcat(joinMessagePrint,message);
}
void addMessage(int value){
	char* val=toChar(value);
	size+=strlen(val);
	strcat(joinMessagePrint,val);
}

#if defined(STM32F411xE)

void transmitMessageToESP(TRAMA_I2C tipoTransmision){
		if(tipoTransmision == INICIAL){
			Serial1.print(joinMessagePrint, size);
			size=0;
		}
		if(tipoTransmision == RESTO){
			memmove(joinMessagePrint, &(joinMessagePrint[254]), sizeof(joinMessagePrint));
			Serial1.print(joinMessagePrint, 254);
		}
		if(tipoTransmision == CLEAN_BUF_I2C){
			memset(joinMessagePrint, '\0', sizeof(joinMessagePrint));
		}

		//SerialSTM.println(joinMessagePrint);
	}

	/*void transmitMessageToESP(TRAMA_I2C tipoTransmision){
		if(tipoTransmision == INICIAL){
			Wire1.write(joinMessagePrint, 254);
		}
		if(tipoTransmision == RESTO){
			memmove(joinMessagePrint, &(joinMessagePrint[254]), sizeof(joinMessagePrint));
			Wire1.write(joinMessagePrint, 254);
		}
		if(tipoTransmision == CLEAN_BUF_I2C){
			memset(joinMessagePrint, '\0', sizeof(joinMessagePrint));
		}

		SerialSTM.println(joinMessagePrint);
	}*/
#elif defined(STM32F107xC)
	void transmitMessageToESP(TRAMA_I2C tipoTransmision){
		if(tipoTransmision == INICIAL){
			Serial1.print(joinMessagePrint, 254);
		}
		if(tipoTransmision == RESTO){
			memmove(joinMessagePrint, &(joinMessagePrint[254]), sizeof(joinMessagePrint));
			Serial1.print(joinMessagePrint, 254);
		}
		if(tipoTransmision == CLEAN_BUF_I2C){
			memset(joinMessagePrint, '\0', sizeof(joinMessagePrint));
		}

		SerialSTM.println(joinMessagePrint);
	}
#endif



#endif /* SRC_TASKS_TASK0_MODULESENSORSREQUESTS_H_ */
