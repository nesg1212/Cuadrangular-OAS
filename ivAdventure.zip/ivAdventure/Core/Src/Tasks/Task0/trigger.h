/*
 * trigger.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK0_TRIGGER_H_
#define SRC_TASKS_TASK0_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t defaultTaskHandle;
osThreadAttr_t defaultTask_attributes;

void Trigger_Task0(){
	#ifdef create_task0
		defaultTask_attributes.name = NAME_TASK;
		defaultTask_attributes.stack_size = RAM_TASK * 4;;
		defaultTask_attributes.priority = PRIORITY_TASK;

		defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);
	#endif
}

#endif /* SRC_TASKS_TASK0_TRIGGER_H_ */
