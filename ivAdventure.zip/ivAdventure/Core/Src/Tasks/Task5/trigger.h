/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK5_TRIGGER_H_
#define SRC_TASKS_TASK5_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask05_Handle;
osThreadAttr_t myTask05_attributes;


void Trigger_Task05(){
	#ifdef create_task5
		myTask05_attributes.name = NAME_TASK5;
		myTask05_attributes.stack_size = RAM_TASK5 * 4;
		myTask05_attributes.priority = PRIORITY_TASK5;

		myTask05_Handle = osThreadNew(StartTask05, NULL, &myTask05_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK5_TRIGGER_H_ */
