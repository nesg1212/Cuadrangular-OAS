/*
 * config.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK5_CONFIG_H_
#define SRC_TASKS_TASK5_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK5 = 256;
const char* NAME_TASK5 = "Prueba Task 5";
osPriority_t PRIORITY_TASK5 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK5_CONFIG_H_ */
