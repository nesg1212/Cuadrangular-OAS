Tarea para Presiones y BME280 (I2C)[Termometro, Barometro e Higrometro

BME280
    Funciones:
        init() -> Inicializa el sensor BME280 con el I2C seleccionado y la respectiva dirección logica
        read() -> leelos datos disponibles en el sensor
        getTemperature() -> devuelve el valor de temperatura en °c
        getHumidity() -> devuelve el valor de humedad en porcentaje 0-100%
        getPressure() -> devuelve el valor de presión atmosferica en hPa
        getAltitude() -> devuelve el valor de altura sobre el nivel del mar