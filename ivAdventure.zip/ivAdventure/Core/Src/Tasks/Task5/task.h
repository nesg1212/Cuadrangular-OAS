/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : task.h
*	@funcion    : Esta tarea interactua con los sensores de presion y BME280
*/

#ifndef SRC_TASKS_TASK5_TASK_H_
#define SRC_TASKS_TASK5_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task5

#if defined(STM32F411xE)

	#include "../../Extensions/BME280.h"

	BME280 bme280;

	void StartTask05(void *argument)
	{
		bool BME_Working;
		uint32_t Ti=millis();

		Wire3.waitAndTakeSemaphore();
		BME_Working=bme280.init(Wire3.getWire(), BME280_1_ADDRESS);
		Wire3.setSemaphore(FREE);

		Serial2.waitAndTakeSemaphore();
		if(BME_Working) Serial2.println("Tarea 5 -> BME1115 Encontrado");
		else Serial2.println("Tarea 5 -> ERROR! BME1115 NO ENCONTRADO");
		Serial2.setSemaphore(FREE);

		sensoresTemperatura[BME280_T].value=30;
		sensoresHumedad[BME280_H].value=97;
		sensoresPresion[BME280_P].value=1300;
		sensoresAltura[BME280_A].value=1234;

		for(;;)
		{/*
			if((millis()-Ti)>=1000){
				Ti=millis();
				bool isCorrect;

				Wire3.waitAndTakeSemaphore();
				isCorrect = bme280.read();
				Wire3.setSemaphore(FREE);

				if(isCorrect && BME_Working){
					float temperature,humidity,pressure,altitude;

					temperature=bme280.getTemperature();
					humidity=bme280.getHumidity();
					pressure=bme280.getPressure();
					altitude=bme280.getAltitude();

					sensoresTemperatura[BME280_T].value=(int)(temperature);
					sensoresHumedad[BME280_H].value=(int)(humidity);
					sensoresPresion[BME280_P].value=(int)(pressure);
					sensoresAltura[BME280_A].value=(int)(altitude);

					Serial2.waitAndTakeSemaphore();
					Serial2.print("Tarea 5 -> BME280 :: T=");
					Serial2.print(temperature);
					Serial2.print("°c H=");
					Serial2.print(humidity);
					Serial2.print("% P=");
					Serial2.print(pressure);
					Serial2.print("hPa A=");
					Serial2.print(altitude);
					Serial2.println("m");
					Serial2.setSemaphore(FREE);
				}
				else{
					Serial2.waitAndTakeSemaphore();
					Serial2.println("Tarea 5 -> BME280 :: ERROR");
					Serial2.setSemaphore(FREE);
				}
			} */
				osDelay(1);
		}

	  /* USER CODE END StartTask02 */
	}

#elif defined(STM32F107xC)
	void StartTask05(void *argument){
		for(;;){
			osDelay(1);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK5_TASK_H_ */
