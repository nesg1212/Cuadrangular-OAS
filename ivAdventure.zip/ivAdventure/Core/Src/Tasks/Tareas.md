GENERAL: 
- SEMAFORE
- EEPROM

Tarea 0 : Comunicacion entre ESP y STM
Tarea 1 : Temperaturas por DS18B20 y PT100
Tarea 2 : Suspencion con IMU
Tarea 3 : Tarea para la comunicación RS485.
Tarea 4 : Tarea para la comunicación CanBus.
Tarea 5 : Tarea para Presiones y BME280 (I2C)[Termometro, Barometro e Higrometro]
Tarea 6 : Tarea para lectura de depositos de liquidos, toma nivel de voltaje de baterias + PUERTOS ANALOGICOS CORRIENTE
Tarea 7 : Tarea NMEA2000, NMEA0183.
Tarea 8 : RTC_clock + TEMPORIZADORES
Tarea 9 : Tarea para SPI lectura termocupla tipo K con modulo MAX31855K + ENTRADAS DIGITALES + RPM + SALIDAS DIGITALES + ELECTROVENTILADORES
Tarea 10: Tarea para lectura del GPS.
Tarea 11: Pantalla OLED
Tarea 12: Tareas LORA :: Wearables