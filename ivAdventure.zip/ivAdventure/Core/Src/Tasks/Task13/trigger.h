/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK13_TRIGGER_H_
#define SRC_TASKS_TASK13_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask13_Handle;
osThreadAttr_t myTask13_attributes;


void Trigger_Task13(){
	#ifdef create_task13
		myTask13_attributes.name = NAME_TASK13;
		myTask13_attributes.stack_size = RAM_TASK13 * 4;
		myTask13_attributes.priority = PRIORITY_TASK13;

		myTask13_Handle = osThreadNew(StartTask13, NULL, &myTask13_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK3_TRIGGER_H_ */
