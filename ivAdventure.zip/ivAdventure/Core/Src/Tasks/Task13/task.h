/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK13_TASK_H_
#define SRC_TASKS_TASK13_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task13

#include "fatfs.h"
#include "../../Extensions/FATFS_LIBP/fatfs_sd.h"
#include "string.h"

SPI_HandleTypeDef hspi3;
static void MX_SPI3_Init(void);

FATFS fs;//file system
FIL fil;//file
FILINFO fno;
FRESULT fresult;//to store the result
UINT br, bw; //file read/write count

/* Capacity related variables */
FATFS *pfs;
DWORD fre_clust;

#define BUFFER_SIZE 128
char buffer[BUFFER_SIZE]; // to store strings..

int i=0;

int bufsize (char *buf)
{
	int i=0;
	while (*buf++ != '\0') i++;
	return i;
}

#if defined(STM32F411xE)

	void StartTask13(void *argument){
		bool USD_Working;
		uint32_t Ti_USD=millis();
		osDelay(3000);


		pinMode(MICRO_SD_GPIO_PORT, MICRO_SD_PIN, OUTPUT);
		MX_SPI3_Init();
		MX_FATFS_Init();
		osDelay(500);

		fresult = f_mount(&fs, DIR_ROOT, 1);
		if(fresult != FR_OK){
			Serial2.println("ERROR!!! NO SE ENCONTRO TARJETA...");
		}
		else{
			Serial2.println("TARJETA DETECTADA SATISFACTORIAMENTE!");
			f_getfree("", &fre_clust, &pfs);
			uint32_t total = (uint32_t)((pfs->n_fatent - 2) * pfs->csize * 0.5);
			uint32_t free_space = (uint32_t)(fre_clust * pfs->csize * 0.5);
			//Serial2.print("SD CARD Total Size: ");
			//Serial2.println(total);
			//Serial2.print("SD CARD Free Space: ");
			//Serial2.println(free_space);
			if(free_space > 0)
				USD_Working = true;
		}

		if(USD_Working){
			fresult = f_open(&fil, SENSOR_HISTORY, FA_OPEN_ALWAYS | FA_READ | FA_WRITE);
			fresult = f_close(&fil);
			fresult = f_open(&fil, ALARM_HISTORY, FA_OPEN_ALWAYS | FA_READ | FA_WRITE);
			fresult = f_close(&fil);
			fresult = f_open(&fil, SENSOR_PENDING_HISTORY, FA_OPEN_ALWAYS | FA_READ | FA_WRITE);
			fresult = f_close(&fil);
			fresult = f_open(&fil, ALARM_PENDING_HISTORY, FA_OPEN_ALWAYS | FA_READ | FA_WRITE);
			fresult = f_close(&fil);
		}

		for(;;)
		{
			if((millis() - Ti_USD) > DATALOGGER_SAMPLE_TIME){
				if(dataDatalogger.tramaAvailable){
					dataDatalogger.tramaAvailable = false;
					if(dataDatalogger.tipoSolicitudDatalogger == SEND_TRAMA_SENSOR_HISTORY){
						fresult = f_open(&fil, SENSOR_HISTORY, FA_OPEN_EXISTING | FA_READ | FA_WRITE);
						Serial2.println("TRAMA_SENSOR_HISTORY EN BUFFER");
					}
					else if(dataDatalogger.tipoSolicitudDatalogger == SEND_TRAMA_ALARM_HISTORY){
						fresult = f_open(&fil, ALARM_HISTORY, FA_OPEN_EXISTING | FA_READ | FA_WRITE);
						Serial2.println("TRAMA_ALARM_HISTORY EN BUFFER");
					}
					else if(dataDatalogger.tipoSolicitudDatalogger == SEND_TRAMA_SENSOR_PENDING_HISTORY){
						fresult = f_open(&fil, SENSOR_PENDING_HISTORY, FA_OPEN_EXISTING | FA_READ | FA_WRITE);
						Serial2.println("TRAMA_SENSOR_PENDING_HISTORY EN BUFFER");
					}
					else if(dataDatalogger.tipoSolicitudDatalogger == SEND_TRAMA_ALARM_PENDING_HISTORY){
						fresult = f_open(&fil, ALARM_PENDING_HISTORY, FA_OPEN_EXISTING | FA_READ | FA_WRITE);
						Serial2.println("TRAMA_ALARM_PENDING_HISTORY EN BUFFER");
					}
					fresult = f_lseek(&fil, f_size(&fil));
					f_printf(&fil, dataDatalogger.trama);
					f_puts("\n", &fil);
					fresult = f_close(&fil);
					Serial2.println("");
					if (fresult == FR_OK)
						Serial2.println("El archivo se escribio satisfactoriamente");
					else
						Serial2.println("Error al intentar escribir en Sensor_History.csv");
				}
			}

			osDelay(500);
		}

	}

	static void MX_SPI3_Init(void)
	{
	  hspi3.Instance = SPI3;
	  hspi3.Init.Mode = SPI_MODE_MASTER;
	  hspi3.Init.Direction = SPI_DIRECTION_2LINES;
	  hspi3.Init.DataSize = SPI_DATASIZE_8BIT;
	  hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;
	  hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
	  hspi3.Init.NSS = SPI_NSS_SOFT;
	  hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
	  hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
	  hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
	  hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	  hspi3.Init.CRCPolynomial = 10;
	  if (HAL_SPI_Init(&hspi3) != HAL_OK)
	  {
	    Error_Handler();
	  }
	}

#endif

#endif
#endif /* SRC_TASKS_TASK3_TASK_H_ */
