/*
*	Copyright ACTIONTRACKER SOLUTIONS LA ©
*	@Archivo    : task.h
*	@funcion    : Tarea #13 :: Tarea encargada de realizar transacciones con la memoria
*				  micro SD, utilizando un CRUD, librería de github y procesos FFS por hardware
*				  que vienen en STM32cubeMX.
*/

#ifndef SRC_TASKS_TASK13_CONFIG_H_
#define SRC_TASKS_TASK13_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK13 = 1024;
const char* NAME_TASK13 = "SDTask";
osPriority_t PRIORITY_TASK13 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK3_CONFIG_H_ */
