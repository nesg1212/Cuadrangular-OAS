/*
*	Copyright ACTIONTRACKER SOLUTIONS LA ©
*	@Archivo    : task.h
*	@funcion    : Tarea #14 :: Esta tarea se encarga de entablar la comunicación con el
*				  microcontrolador ESP32 bajo el protocolo de comunicaciones I2C y el
*				  Formato de datos construido por ActionTracker Solutions ©
*				  La funcionalidad principal de esta tarea es de recibir las tramas
*				  que no pudieron enviarse al servidor de datos.
*				  La idea principal es almacenar en memoria todas las tramas no enviadas
*				  y posteriormente enviarlas cuando se detecte una conexión.
*/

#ifndef SRC_TASKS_TASK14_TASK_H_
#define SRC_TASKS_TASK14_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task14

#include "../SemaphoreData/MapeoHardware.h"
#include "moduleDataloggerRequest.h"

#define STM32_UUID ((uint32_t *)0x1FFF7A10)
#define BYTES_DATALOGGER 253

void ProcessSinc();
uint8_t Rx_data[256] = {'\0'};
bool banceraComunicaciones = false;
bool banderaNuevaTrama = true;
char individualDataTrama[1];
int repeatedCycles = 1;


void CapturarDatosESP32Datalogger()
{
	if(Wire1.available() >= BYTES_DATALOGGER){
		if(banderaNuevaTrama){
			memset(dataDatalogger.trama, '\0', sizeof(dataDatalogger.trama));
			banderaNuevaTrama = false;
		}
		transmitMessageToESPDatalogger(CLEAN_BUF_I2C);
		repeatedCycles++;
		for(uint8_t i=0;i<BYTES_DATALOGGER;i++){
			Rx_data[i] = Wire1.read();
			//SerialSTM.print(" ");
			//SerialSTM.print(Rx_data[i]);
			//osDelay(1);

			if(i == 0)
				dataDatalogger.tipoSolicitudDatalogger = (TipoSolicitud_Datalogger)(Rx_data[0]);
			else if(i == 1)
				dataDatalogger.SlaveNumber = Rx_data[1];
			else if(i == 2)
				dataDatalogger.SegmentosPendientes = Rx_data[2];
			else{
				if(Rx_data[i] != 0xFF){
					individualDataTrama[0] = (char)Rx_data[i];
					strcat(dataDatalogger.trama, &individualDataTrama[0]);
					if(dataDatalogger.SegmentosPendientes == 1){
						banderaNuevaTrama = true;
						banceraComunicaciones = true;
					}
				}
			}
		}
		//SerialSTM.println("");
		//SerialSTM.println((uint8_t)dataDatalogger.tipoSolicitudDatalogger);
		//SerialSTM.println((uint8_t)dataDatalogger.SlaveNumber);
		//SerialSTM.println((uint8_t)dataDatalogger.SegmentosPendientes);
		//SerialSTM.print(dataDatalogger.trama, 255*repeatedCycles);

		//osDelay(10);

		if(dataDatalogger.SegmentosPendientes > 1){
			Wire1.EnableReceiveMode();
		}
		else{
			SerialSTM.print(dataDatalogger.trama, 255*repeatedCycles);
			dataDatalogger.tramaAvailable = true;
			Wire1.write("OK\r\n", 254);
			repeatedCycles=0;
		}
	}
}

void ProcessReceived()
{
	CapturarDatosESP32Datalogger();
	/*
	if(banceraComunicaciones)
	{
		banceraComunicaciones = false;
		if (dataReceived.tipoSolicitud == READ_PORT)
		{
			if (dataReceived.modulo == NONE_MODULE)
			{
				RequestNoneModule();
			}
			else if(dataReceived.tipoSolicitud == SCAN_DS18B20){
				uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
				ds18b20_matricula.puerto = puerto;
				ds18b20_matricula.scanner = true;
				ds18b20_matricula.offset = 0;

				addMessage("OK");
				addMessage("\r\n");
				transmitMessageToESP(INICIAL);

				SerialSTM.println("Entra en modo scanner DS18B20");
			}
		}
	}
	else
	{
		//SerialSTM.println("Dato repetido");
	}
	*/
}

void StartTask14(void *argument)
{
	osDelay(100);
	SerialSTM.println("INICIALIZA LA TAREA 14 - Datalogger");
	Wire1.setBytesToReceive(BYTES_DATALOGGER);
	if(Wire1.begin(STM32_SLAVE_ADDRESS, 400000)){
		SerialSTM.println("INICIALIZO BIEN EL I2C1");
	}
	else{
		SerialSTM.println("Error en inicialización");
	}

	for (;;){
		ProcessReceived();
		ProcessSinc();
		osDelay(1);
	}
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c){
	if(hi2c->Instance==I2C1){
		SerialSTM.println("!!!ERROR_CALLBACK_I2C!!!");
		while(Wire1.available()) Wire1.read();
		HAL_I2C_Slave_Receive_DMA(hi2c, I2C_Buffer_ESP.Buffer_raw, I2C_Buffer_ESP.numBytesToReceive);
	}
}

void ProcessSinc(){
	if(Wire1.isReceiveModeAvailable()) Wire1.EnableReceiveMode();
	if(Wire1.isDataReceived()) Wire1.refresh();
}


#endif
#endif /* SRC_TASKS_TASK14_TASK_H_ */
