#TASK 14
Copyright ACTIONTRACKER SOLUTIONS LA ©
@Archivo    : task.h
@funcion    : Tarea #14 :: Esta tarea se encarga de entablar la comunicación con el
			  microcontrolador ESP32 bajo el protocolo de comunicaciones I2C y el
			  Formato de datos construido por ActionTracker Solutions ©
			  La funcionalidad principal de esta tarea es de recibir las tramas
			  que no pudieron enviarse al servidor de datos. 
			  La idea principal es almacenar en memoria todas las tramas no enviadas
			  y posteriormente enviarlas cuando se detecte una conexión.

## CONEXIONES
* Revisar el archivo de conexiones en /Extensions/pines.h
F411: I2C2 -> ESP32 I2C1

