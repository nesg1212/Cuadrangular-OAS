/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK14_TRIGGER_H_
#define SRC_TASKS_TASK14_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask14_Handle;
osThreadAttr_t myTask14_attributes;


void Trigger_Task14(){
	#ifdef create_task14
		myTask14_attributes.name = NAME_TASK14;
		myTask14_attributes.stack_size = RAM_TASK14 * 4;
		myTask14_attributes.priority = PRIORITY_TASK14;

		myTask14_Handle = osThreadNew(StartTask14, NULL, &myTask14_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK7_TRIGGER_H_ */
