/*
 * config.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK14_CONFIG_H_
#define SRC_TASKS_TASK14_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK14 = 2048;
const char* NAME_TASK14 = "Prueba Task 14";
osPriority_t PRIORITY_TASK14 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK7_CONFIG_H_ */
