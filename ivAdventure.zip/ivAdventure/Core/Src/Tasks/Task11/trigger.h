/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK11_TRIGGER_H_
#define SRC_TASKS_TASK11_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask11_Handle;
osThreadAttr_t myTask11_attributes;


void Trigger_Task11(){
	#ifdef create_task11
		myTask11_attributes.name = NAME_TASK11;
		myTask11_attributes.stack_size = RAM_TASK11 * 4;
		myTask11_attributes.priority = PRIORITY_TASK11;

		myTask11_Handle = osThreadNew(StartTask11, NULL, &myTask11_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK11_TRIGGER_H_ */
