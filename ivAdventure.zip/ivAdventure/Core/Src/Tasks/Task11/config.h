/*
 * config.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK11_CONFIG_H_
#define SRC_TASKS_TASK11_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK11 = 1024;
const char* NAME_TASK11 = "Task11 - Display OLED";
osPriority_t PRIORITY_TASK11 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK11_CONFIG_H_ */
