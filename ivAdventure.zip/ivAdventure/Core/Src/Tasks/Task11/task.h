/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK11_TASK_H_
#define SRC_TASKS_TASK11_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task11

#if defined(STM32F411xE)

	#include "../../Extensions/Extra_String.h"
	#include "../../Extensions/SSD1306/SSD1306.h"

	SSD1306 Display1;

	void StartTask11(void *argument)
	{
		bool DISPLAY_Working;
		uint32_t Ti=millis();

		Wire3.waitAndTakeSemaphore();
		DISPLAY_Working = Display1.init(Wire3.getWire(),OLED1_ADDRESS);
		Display1.fill(0);
		Display1.draw();
		Wire3.setSemaphore(FREE);

		Serial2.waitAndTakeSemaphore();
		if(DISPLAY_Working) Serial2.println("Tarea 11 -> SSD1307 Encontrada");
		else Serial2.println("Tarea 11 -> ERROR! SSD1307 NO ENCONTRADO");
		Serial2.setSemaphore(FREE);
	/*
		Display1.circle(64, 10, 10, 1);
		Display1.text(10,25,"ole Mundo",1,0,2);
		Display1.fillTriangle(56, 60, 70, 60, 63, 50, 1);
		Display1.draw();
		osDelay(500);

	*/
		for(;;)
		{
			if((millis()-Ti)>=1000){
				Ti=millis();
				if(DISPLAY_Working){
					Wire3.waitAndTakeSemaphore();
					float temp1=float(sensoresTemperatura[PT100_1].value)/float(10);
					float temp2=float(sensoresTemperatura[BME280_1_T].value)/float(10);
					int hum1=int(sensoresHumedad[BME280_1_H].value);
					string message1=((string)"T1:")+((string)toChar(temp1))+((string)"C");
					string message2=((string)"A1:")+((string)toChar(temp2))+((string)"C");
					string message3=((string)"H1:")+((string)toChar(hum1))+((string)"%");
					Display1.text(0,10,message1,1,0,2);
					Display1.text(0,30,message2,1,0,2);
					Display1.text(0,50,message3,1,0,2);
					Display1.draw();
					Wire3.setSemaphore(FREE);

					Serial2.waitAndTakeSemaphore();
					Serial2.println("Tarea 11 -> SSD1306 :: Escritura");
					Serial2.setSemaphore(FREE);
				}
				else{
					Serial2.waitAndTakeSemaphore();
					Serial2.println("Tarea 11 -> SSD1306 :: ERROR");
					Serial2.setSemaphore(FREE);
				}
			}
			osDelay(1);
		}
	}

#elif defined(STM32F107xC)

	void StartTask11(void *argument){
		for(;;){
			osDelay(500);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK11_TASK_H_ */
