/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK7_TASK_H_
#define SRC_TASKS_TASK7_TASK_H_

#include "../Base_Tasks.h"
#ifdef create_task7

#if defined(STM32F411xE)

	void StartTask07(void *argument)
	{
		for(;;){
			osDelay(500);
		}
	  /* USER CODE END StartTask02 */
	}

#elif defined(STM32F107xC)

	void StartTask07(void *argument){
		for(;;){
			osDelay(500);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK7_TASK_H_ */
