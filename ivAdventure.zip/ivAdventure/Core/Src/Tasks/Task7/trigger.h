/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK7_TRIGGER_H_
#define SRC_TASKS_TASK7_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask07_Handle;
osThreadAttr_t myTask07_attributes;


void Trigger_Task07(){
	#ifdef create_task7
		myTask07_attributes.name = NAME_TASK7;
		myTask07_attributes.stack_size = RAM_TASK7 * 4;
		myTask07_attributes.priority = PRIORITY_TASK7;

		myTask07_Handle = osThreadNew(StartTask07, NULL, &myTask07_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK7_TRIGGER_H_ */
