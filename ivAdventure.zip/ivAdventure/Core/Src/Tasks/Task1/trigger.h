/*
 * trigger.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK1_TRIGGER_H_
#define SRC_TASKS_TASK1_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask_01Handle;
osThreadAttr_t myTask_01_attributes;

void Trigger_Task1(){
	#ifdef create_task1
		myTask_01_attributes.name = NAME_TASK1;
		myTask_01_attributes.stack_size = RAM_TASK1 * 4;
		myTask_01_attributes.priority = PRIORITY_TASK1;

		myTask_01Handle = osThreadNew(StartTask01, NULL, &myTask_01_attributes);
	#endif
}




#endif /* SRC_TASKS_TASK1_TRIGGER_H_ */
