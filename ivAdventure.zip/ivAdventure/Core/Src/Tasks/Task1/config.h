/*
 * config.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK1_CONFIG_H_
#define SRC_TASKS_TASK1_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK1 = 256;
const char* NAME_TASK1 = "Prueba Task 1";
osPriority_t PRIORITY_TASK1 = (osPriority_t) osPriorityHigh1;



#endif /* SRC_TASKS_TASK1_CONFIG_H_ */
