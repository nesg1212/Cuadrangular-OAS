/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : task.h
*	@funcion    : Tarea encargada de la lectura de temperaturas
*/


#ifndef SRC_TASKS_TASK1_TASK_H_
#define SRC_TASKS_TASK1_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task1

#if defined(STM32F411xE)
#include "../../Extensions/ADS1115.h"
#include "../../Extensions/DS18b20.h"

ADS1115 ADC_EXT1;
DS18B20 ds18b20;
uint8_t NEW_ROM[8];
DS18B20_modos MODE_DS18B20 = MODO_ESCANER;

float temperaturaPT100(float voltaje){
	return((125*voltaje)-168.25);
}

void StartTask01(void *argument)
{
	bool ADC_Working;
	bool DS18B20_Working;
	bool DS18B20_Ready = false;
	uint32_t Ti=millis();
	uint32_t Ti2=millis();

	//pinMode(GPIOB, GPIO_PIN_4, INPUT);

	Wire3.waitAndTakeSemaphore();
	ADC_Working = ADC_EXT1.init(Wire3.getWire(),ADS1115_1_ADDRESS);
	Wire3.setSemaphore(FREE);

	DS18B20_Working = ds18b20.init();

	Serial2.waitAndTakeSemaphore();
	if(ADC_Working) Serial2.println("Tarea 1a -> ADS1115 :: Encontrado");
	else Serial2.println("Tarea 1a -> ERROR! ADS1115 NO ENCONTRADO");
	if(DS18B20_Working) Serial2.println("Tarea 1b -> DS18B20 :: Encontrado/s");
	else Serial2.println("Tarea 1b -> ERROR! DS18B20 NO ENCONTRADO");
	Serial2.setSemaphore(FREE);

	//EXAMPLE
	sensoresTemperatura[PT100_1].value=(int)(-12);
	sensoresTemperatura[PT100_2].value=(int)(21);
	sensoresTemperatura[PT100_3].value=(int)(-45);
	sensoresTemperatura[PT100_4].value=(int)(52);
	//CLOSE

	for(;;)
	{/*
		if((millis()-Ti) >= TEMPERATURA_PT100_SAMPLE_TIME){
			Ti=millis();
			if(ADC_Working){
				float voltChannel_0,voltChannel_1,voltChannel_2,voltChannel_3;
				float temp1,temp2,temp3,temp4;

				Wire3.waitAndTakeSemaphore();
				ADC_EXT1.setGain(V_6_144);
				voltChannel_0=ADC_EXT1.read_Voltage(SINGLE_A0);
				voltChannel_1=ADC_EXT1.read_Voltage(SINGLE_A1);
				voltChannel_2=ADC_EXT1.read_Voltage(SINGLE_A2);
				voltChannel_3=ADC_EXT1.read_Voltage(SINGLE_A3);
				Wire3.setSemaphore(FREE);

				temp1=temperaturaPT100(voltChannel_0);
				temp2=temperaturaPT100(voltChannel_1);
				temp3=temperaturaPT100(voltChannel_2);
				temp4=temperaturaPT100(voltChannel_3);

				sensoresTemperatura[PT100_1].value=(int)(temp1*10);
				sensoresTemperatura[PT100_2].value=(int)(temp2*10);
				sensoresTemperatura[PT100_3].value=(int)(temp3*10);
				sensoresTemperatura[PT100_4].value=(int)(temp4*10);

				Serial2.waitAndTakeSemaphore();
				Serial2.print("Tarea 1a -> ADS1115 :: T1:");
				Serial2.print(temp1);
				Serial2.print("°c T2:");
				Serial2.print(temp2);
				Serial2.print("°c T3:");
				Serial2.print(temp3);
				Serial2.print("°c T4:");
				Serial2.println(temp4);
				Serial2.setSemaphore(FREE);
			}
			else{
				Serial2.waitAndTakeSemaphore();
				Serial2.println("Tarea 1 -> ADS1115 ERROR");
				Serial2.setSemaphore(FREE);
			}
		}

		if((millis()-Ti2)>=2000){
			Ti2=millis();

			if(MODE_DS18B20 == MODO_ESCANER){
				float Temporal = 0;
				if(NEW_ROM[0] != 0){
					Temporal = ds18b20.getMuxTemperature(NEW_ROM) + (float)ds18b20_matricula.offset;
					osDelay(10);
					Serial2.print("Tarea 1b -> DS18B20 :: DS18B20 Escaneado:");
					for(int i=0;i<8;i++){
						ds18b20_matricula.ROM[i] = NEW_ROM[i];
						Serial2.print(NEW_ROM[i],HEX);
						Serial2.print("-");
						osDelay(1);
					}
					Serial2.print(" con T = ");
					Serial2.println(Temporal);
				}
				else{
					Serial2.println("Tarea 1b -> DS18B20 :: SENSOR NO CONECTADO");
					for(int i=0;i<8;i++){
						ds18b20_matricula.ROM[i] = 0;
					}
				}
				ds18b20_matricula.Temperatura = (uint8_t)Temporal;
			}

			if(MODE_DS18B20 == MODO_LECTURA){
				Serial2.waitAndTakeSemaphore();
				Serial2.print("Tarea 1b -> DS18B20 :: ");
				for(uint8_t i=0;i<numero_sensores_temperatura;i++){
					if(ds18b20.isValid(i)){
						if(DS18B20_Ready){
							sensoresTemperatura[i].value = (uint8_t)ds18b20.getMuxTemperature(i);
							if(sensoresTemperatura[i].value != 0){
								sensoresTemperatura[i].value += (uint8_t)ds18b20.getOffset(i);
							}
						}
						else{
							sensoresTemperatura[i].value = 0;
						}
						Serial2.print("T");
						Serial2.print(sensoresTemperatura[i].value);
						Serial2.print("°C  ");
					}
				}
				Serial2.println("");
				Serial2.setSemaphore(FREE);
			}

			if(ds18b20_matricula.scanner){
				MODE_DS18B20 = MODO_ESCANER;
			}
			else{
				MODE_DS18B20 = MODO_LECTURA;
				if(ds18b20_matricula.almacenar){
					ds18b20_matricula.almacenar = false;
					ds18b20.storeInformation(NEW_ROM, ds18b20_matricula.puerto, ds18b20_matricula.offset);
				}
			}

			if(MODE_DS18B20 == MODO_ESCANER){
				for(int i=0;i<8;i++) NEW_ROM[i]=0;
				if(ds18b20.isSlaveConnected()){
					ds18b20.getNewROM(NEW_ROM);
					if(NEW_ROM[0] != 0){
						ds18b20.orderMeasure(NEW_ROM);
						ds18b20.initAllMeasure();
					}
				}
			}

			if(MODE_DS18B20 == MODO_LECTURA){
				osDelay(10);
				if(ds18b20.isSlaveConnected()){
					ds18b20.orderMeasure();
					ds18b20.initAllMeasure();
					DS18B20_Ready = true;
				}
				else{
					DS18B20_Ready = false;
					Serial2.println("Tarea 1b -> DS18B20 :: ERROR! NO HAY ESCLAVOS");
				}
			}

		}*/
		osDelay(1);
	}
}

#elif defined(STM32F107xC)

	#include "../../Extensions/LM75.h"

	LM75 lm75;
	float THYST;
	float TOS;

	float temperaturaPT100(float voltaje){
		return((125*voltaje)-168.25); //Ecuación cambiará cuando se hagan pruebas de funcionamiento
	}

	void StartTask01(void *argument)//2-PT100 + 1-LM75
	{
		uint32_t Ti=millis();
		bool LM75_Working;

		Serial3.println("Tarea 1a -> PT100 :: INICIALIZADA");

		Wire1.waitAndTakeSemaphore();
		LM75_Working=lm75.init(Wire1.getWire(), LM75_ADDRESS);
		Wire1.setSemaphore(FREE);

		THYST = lm75.THYST_Read();
		osDelay(20);
		TOS = lm75.TOS_Read();
		osDelay(20);
		lm75.sleepMode(false);
		osDelay(20);

		for(;;){
			if((millis()-Ti) >= TEMPERATURA_PT100_SAMPLE_TIME){
				float temp1,temp2;
				temp1=temperaturaPT100(3);
				temp1=temperaturaPT100(2.5);
				sensoresTemperatura[PT100_1].value=(int)(temp1*10);
				sensoresTemperatura[PT100_2].value=(int)(temp2*10);
				if(LM75_Working)
					sensoresTemperatura[LM75_1].value=(int)lm75.temperatureRead();
			}
			osDelay(10);
		}
	}
#endif
#endif
#endif /* SRC_TASKS_TASK1_TASK_H_ */
