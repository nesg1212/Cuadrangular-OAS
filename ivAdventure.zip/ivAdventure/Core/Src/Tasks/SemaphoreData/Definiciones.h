/*
 * Definiciones.h
 *
 *  Created on: 16 sep. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_TASKS_SEMAPHOREDATA_DEFINICIONES_H_
#define SRC_TASKS_SEMAPHOREDATA_DEFINICIONES_H_

#if defined(STM32F411xE)
	/*Temperatura*/
	#define PT100_1 	 0
	#define PT100_2 	 1
	#define PT100_3 	 2
	#define PT100_4 	 3
	#define TERMOCUPLA_1 4
	#define TERMOCUPLA_2 5
	#define TERMOCUPLA_3 6
	#define BME280_T     7
	//#define DS18B20_1   5
	//#define DS18B20_2   6

	/*HUMEDAD*/
	#define BME280_H  0

	/*PRESION*/
	#define BME280_P  0

	/*ALTURA ASNM*/
	#define BME280_A  0
	#define GPS_1_A   1

	/*IMU*/
	#define IMU_LSM9DS1_1  0

	/*VOLTAJE*/
	#define VOLTAJE_BATERIA_1  0
	#define VOLTAJE_BATERIA_2  1
	#define VOLTAJE_BATERIA_3  2

	/*DIGITAL INPUT*/
	#define DIGITAL_INPUT_1  0
	#define DIGITAL_INPUT_2  1
	#define DIGITAL_INPUT_3  2
	#define DIGITAL_INPUT_4  3

	/*RPM INPUT*/
	#define RPM_INPUT_1  0
	#define RPM_INPUT_2  1
	#define RPM_INPUT_3  2
	#define RPM_INPUT_4  3

	/*GPS*/
	#define GPS_1_DATA   0

	/*ANALOG INPUT*/
	#define ANALOG_INPUT_1  0
	#define ANALOG_INPUT_2  1
	#define ANALOG_INPUT_3  2
	#define ANALOG_INPUT_4  3

	/*RTC*/
	#define RTC_1       0

	/*DIGITAL OUTPUT*/
	#define DIGITAL_OUTPUT_1  0
	#define DIGITAL_OUTPUT_2  1
	#define DIGITAL_OUTPUT_3  2
	#define DIGITAL_OUTPUT_4  3
	#define DIGITAL_OUTPUT_5  4
	#define DIGITAL_OUTPUT_6  5
	#define DIGITAL_OUTPUT_7  6
	#define DIGITAL_OUTPUT_8  7
	#define DIGITAL_OUTPUT_9  8
	#define DIGITAL_OUTPUT_10 9
	#define DIGITAL_OUTPUT_11 10
	#define DIGITAL_OUTPUT_12 11
	#define DIGITAL_OUTPUT_13 12
	#define DIGITAL_OUTPUT_14 13
	#define DIGITAL_OUTPUT_15 14
	#define DIGITAL_OUTPUT_16 15
	#define DIGITAL_OUTPUT_17 16
	#define DIGITAL_OUTPUT_18 17

	/*ELECTROVENTILADORES OUTPUT*/
	#define ELECTROVENTILADORES_OUTPUT_1  0
	#define ELECTROVENTILADORES_OUTPUT_2  1
	#define ELECTROVENTILADORES_OUTPUT_3  2

#elif defined(STM32F107xC)
	/*Temperatura*/
	#define PT100_1 	 0
	#define PT100_2 	 1
	#define LM75_1       2

	/*HUMEDAD*/
	#define BME280_H  0

	/*PRESION*/
	#define BME280_P  0

	/*ALTURA ASNM*/
	#define BME280_A  0
	#define GPS_1_A   1

	/*IMU*/
	#define IMU_LSM9DS1_1  0

	/*VOLTAJE*/
	#define VOLTAJE_BATERIA_1  0
	#define VOLTAJE_BATERIA_2  1
	#define VOLTAJE_BATERIA_3  2

	/*DIGITAL INPUT*/
	#define DIGITAL_INPUT_1  0
	#define DIGITAL_INPUT_2  1
	#define DIGITAL_INPUT_3  2
	#define DIGITAL_INPUT_4  3

	/*RPM INPUT*/
	#define RPM_INPUT_1  0
	#define RPM_INPUT_2  1
	#define RPM_INPUT_3  2
	#define RPM_INPUT_4  3

	/*GPS*/
	#define GPS_1_DATA   0

	/*ANALOG INPUT*/
	#define ANALOG_INPUT_1  0
	#define ANALOG_INPUT_2  1
	#define ANALOG_INPUT_3  2
	#define ANALOG_INPUT_4  3
	#define ANALOG_INPUT_5  4
	#define ANALOG_INPUT_6  5
	#define ANALOG_INPUT_7  6
	#define ANALOG_INPUT_8  7

	/*RTC*/
	#define RTC_1       0

	/*DIGITAL OUTPUT*/
	#define DIGITAL_OUTPUT_1  0
	#define DIGITAL_OUTPUT_2  1
	#define DIGITAL_OUTPUT_3  2
	#define DIGITAL_OUTPUT_4  3
	#define DIGITAL_OUTPUT_5  4
	#define DIGITAL_OUTPUT_6  5
	#define DIGITAL_OUTPUT_7  6
	#define DIGITAL_OUTPUT_8  7
	#define DIGITAL_OUTPUT_9  8
	#define DIGITAL_OUTPUT_10 9
	#define DIGITAL_OUTPUT_11 10
	#define DIGITAL_OUTPUT_12 11
	#define DIGITAL_OUTPUT_13 12
	#define DIGITAL_OUTPUT_14 13
	#define DIGITAL_OUTPUT_15 14
	#define DIGITAL_OUTPUT_16 15
	#define DIGITAL_OUTPUT_17 16
	#define DIGITAL_OUTPUT_18 17

	/*ELECTROVENTILADORES OUTPUT*/
	#define ELECTROVENTILADORES_OUTPUT_1  0
	#define ELECTROVENTILADORES_OUTPUT_2  1
	#define ELECTROVENTILADORES_OUTPUT_3  2
#endif


#endif /* SRC_TASKS_SEMAPHOREDATA_DEFINICIONES_H_ */
