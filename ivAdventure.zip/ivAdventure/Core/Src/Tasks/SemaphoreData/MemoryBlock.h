/*
 * MemoryBlock.h
 *
 *  Created on: 16 sep. 2020
 *      Author: JoseBenitez
 */

#ifndef SRC_TASKS_SEMAPHOREDATA_MEMORYBLOCK_H_
#define SRC_TASKS_SEMAPHOREDATA_MEMORYBLOCK_H_

#include "SemaphoreData.h"

typedef enum numberBlocksMemory{
	ONE_BYTES   =1,
	CHAR_BYTES  =1,
	TWO_BYTES   =2,
	FLOAT_BYTES =2,
	INT_BYTES   =2
};

/********************BLOQUE DE CUENTA HORAS [0-49]*******************/
#define TEMPORIZADOR_BASE 0//[0, 5, 10, 15, 20, 25, 30, 35, 40, 45]
#define TEMPORIZADOR_LONG 5

#define HABILTEMP  0
#define ESTADO_MEM 1
#define HORAREG    2
#define FECHAREG   3
#define MINUTOSMEM 4

/********************BLOQUE DE TANQUES [50-799]*******************/
#define TANQUE_BASE 50//[50, 200, 350, 500, 650]
#define TANQUE_LONG 150

#define HABILT 0
#define TIPOT 1
#define NIVELEST 2
#define RT_BASE 3 //3-10
#define LT_BASE 11//11-20
#define HT_BASE 21//21-30
#define WT_BASE 31//31-40
#define EX_BASE 49//49-149

/********************BLOQUE DE ANALOGICOS [800-815]*******************/
#define ANALOGICO_BASE 800//[800, 804, 808, 812]
#define ANALOGICO_LONG 4

#define HABIL_A 0
#define PENDIENTE_A 1
#define INTERSECCION_A 2

/********************BLOQUE DE PID [820-847]*******************/
#define PID_BASE 816//[816, 824, 832, 840]
#define PID_LONG 8

#define HABIL_PID 0
#define KP_PID 1
#define KI_PID 2
#define KD_PID 3
#define SETPOINT_PID 4
#define INTPUT_PID 5
#define OUTPUT_PID 6
#define TM_PID 7


#endif /* SRC_TASKS_SEMAPHOREDATA_MEMORYBLOCK_H_ */
