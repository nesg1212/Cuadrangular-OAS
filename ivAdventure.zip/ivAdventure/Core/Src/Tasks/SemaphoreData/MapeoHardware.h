/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : MapeoHardware.h
*	@funcion    : define el numero de sensores disponibles en la electronica
*				  del hardware.
*				  Este archivo es editado para las diferentes placas electronicas
*/
#ifndef semaforo_mapeo_hardware
#define semaforo_mapeo_hardware

#if defined(STM32F411xE)
	#define numero_sensores_temperatura 16
	#define numero_sensores_humedad 1
	#define numero_sensores_velocidad 0
	#define numero_sensores_voltaje 3
	#define numero_entradas_digitales 4
	#define numero_sensores_proximidad 0
	#define numero_sensores_liquido 5
	#define numero_sensores_presion 1
	#define numero_sensores_rpm 5
	#define numero_suspensiones 0
	#define numero_alturas 2
	#define numero_rebotes 0
	#define numero_sensores_inclinaciones 1
	#define numero_marchas_instaladas 1
	#define numero_sensores_torque 0
	#define numero_sensores_potencia 0
	#define numero_sensores_gps 1
	#define numero_neumaticos 16
	#define numero_ventiladores 3
	#define numero_winches 3
	#define numero_sensores_analogicos 4
	#define numero_sensores_temporizadores 10
	#define numero_maximo_sensores_sysgo 0
	#define numero_actuadores_interruptor 18
	#define numero_total_shift 1
	#define numeroSensoresRTC 1

#elif defined(STM32F107xC)
	#define numero_sensores_temperatura 3
	#define numero_sensores_humedad 1
	#define numero_sensores_velocidad 0
	#define numero_baterias 1
	#define numero_sensores_voltaje numero_baterias
	#define numero_entradas_digitales 1
	#define numero_sensores_proximidad 0
	#define numero_sensores_liquido 4
	#define numero_sensores_presion 1
	#define numero_sensores_rpm 0
	#define numero_suspensiones 0
	#define numero_alturas 0
	#define numero_rebotes 0
	#define numero_sensores_inclinaciones 1
	#define numero_marchas_instaladas 0
	#define numero_sensores_torque 0
	#define numero_sensores_potencia 0
	#define numero_actuadores_interruptor 2
	#define numero_sensores_gps 1
	#define numero_neumaticos 0
	#define numero_ventiladores 2
	#define numero_winches 0
	#define numero_sensores_analogicos 8
	#define numero_sensores_temporizadores 10
	#define numero_total_shift 0
	#define numero_maximo_sensores_sysgo 0

	#define numeroSensoresRTC 1
#endif


#endif
