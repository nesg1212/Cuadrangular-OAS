/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : MapeoHardware.h
*	@funcion    : define el numero de sensores disponibles en la electronica
*				  del hardware.
*				  Este archivo es editado para las diferentes placas electronicas
*/

#ifndef SRC_TASKS_SEMAPHOREDATA_SEMAPHOREDATA_H_
#define SRC_TASKS_SEMAPHOREDATA_SEMAPHOREDATA_H_

#include "../../Util/enums.h"
#include "../../Util/structs.h"

#define numeroEntradas 100
#define numeroSalidas 40

/******   ENTRADAS   ******/
Sensor sensoresTemperatura[numero_sensores_temperatura];//OK
Sensor sensoresHumedad[numero_sensores_humedad];//OK
Sensor sensoresVelocidad[numero_sensores_velocidad];//0
Sensor sensoresVoltaje[numero_sensores_voltaje];//OK
Sensor sensoresDigitales[numero_entradas_digitales];//OK
Sensor sensoresProximidad[numero_sensores_proximidad];//0
Tanque sensoresLiquidoTanques[numero_sensores_liquido];//OK
Sensor sensoresPresion[numero_sensores_presion];//OK
Sensor sensoresRPM[numero_sensores_rpm];//OK
Sensor sensoresSuspension[numero_suspensiones];//0
Sensor sensoresAltura[numero_alturas];//OK -- falta GPS
Sensor sensoresRebotes[numero_rebotes];//0
Sensor sensoresInclinaciones[numero_sensores_inclinaciones];//OK
Sensor sensoresMarchas[numero_marchas_instaladas];//NO SE SABE COMO SE RECOLECTA
Sensor sensoresTorque[numero_sensores_torque];//0
Sensor sensoresPotencia[numero_sensores_potencia];//0
GPS sensoresGPS[numero_sensores_gps];//OK
Sensor sensoresNeumaticos[numero_neumaticos];//DEPENDE DE LORA
Sensor sensoresAnalogicos[numero_sensores_analogicos];//OK
Temporizador sensoresTemporizadores[numero_sensores_temporizadores];//OK
Sensor sensoresSysgo[numero_maximo_sensores_sysgo];//DEPENDE DE LORA

/******   SALIDAS   ******/
Actuador salidasDigital[numero_actuadores_interruptor];//OK
Actuador actuadoresVentiladores[numero_ventiladores];//OK
Actuador actuadoresWinches[numero_winches];//NO TENEMOS EN SENSOR DE DISTANCIA!!!

Port mapeoPuertos[numeroEntradas + numeroSalidas];
DS18B20_info ds18b20_matricula;

void setearValoresEjemploMientrasSeConectanSensoresReales();

void InitSemaphore()
{

	for (uint8_t var = 0; var < (numeroEntradas + numeroSalidas); ++var){
		mapeoPuertos[var].port = var;
	}

	uint8_t numero_puerto = 0;

	for (uint8_t var = 0; var < numero_sensores_temperatura; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = TEMPERATURA;
		sensoresTemperatura[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_temperatura;
	for (uint8_t var = 0; var < numero_sensores_humedad; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = HUMEDAD;
		sensoresHumedad[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_humedad;
	for (uint8_t var = 0; var < numero_sensores_velocidad; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = VELOCIDAD;
		sensoresVelocidad[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_velocidad;
	for (uint8_t var = 0; var < numero_sensores_voltaje; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = VOLTAJE;
		sensoresVoltaje[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_voltaje;
	for (uint8_t var = 0; var < numero_entradas_digitales; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = ENT_DIGITAL;
		sensoresDigitales[var].port = port;
	}

	numero_puerto = numero_puerto + numero_entradas_digitales;
	for (uint8_t var = 0; var < numero_sensores_proximidad; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = PROXIMIDAD;
		sensoresProximidad[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_proximidad;
	for (uint8_t var = 0; var < numero_sensores_liquido; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = LIQUIDO;
		sensoresLiquidoTanques[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_liquido;
	for (uint8_t var = 0; var < numero_sensores_presion; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = PRESION;
		sensoresPresion[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_presion;
	for (uint8_t var = 0; var < numero_sensores_rpm; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = RPM;
		sensoresRPM[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_rpm;
	for (uint8_t var = 0; var < numero_suspensiones; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = SUSPENCION;
		sensoresSuspension[var].port = port;
	}

	numero_puerto = numero_puerto + numero_suspensiones;
	for (uint8_t var = 0; var < numero_alturas; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = ALTURA;
		sensoresAltura[var].port = port;
	}

	numero_puerto = numero_puerto + numero_alturas;
	for (uint8_t var = 0; var < numero_rebotes; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = REBOTE;
		sensoresRebotes[var].port = port;
	}

	numero_puerto = numero_puerto + numero_rebotes;
	for (uint8_t var = 0; var < numero_sensores_inclinaciones; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = INCLINACIONES;
		sensoresInclinaciones[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_inclinaciones;
	for (uint8_t var = 0; var < numero_marchas_instaladas; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = MARCHA;
		sensoresMarchas[var].port = port;
	}

	numero_puerto = numero_puerto + numero_marchas_instaladas;
	for (uint8_t var = 0; var < numero_neumaticos; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = NEUMATICO;
		sensoresNeumaticos[var].port = port;
	}

	numero_puerto = numero_puerto + numero_neumaticos;
	for (uint8_t var = 0; var < numero_sensores_torque; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = TORQUE;
		sensoresTorque[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_torque;
	for (uint8_t var = 0; var < numero_sensores_potencia; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = POTENCIA;
		sensoresPotencia[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_potencia;
	for (uint8_t var = 0; var < numero_sensores_analogicos; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = ANALOGICA;
		sensoresAnalogicos[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_analogicos;
	for (uint8_t var = 0; var < numero_sensores_temporizadores; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = TEMPORIZADOR;
		sensoresTemporizadores[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_temporizadores;
	for (uint8_t var = 0; var < numero_sensores_gps; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = GPS_SENSOR;
		sensoresGPS[var].port = port;
	}

	numero_puerto = numero_puerto + numero_sensores_gps;
	for (uint8_t var = 0; var < numero_maximo_sensores_sysgo; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = SYSGO;
		sensoresSysgo[var].port = port;
	}

	numero_puerto = numero_puerto + numero_maximo_sensores_sysgo;
	for (uint8_t var = 0; var < numero_entradas_digitales; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = FREE_PORT;
	}

	/**
	 * PUERTOS DE SALIDA
	*/

	numero_puerto = numeroEntradas;
	for (uint8_t var = 0; var < numero_winches; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = SALIDA_WINCH;
		salidasDigital[var].port = port;
	}

	numero_puerto = numero_puerto + numero_winches;
	for (uint8_t var = 0; var < numero_ventiladores; ++var){
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = SALIDA_VENT;
		actuadoresVentiladores[var].port = port;
	}

	numero_puerto = numero_puerto + numero_ventiladores + numero_total_shift;
	for (uint8_t var = 0; var < numero_actuadores_interruptor; ++var)
	{
		uint8_t port = numero_puerto + var;
		mapeoPuertos[port].tipoEntrada = SALIDA_DIGITAL;
		salidasDigital[var].port = port;
	}

	setearValoresEjemploMientrasSeConectanSensoresReales();
}

void setearValoresEjemploMientrasSeConectanSensoresReales(){
	int id;

	for(int i=0;i<numero_sensores_temperatura;i++){
		id = sensoresTemperatura[0].port;
		mapeoPuertos[id].value = i+25;
	}
/*
	id = sensoresMagnetometro[0].port;
	mapeoPuertos[id].value = 95;

	id = sensoresVoltaje[0].port;
	mapeoPuertos[id].value = 95;

	id = sensoresPresion[0].port;
	mapeoPuertos[id].value = 95;
*/
}

void obtener_valores_iniciales(){

}

#endif /* SRC_TASKS_SEMAPHOREDATA_SEMAPHOREDATA_H_ */
