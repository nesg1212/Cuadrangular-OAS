/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK10_TRIGGER_H_
#define SRC_TASKS_TASK10_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask10_Handle;
osThreadAttr_t myTask10_attributes;


void Trigger_Task10(){
	#ifdef create_task10
		myTask10_attributes.name = NAME_TASK10;
		myTask10_attributes.stack_size = RAM_TASK10;
		myTask10_attributes.priority = PRIORITY_TASK10;

		myTask10_Handle = osThreadNew(StartTask10, NULL, &myTask10_attributes);
	#endif
}




#endif /* SRC_TASKS_TASK10_TRIGGER_H_ */
