/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK10_TASK_H_
#define SRC_TASKS_TASK10_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task10

#if defined(STM32F411xE)

	#include "../../Extensions/GPS_NEO.h"

	Serial Serial6(USART6);
	GPS_NEO GPS1;
	GNSS_RESPONSE responseGnss;

	void StartTask10(void *argument)
	{
		uint32_t Ti=millis();
		GPS1.init(Serial6);
		Serial2.waitAndTakeSemaphore();
		Serial2.println("Tarea 10 -> GPS INICIALIZADO");
		Serial2.setSemaphore(FREE);
	/*
		char horaInicial[]="210809165604";
		sensoresGPS[GPS_1_DATA].validez = 1;
		sensoresGPS[GPS_1_DATA].hora = horaInicial;
		sensoresGPS[GPS_1_DATA].latitud = 7.100159;
		sensoresGPS[GPS_1_DATA].logitud = -73.122039;
		sensoresGPS[GPS_1_DATA].numSat = 5;
		sensoresAltura[GPS_1_A].value = 1025;
	*/
		for(;;)
		{

			if((millis()-Ti)>=1000){
				Ti=millis();
				responseGnss=GPS1.encode(GNGGA);
				Serial2.waitAndTakeSemaphore();
				Serial2.print("Tarea 10 -> GNSS :: ");
				if(responseGnss==CONECTED){

					int val = GPS1.getValidationState();
					char* hora = GPS1.getTime();
					uint8_t numSat = GPS1.getNumSatellites();
					double lat = GPS1.getLatitude();
					double lon = GPS1.getLongitude();
					double asnm = GPS1.getHeightAboveSeaLevel();

					sensoresGPS[GPS_1_DATA].validez = val;
					sensoresGPS[GPS_1_DATA].hora = hora;
					sensoresGPS[GPS_1_DATA].latitud = lat;
					sensoresGPS[GPS_1_DATA].logitud = lon;
					sensoresGPS[GPS_1_DATA].numSat = numSat;
					sensoresAltura[GPS_1_A].value = asnm;

					Serial2.print("val:");Serial2.print(val);
					Serial2.print(", UTC:");Serial2.print(hora);
					Serial2.print(", sat:");Serial2.print(numSat);
					Serial2.print(", Lat:");Serial2.print(lat);
					Serial2.print(", Long:");Serial2.print(lon);
					Serial2.print(", asnm:");Serial2.print(asnm);
					Serial2.println("m");
				}
				if(responseGnss==WAITING_FOR_SATELLITE){
					Serial2.println("Esperando a recibir informacion...");
				}
				if(responseGnss==ISNT_VALID){
					Serial2.println("El dato recibido no es valido para GGA");
				}
				Serial2.setSemaphore(FREE);
			}

			osDelay(1);
		}
	}

#elif defined(STM32F107xC)

#include "../../Extensions/GPS_NEO.h"

	Serial Serial2(USART2);
	GPS_NEO GPS1;
	GNSS_RESPONSE responseGnss;

	void StartTask10(void *argument)
	{
		uint32_t Ti=millis();
		GPS1.init(Serial2);
		Serial3.waitAndTakeSemaphore();
		Serial3.println("Tarea 10 -> GPS INICIALIZADO");
		Serial3.setSemaphore(FREE);
	/*
		char horaInicial[]="210809165604";
		sensoresGPS[GPS_1_DATA].validez = 1;
		sensoresGPS[GPS_1_DATA].hora = horaInicial;
		sensoresGPS[GPS_1_DATA].latitud = 7.100159;
		sensoresGPS[GPS_1_DATA].logitud = -73.122039;
		sensoresGPS[GPS_1_DATA].numSat = 5;
		sensoresAltura[GPS_1_A].value = 1025;
	*/
		for(;;)
		{

			if((millis()-Ti)>=1000){
				Ti=millis();
				responseGnss=GPS1.encode(GNGGA);
				Serial3.waitAndTakeSemaphore();
				Serial3.print("Tarea 10 -> GNSS :: ");
				if(responseGnss==CONECTED){
					int val = GPS1.getValidationState();
					char* hora = GPS1.getTime();
					uint8_t numSat = GPS1.getNumSatellites();
					double lat = GPS1.getLatitude();
					double lon = GPS1.getLongitude();
					double asnm = GPS1.getHeightAboveSeaLevel();

					sensoresGPS[GPS_1_DATA].validez = val;
					sensoresGPS[GPS_1_DATA].hora = hora;
					sensoresGPS[GPS_1_DATA].latitud = lat;
					sensoresGPS[GPS_1_DATA].logitud = lon;
					sensoresGPS[GPS_1_DATA].numSat = numSat;
					sensoresAltura[GPS_1_A].value = asnm;

					Serial3.print("val:");Serial3.print(val);
					Serial3.print(", UTC:");Serial3.print(hora);
					Serial3.print(", sat:");Serial3.print(numSat);
					Serial3.print(", Lat:");Serial3.print(lat);
					Serial3.print(", Long:");Serial3.print(lon);
					Serial3.print(", asnm:");Serial3.print(asnm);
					Serial3.println("m");
				}
				if(responseGnss==WAITING_FOR_SATELLITE){
					Serial3.println("Esperando a recibir informacion...");
				}
				if(responseGnss==ISNT_VALID){
					Serial3.println("El dato recibido no es valido para GGA");
				}
				Serial3.setSemaphore(FREE);
			}

			osDelay(1);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK10_TASK_H_ */
