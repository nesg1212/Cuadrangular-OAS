/*
 * config.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK10_CONFIG_H_
#define SRC_TASKS_TASK10_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK10 = 1024;
const char* NAME_TASK10 = "Prueba Task 10";
osPriority_t PRIORITY_TASK10 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK10_CONFIG_H_ */
