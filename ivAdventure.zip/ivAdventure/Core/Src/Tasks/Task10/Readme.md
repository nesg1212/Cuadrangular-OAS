Tarea para lectura del GPS.

NOTA: el modulo GNSS NEO M8N adquirido no dispone de la memoria FLASH que la hoja de datos propone, por ende no puede actualizarse a la utima versión para adquirir las redes satelitales de Galileo y otras!.
Satelites recibidos: - GPS + GLONASS

    Enums:
        NMEA_TYPE: solicita trama NMEA especifica para leer, solo se propuso para GNGGA.
        GNSS_RESPONSE: respuestas del modulo para con la conexión y deteccion de errores
    Funciones:
        init -> inicializa el puerto serie seleccionado para dar inicio a la recepción de información.
        encode -> recibe la información por puerto serie y la deja disponible para leerla luego
        int getValidationState()-> retorna codigo de validación:: 0 es invalido
	   char* getTime()-> retorna un array char con la hora UTC (Colombia tiene UTC-5 y España UTC+2)
	   int getNumSatellites()-> devuelve el numero de satelites con los cuales se encuentra enlazado
       double getLatitude()-> devuelve la latitud en formato decimal
       double getLongitude()-> devuelve la longitud en formato decimal
       double getHeightAboveSeaLevel()-> retorna la altura sobre el nivel del mar!
