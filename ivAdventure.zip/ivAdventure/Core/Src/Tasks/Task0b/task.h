/*
 * task.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK0B_TASK_H_
#define SRC_TASKS_TASK0B_TASK_H_

#ifdef create_task0b

#include "../SemaphoreData/MapeoHardware.h"
#include "../Base_Tasks.h"

#include "moduleSensorsRequests.h"
void ProcessSinc();
uint8_t Rx_data[8];
bool banderaI2C = false;

void CapturarDatosRecibidosESP32()
{
	if(Wire2.available()>=7){
		for(uint8_t i=0;i<7;i++){
			Rx_data[i] = Wire2.read();
		}
		if(Rx_data[0] != 0xFF){
			dataReceived.tipoSolicitud = (TipoSolicitud)(Rx_data[0]); //convert char to int
			dataReceived.Port = Rx_data[1];
			dataReceived.SlaveNumber = Rx_data[2];
			dataReceived.new_value = Rx_data[3];
			dataReceived.new_value2 = Rx_data[4];
			dataReceived.new_value3 = Rx_data[5];
			dataReceived.modulo = (ModulosApp)(Rx_data[6]);
			banderaI2C = true;
			transmitMessageToESP(CLEAN_BUF_I2C);
		}
		else{
			transmitMessageToESP(RESTO);
		}
	}
}

void ProcessReceived()
{
	CapturarDatosRecibidosESP32();
	if(banderaI2C)
	{
		banderaI2C = false;
		if (dataReceived.tipoSolicitud == READ_PORT)
		{
			if (dataReceived.modulo == NONE_MODULE)
			{
				RequestNoneModule();
			}
			else if (dataReceived.modulo == TEMPERATURE_SENSORS)
			{
				RequestModuleTemperatureSensor();
			}
			else if (dataReceived.modulo == HUMEDAD_SENSORS)
			{
				RequestModuleHumditySensor();
			}
			else if (dataReceived.modulo == VELOCIDAD_SENSORS)
			{
				RequestModuleSpeedSensor();
			}
			else if (dataReceived.modulo == ACELEROMETRO_SENSORS)
			{
				RequestModuleAccelerometerSensor();
			}
			else if (dataReceived.modulo == MAGNETOMETRO_SENSORS)
			{
				RequestModuleMagnetometerSensor();
			}
			else if (dataReceived.modulo == VOLTAJE_SENSORS)
			{
				RequestModuleVoltageSensor();
			}
			else if (dataReceived.modulo == CORRIENTE_SENSORS)
			{
				RequestModuleCurrentSensor();
			}
			else if (dataReceived.modulo == PROXIMIDAD_SENSORS)
			{
				RequestModuleProximitySensor();
			}
			else if (dataReceived.modulo == LIQUIDO_SENSORS)
			{
				RequestModuleLiquidSensor();
			}
			else if (dataReceived.modulo == PRESION_SENSORS)
			{
				RequestModulePressureSensor();
			}
			else if (dataReceived.modulo == RPM_SENSORS)
			{
				RequestModuleRpmSensor();
			}
			else if (dataReceived.modulo == SUSPENCION_SENSORS)
			{
				RequestModuleSuspensionSensor();
			}
			else if (dataReceived.modulo == ALTURA_SENSORS)
			{
				RequestModuleHeightSensor();
			}
			else if (dataReceived.modulo == REBOTE_SENSORS)
			{
				RequestModuleReboundSensor();
			}
			else if (dataReceived.modulo == MARCHA_SENSORS)
			{
				RequestModuleMarchSensor();
			}
			else if (dataReceived.modulo == DIFERENCIAL_SENSORS)
			{
				RequestModuleDiferentialSensor();
			}
			else if (dataReceived.modulo == BRUJULA_SENSORS)
			{
				RequestModuleCompassSensor();
			}
			else if (dataReceived.modulo == TRACCION_SENSORS)
			{
				RequestModuleTractionSensor();
			}
			else if (dataReceived.modulo == TORQUE_SENSORS)
			{
				RequestModuleTorqueSensor();
			}
			else if (dataReceived.modulo == POTENCIA_SENSORS)
			{
				RequestModulePowerSensor();
			}
			else if (dataReceived.modulo == MSNM_SENSORS)
			{
				RequestModuleMsnmSensor();
			}
			else if (dataReceived.modulo == GIROSCOPIO_SENSORS)
			{
				RequestModuleGyroscopeSensor();
			}
			else if (dataReceived.modulo == SHIFT_SENSORS)
			{
				RequestModuleShiftSensor();
			}
			else if (dataReceived.modulo == GPS_SENSORS)
			{
				RequestModuleGPS_Sensor();
			}
			else
			{
				addMessage("{p[]d[]m[");
				addMessage(dataReceived.modulo);
				addMessage("]}");
				addMessage("\r\n");
				transmitMessageToESP(INICIAL);
			}
		}

		//proceso:
		//1 - SCAN_DS18B20
		//2 - SET_SCAN_DS18B20
		//3 - FINISH_SCAN_DS18B20
		else if(dataReceived.tipoSolicitud == SCAN_DS18B20){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			ds18b20_matricula.puerto = puerto;
			ds18b20_matricula.scanner = true;
			ds18b20_matricula.offset = 0;

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

			Serial2.println("Entra en modo scanner DS18B20");
		}else if (dataReceived.tipoSolicitud == DATA_SCAN_DS18B20){
			Serial2.println("******************************************************");
			addMessage("{");
			addMessage("'id' : ");
			addMessage("[");
			for(uint8_t i=0; i<8; i++)
			{
				uint8_t value = ds18b20_matricula.ROM[i];
				addMessage(value);
				addMessage(",");
			}
			addMessage("]");

			addMessage(", 't' : ");
			addMessage(ds18b20_matricula.Temperatura);
			addMessage("}");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

		}else if (dataReceived.tipoSolicitud == OFFSET_SCAN_DS18B20){
			uint8_t parte_entera = dataReceived.new_value;
			ds18b20_matricula.offset = (float)(parte_entera);

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

			Serial2.println("Se configura el offset que requiera el sensor por parte del usuario");
		}
		else if (dataReceived.tipoSolicitud == FINISH_SCAN_DS18B20){
			ds18b20_matricula.scanner = false;
			ds18b20_matricula.almacenar = true;
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_TANKS_TIPO_SOLICITUD)
		{
			uint8_t indice_posicion_vector = dataReceived.SlaveNumber;
			uint32_t valor =  (dataReceived.new_value<<16) | (dataReceived.new_value2<<8) | (dataReceived.new_value3);
			double valorTanque = double(valor)/10.0;

			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t tipo_tanque = (uint8_t)(dataReceived.modulo);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].valores_depositos[indice_posicion_vector] = valorTanque;
					tanques[i].tipo_tanque = tipo_tanque;
					if(indice_posicion_vector==100){
						tanques[i].valores_depositos_disponible=true;
					}
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}




		//TANQUES IRREGULARES 1
		else if (dataReceived.tipoSolicitud == ALMACENAR_MINIMO_TANQUES){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t largo = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].medidas_tanque_inferior.largo = largo;
					tanques[i].orden_almacenar_resistencia.zero_absoluto = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_MAXIMO_TANQUES){
			uint8_t ancho = dataReceived.new_value;
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].medidas_tanque_superior.ancho = ancho;
					tanques[i].orden_almacenar_resistencia.maximo_absoluto = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MINIMO_TANQUES){
			uint8_t ancho = dataReceived.new_value;
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].medidas_tanque_inferior.ancho = ancho;
					tanques[i].orden_almacenar_resistencia.offset_minimo = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MAXIMO_TANQUES){
			uint8_t largo = dataReceived.new_value;
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].medidas_tanque_superior.largo = largo;
					tanques[i].orden_almacenar_resistencia.offset_maximo = true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == MATRICULAR_TANQUE_IRREGULAR){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t alto = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].tipo_tanque=1;
					tanques[i].medidas_tanque_inferior.alto = alto;
					tanques[i].medidas_tanque_superior.alto = alto;
					tanques[i].matricular_tanque=true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		else if (dataReceived.tipoSolicitud == ALMACENAR_INFLEXION_TANQUES2_CIERRE){//MOD-JOSE
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint16_t alto = (dataReceived.new_value<<8) | (dataReceived.new_value2);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].punto_inflexion.alto = alto;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_INFLEXION_TANQUES2_APERTURA){//MOD-JOSE
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint16_t largo = (dataReceived.new_value<<8) | (dataReceived.new_value2);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].punto_inflexion.largo = largo;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_INFLEXION_TANQUES2_ORDEN){///MOD-JOSE
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint16_t ancho = (dataReceived.new_value<<8) | (dataReceived.new_value2);

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].punto_inflexion.ancho = ancho;
					tanques[i].orden_almacenar_resistencia.inflexion=true;
					break;
				}
			}
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MINIMO_TANQUES2){//OK, falta probar
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t new_value = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].orden_almacenar_resistencia_inflexion.offset_minimo = true;
					Serial2.println("*****************************************************************************");
					Serial2.println("umbMin");
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == ALMACENAR_UMBRAL_MAXIMO_TANQUES2){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t new_value = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].orden_almacenar_resistencia_inflexion.offset_maximo = true;
					Serial2.println("*****************************************************************************");
					Serial2.println("umbMax");
					break;
				}
			}

			// funcion para matricular tanques irregulares 2
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == MATRICULAR_TANQUE_IRREGULAR_2){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			//uint8_t new_value = dataReceived.new_value;

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].matricular_tanque_2=true;
					Serial2.println("*****************************************************************************");
					Serial2.println("matricula");
					break;
				}
			}

			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);
		}

		//TANQUES IRREGULARES 3:
		else if (dataReceived.tipoSolicitud == SEND_TANKS_TIPO_SOLICITUD)//OJO, PUEDE BORRARSE... NO HACE NADA AHORITA
		{
			uint8_t valor = dataReceived.SlaveNumber; //valor medido en el tanque
			uint8_t indice_posicion_vector = dataReceived.new_value;

			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;
			uint8_t tipo_tanque = (uint8_t)(dataReceived.modulo);

			SerialSTM.println("****************************");
			SerialSTM.println("****************************");
			SerialSTM.println("            TANQ      ");
			SerialSTM.println("****************************");
			SerialSTM.print(puerto);
			SerialSTM.print("-");
			SerialSTM.print(indice_posicion_vector);
			SerialSTM.print("-");
			SerialSTM.println(valor);
			SerialSTM.println("****************************");

			for (uint8_t i = 0; i < numero_sensores_liquido; i++)
			{
				if (tanques[i].port == puerto)
				{
					tanques[i].valores_depositos[indice_posicion_vector] = valor;
					tanques[i].tipo_tanque = tipo_tanque;
					break;
				}
			}
		}

		// BORRAR TANQUE
		else if (dataReceived.tipoSolicitud == BORRAR_TANQUE){
			uint8_t puerto = mapeoPuertos[dataReceived.Port].port;

			SerialSTM.print("Borrar tanque irregular con puerto: ");
			SerialSTM.println(puerto);
			addMessage("OK");
			addMessage("\r\n");
			transmitMessageToESP(INICIAL);

		}

		else if (dataReceived.tipoSolicitud == STATUS_INTERRUPTOR){
			uint8_t puerto = dataReceived.Port;
			uint8_t nuevo_valor = dataReceived.new_value;

			bool interruptor_encontrado = false;
			for (uint8_t var = 0; var < numero_actuadores_interruptor; ++var){
				Serial2.print("puerto=");
				Serial2.println(salidasDigital[var].port);
				if(salidasDigital[var].port == puerto){
					salidasDigital[var].value = nuevo_valor;
					if(nuevo_valor == 1){
						SerialSTM.print("Encendiendo interruptor de puerto :");
						SerialSTM.println(puerto);
					}else{
						SerialSTM.print("Apagando interruptor de puerto :");
						SerialSTM.println(puerto);
					}
					interruptor_encontrado = true;
					break;
				}
				addMessage("OK");
				addMessage("\r\n");
				transmitMessageToESP(INICIAL);
			}

			if(interruptor_encontrado == false){
				SerialSTM.print("Interruptor en el puerto: ");
				SerialSTM.println(puerto);
			}
		}

		else if (dataReceived.tipoSolicitud == WRITE_PORT)
		{
			SerialSTM.print("WRITE_PORT: ");
			SerialSTM.println(mapeoPuertos[dataReceived.Port].port);

			Port thisPort = mapeoPuertos[dataReceived.Port];
			TipoEntrada typeInt = thisPort.tipoEntrada;
			TipoPuerto typePort = thisPort.tipoPuerto;
			uint8_t value = thisPort.value;
			uint8_t port = thisPort.port;

			addMessage("{");
			addMessage("'d' : ");
			if (typePort == OUTPUT)
			{
				if (typeInt == SALIDA_PWM)
				{
					addMessage(1);
					mapeoPuertos[dataReceived.Port].value = dataReceived.new_value;
					//RefreshOutputsInSemaphore();
				}
				else if (typeInt == SALIDA_DAC)
				{
					addMessage(1);
					mapeoPuertos[dataReceived.Port].value = dataReceived.new_value;
					//RefreshOutputsInSemaphore();
				}
				else if (typeInt == SALIDA_DIGITAL)
				{
					addMessage(1);
					mapeoPuertos[dataReceived.Port].value = dataReceived.new_value;
					//RefreshOutputsInSemaphore();
				}
				else
				{
					addMessage(255);
				}
			}
			else
			{
				addMessage((uint8_t)0);
			}
			addMessage(", 'p' : ");
			addMessage(dataReceived.Port);
			addMessage("}");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == READ_CLOCK)
		{
			SerialSTM.println("READ_CLOCK");

			addMessage("Rx: ");
			addMessage("hola mundo 2");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_RS485)
		{
			SerialSTM.println("SEND_RS485");

			addMessage("Rx: ");
			addMessage("hola mundo 3");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SCAN_CANBUS)
		{
			SerialSTM.println("SCAN_CANBUS");

			addMessage("Rx: ");
			addMessage("hola mundo 4");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_CANBUS)
		{
			SerialSTM.println("SEND_CANBUS");

			addMessage("Rx: ");
			addMessage("hola mundo 5");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SCAN_LORA)
		{
			SerialSTM.println("SCAN_LORA");

			addMessage("Rx: ");
			addMessage("hola mundo 6");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
		else if (dataReceived.tipoSolicitud == SEND_LORA)
		{
			SerialSTM.println("SEND_LORA");

			addMessage("Rx: ");
			addMessage("hola mundo 7");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}

		else
		{
			SerialSTM.print("Received: ");
			SerialSTM.println((int)dataReceived.tipoSolicitud);

			addMessage("Rx: ");
			addMessage("hola mundo 8");
			addMessage("\r\n");

			transmitMessageToESP(INICIAL);
		}
	}
	else
	{
		//SerialSTM.println("Dato repetido");
	}
}

void SettingsTask0B()
{
	dataReceived.tipoSolicitud = READ_PORT;
}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask0B(void *argument)
{
	/* USER CODE BEGIN 5 */
	//SerialESP.begin(115200);
	SerialSTM.println("INICIALIZA LA TAREA 0B");
	Wire2.setBytesToReceive(7);
	if(Wire2.begin(STM32_SLAVE_ADDRESS, 400000)){
		Serial2.println("INICIALIZO BIEN EL I2C2");
	}
	else{
		Serial2.println("Error en inicialización");
	}
	pinMode(GPIOC, GPIO_PIN_7, INPUT);
	SettingsTask0B();

#ifdef DEBUG_COMPILATION
	/*for (uint8_t var = 0; var < (numeroEntradas + numeroSalidas); ++var)
	{
		Serial2.print("Port (");
		Serial2.print((int)var);
		Serial2.print("): ");
		Serial2.print("Port: ");
		Serial2.print((int)mapeoPuertos[var].port);
		Serial2.print("-TE: ");
		Serial2.print((int)mapeoPuertos[var].tipoEntrada);
		Serial2.print("-value: ");
		Serial2.println((int)mapeoPuertos[var].value);
	}*/
#else
	Serial2.println("Debug OFF");
#endif

	/* Infinite loop */

	for (;;)
	{
		ProcessReceived();
		ProcessSinc();
		osDelay(1);
	}
	/* USER CODE END 5 */
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c){
	Serial2.println("!!!ERROR_CALLBACK_I2C2!!!");
	while(Wire2.available()) Wire2.read();
	HAL_I2C_Slave_Receive_DMA(hi2c, I2C_Buffer_ESP2.Buffer_raw, I2C_Buffer_ESP2.numBytesToReceive);
}

void ProcessSinc(){
	if(digitalRead(GPIOC, GPIO_PIN_7)) NVIC_SystemReset();
	if(Wire2.isReceiveModeAvailable()) Wire2.EnableReceiveMode();
	if(Wire2.isDataReceived()) Wire2.refresh();
}

#endif
#endif /* SRC_TASKS_TASK0_TASK_H_ */
