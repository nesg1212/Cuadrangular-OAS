/*
 * trigger.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK0B_TRIGGER_H_
#define SRC_TASKS_TASK0B_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t defaultTaskHandle0B;
osThreadAttr_t defaultTask_attributes0B;

void Trigger_Task0b(){
	#ifdef create_task0b
		defaultTask_attributes0B.name = NAME_TASK0B;
		defaultTask_attributes0B.stack_size = RAM_TASK0B;
		defaultTask_attributes0B.priority = PRIORITY_TASK0B;

		defaultTaskHandle0B = osThreadNew(StartDefaultTask0B, NULL, &defaultTask_attributes0B);
	#endif
}

#endif /* SRC_TASKS_TASK0_TRIGGER_H_ */
