/*
 * config.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK0B_CONFIG_H_
#define SRC_TASKS_TASK0B_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK0B = 1024;
const char* NAME_TASK0B = "defaultTask";
osPriority_t PRIORITY_TASK0B = (osPriority_t) osPriorityHigh;

#endif /* SRC_TASKS_TASK0_CONFIG_H_ */
