/*
 * moduleSensorsRequests.h
 *
 *  Created on: 6/11/2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK0B_MODULESENSORSREQUESTS_H_
#define SRC_TASKS_TASK0B_MODULESENSORSREQUESTS_H_

typedef enum{
	CLEAN_BUF_I2C,
	INICIAL,
	RESTO
}TRAMA_I2C;

char joinMessagePrint[2000]={'\0'};

DataESP32 dataReceived;
Wire Wire2(I2C2, SLAVE2);

#define SerialSTM Serial2

void addMessage(char* message);
void addMessage(uint8_t value);
void transmitMessageToESP(TRAMA_I2C tipoTransmision);

void RequestNoneModule(){
	int numero_sensores = 1;
	int modulo = NONE_MODULE;
	SerialSTM.println("NO MODULO");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage((int)mapeoPuertos[dataReceived.Port].port);
		addMessage("-");
		addMessage((int)mapeoPuertos[dataReceived.Port].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = (int)mapeoPuertos[dataReceived.Port].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleTemperatureSensor()
{
	int numero_sensores = numero_sensores_temperatura + numeroTotalLlantas + numeroTotalVentiladores;
	int modulo = TEMPERATURE_SENSORS;
	SerialSTM.println("TEMPERATURE_SENSORS");

	addMessage("{p[");
	if(numero_sensores >0){
		addMessage(sensoresTemperatura[0].port);
		addMessage("-");
		addMessage(sensoresTemperatura[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresTemperatura[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleHumditySensor()
{
	int numero_sensores = numero_sensores_humedad;
	int modulo = HUMEDAD_SENSORS;
	SerialSTM.println("HUMEDAD_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresHumedad[0].port);
		addMessage("-");
		addMessage(sensoresHumedad[numero_sensores-1].port);
	}

	addMessage("]");

	addMessage("d[");

	for (uint8_t var = 0; var < numero_sensores; ++var)
		{
			uint8_t value = sensoresHumedad[var].value;
			addMessage(value);
			if(var < (numero_sensores-1)) addMessage(",");
		}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleSpeedSensor()
{
	int numero_sensores = numero_sensores_velocidad;
	int modulo = VELOCIDAD_SENSORS;
	SerialSTM.println("VELOCIDAD_SENSORS");

	addMessage("{p[");
	if(numero_sensores >0){
		addMessage(sensoresVelocidad[0].port);
		addMessage("-");
		addMessage(sensoresVelocidad[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresVelocidad[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleAccelerometerSensor()
{
	int numero_sensores = numero_sensores_acelerometro;
	int modulo = ACELEROMETRO_SENSORS;
	SerialSTM.println("ACELEROMETRO_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresAcelerometro[0].port);
		addMessage("-");
		addMessage(sensoresAcelerometro[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresAcelerometro[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleMagnetometerSensor()
{
	int numero_sensores = numero_sensores_magnetometro;
	int modulo = MAGNETOMETRO_SENSORS;
	SerialSTM.println("MAGNETOMETRO_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresMagnetometro[0].port);
		addMessage("-");
		addMessage(sensoresMagnetometro[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresMagnetometro[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleVoltageSensor()
{
	int numero_sensores = numero_sensores_voltaje;
	int modulo = VOLTAJE_SENSORS;
	SerialSTM.println("VOLTAJE_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresVoltaje[0].port);
		addMessage("-");
		addMessage(sensoresVoltaje[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresVoltaje[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleCurrentSensor()
{
	int numero_sensores = numero_sensores_corriente;
	int modulo = CORRIENTE_SENSORS;
	SerialSTM.println("CORRIENTE_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresCorriente[0].port);
		addMessage("-");
		addMessage(sensoresCorriente[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresCorriente[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleProximitySensor()
{
	int numero_sensores = numero_sensores_proximidad;
	int modulo = PROXIMIDAD_SENSORS;
	SerialSTM.println("PROXIMIDAD_SENSORS");
	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresProximidad[0].port);
		addMessage("-");
		addMessage(sensoresProximidad[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresProximidad[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");
	transmitMessageToESP(INICIAL);
}

void RequestModuleLiquidSensor()
{
	int numero_sensores = numero_sensores_liquido;
	int modulo = LIQUIDO_SENSORS;
	SerialSTM.println("LIQUIDO_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresLiquido[0].port);
		addMessage("-");
		addMessage(sensoresLiquido[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresLiquido[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModulePressureSensor()
{
	int numero_sensores = numero_sensores_presion + numeroTotalLlantas;
	int modulo = PRESION_SENSORS;
	SerialSTM.println("PRESION_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresPresion[0].port);
		addMessage("-");
		addMessage(sensoresPresion[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresPresion[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleRpmSensor()
{
	int numero_sensores = numero_sensores_rpm + numeroTotalVentiladores;
	int modulo = RPM_SENSORS;
	SerialSTM.println("RPM_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresRPM[0].port);
		addMessage("-");
		addMessage(sensoresRPM[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresRPM[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleSuspensionSensor()
{
	int numero_sensores = numero_suspenciones;
	int modulo = SUSPENCION_SENSORS;
	SerialSTM.println("SUSPENCION_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresSuspencion[0].port);
		addMessage("-");
		addMessage(sensoresSuspencion[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresSuspencion[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleHeightSensor()
{
	int numero_sensores = numero_alturas;
	int modulo = ALTURA_SENSORS;
	SerialSTM.println("ALTURA_SENSORS");

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresAltura[0].port);
		addMessage("-");
		addMessage(sensoresAltura[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresAltura[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleReboundSensor()
{
	int modulo = REBOTE_SENSORS;
	SerialSTM.println("REBOTE_SENSORS");
	int numero_sensores = numero_rebotes;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresRebotes[0].port);
		addMessage("-");
		addMessage(sensoresRebotes[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresRebotes[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleCompassSensor()
{
	int modulo = BRUJULA_SENSORS;
	SerialSTM.println("BRUJULA_SENSORS");
	int numero_sensores = numero_brujulas;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresBrujulas[0].port);
		addMessage("-");
		addMessage(sensoresBrujulas[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresBrujulas[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleDiferentialSensor()
{
	int modulo = DIFERENCIAL_SENSORS;
	SerialSTM.println("DIFERENCIAL_SENSORS");
	int numero_sensores = numero_diferenciales;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresDiferenciales[0].port);
		addMessage("-");
		addMessage(sensoresDiferenciales[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresDiferenciales[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleMarchSensor()
{
	int modulo = MARCHA_SENSORS;
	SerialSTM.println("MARCHA_SENSORS");
	int numero_sensores = numero_marchas_instaladas;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresMarchas[0].port);
		addMessage("-");
		addMessage(sensoresMarchas[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresMarchas[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleTractionSensor()
{
	int modulo = TRACCION_SENSORS;
	SerialSTM.println("TRACCION_SENSORS");
	int numero_sensores = numero_tracciones_instaladas;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresTracciones[0].port);
		addMessage("-");
		addMessage(sensoresTracciones[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresTracciones[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleTorqueSensor()
{
	int modulo = TORQUE_SENSORS;
	SerialSTM.println("TORQUE_SENSORS");
	int numero_sensores = numero_sensores_torque;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresTorque[0].port);
		addMessage("-");
		addMessage(sensoresTorque[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresTorque[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModulePowerSensor()
{
	int modulo = POTENCIA_SENSORS;
	SerialSTM.println("POTENCIA_SENSORS");
	int numero_sensores = numero_sensores_potencia;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresPotencia[0].port);
		addMessage("-");
		addMessage(sensoresPotencia[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresPotencia[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleMsnmSensor()
{
	int modulo = MSNM_SENSORS;
	SerialSTM.println("MSNM_SENSORS");
	int numero_sensores = numero_sensores_alturaMSNM;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresAlturaMSNM[0].port);
		addMessage("-");
		addMessage(sensoresAlturaMSNM[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresAlturaMSNM[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleGyroscopeSensor()
{
	int modulo = GIROSCOPIO_SENSORS;
	SerialSTM.println("GIROSCOPIO_SENSORS");
	int numero_sensores = numero_sensores_giroscopos;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresGiroscopios[0].port);
		addMessage("-");
		addMessage(sensoresGiroscopios[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresGiroscopios[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleShiftSensor()
{
	int modulo = SHIFT_SENSORS;
	SerialSTM.println("SHIFT_SENSORS");
	int numero_sensores = numero_shift;

	addMessage("{p[");

	if(numero_sensores >0){
		addMessage(sensoresShift[0].port);
		addMessage("-");
		addMessage(sensoresShift[numero_sensores-1].port);
	}
	addMessage("]");

	addMessage("d[");
	for (uint8_t var = 0; var < numero_sensores; ++var)
	{
		uint8_t value = sensoresShift[var].value;
		addMessage(value);
		if(var < (numero_sensores-1)) addMessage(",");
	}
	addMessage("]");

	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void RequestModuleSwitchSensor()
{

}

void RequestModuleGPS_Sensor()
{
	int modulo = GPS_SENSORS;

	SerialSTM.println("GPS_SENSORS");

	addMessage("{p[]");
	addMessage("d[");
	addMessage(toChar(sensoresGPS[0].validez));
	addMessage(",");
	addMessage(sensoresGPS[0].hora);
	addMessage(",");
	addMessage(toChar(sensoresGPS[0].latitud,7));
	addMessage(",");
	addMessage(toChar(sensoresGPS[0].logitud,7));
	addMessage(",");
	addMessage(toChar(sensoresGPS[0].numSat));
	addMessage("]");
	addMessage("m[");
	addMessage(modulo);
	addMessage("]}");
	addMessage("\r\n");

	transmitMessageToESP(INICIAL);
}

void addMessage(char* message){
	strcat(joinMessagePrint,message);
}
void addMessage(uint8_t value){
	strcat(joinMessagePrint,toChar(value));
}

void transmitMessageToESP(TRAMA_I2C tipoTransmision){
	if(tipoTransmision == INICIAL){
		Wire2.write(joinMessagePrint, 254);
	}
	if(tipoTransmision == RESTO){
		memmove(joinMessagePrint, &(joinMessagePrint[254]), sizeof(joinMessagePrint));
		Wire2.write(joinMessagePrint, 254);
	}
	if(tipoTransmision == CLEAN_BUF_I2C){
		memset(joinMessagePrint, '\0', sizeof(joinMessagePrint));
	}
}

#endif /* SRC_TASKS_TASK0_MODULESENSORSREQUESTS_H_ */
