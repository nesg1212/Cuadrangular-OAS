/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : BAse_Task.h
*	@funcion    : Archivo que controla la activación de cada tarea en el STM32
*/

#ifndef SRC_TASKS_BASE_TASKS_H_
#define SRC_TASKS_BASE_TASKS_H_

#include "cmsis_os.h"  //For Task

#include "SemaphoreData/MapeoHardware.h"

#include "SemaphoreData/SemaphoreData.h"
#include "SemaphoreData/Definiciones.h"

#if defined(STM32F411xE)
	#define create_task0
	//#define create_task0b
	#define create_task1
	//#define create_task2
	//#define create_task3
	//#define create_task4
	#define create_task5
	//#define create_task6
	//#define create_task7
	//#define create_task8
	//#define create_task9
	//#define create_task10
	//#define create_task11
	//#define create_task12
	//#define create_task13
	//#define create_task14
#elif defined(STM32F107xC)
	#define create_task0
	//#define create_task0b
	//#define create_task1
	//#define create_task2
	//#define create_task3
	//#define create_task4
	//#define create_task5
	//#define create_task6
	//#define create_task7
	//#define create_task8
	#define create_task9
	//#define create_task10
	//#define create_task11
	//#define create_task12
#endif

#endif /* SRC_TASKS_BASE_TASKS_H_ */
