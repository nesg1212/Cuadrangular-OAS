Tarea para SPI lectura termocupla tipo K con modulo MAX31855K.

MAX31855: Dependencia de libreria SPI.h
    Funciones:
        init() -> solicita del objeto SPI utilizado y el pin de seleccion de esclavo
        read() -> realiza unica lectura del modulo MAX31855, retorna true si todo sale bien, o false si existe un error
        getInternal -> Lectura de tempertura interna en termocupla
        getCelsius -> lectura de temperatura externa
        getStatus -> retorna estructura que presenta el error por el modulo MAX31855 y su conexión con termocupla 