/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK9_TRIGGER_H_
#define SRC_TASKS_TASK9_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask09_Handle;
osThreadAttr_t myTask09_attributes;


void Trigger_Task09(){
	#ifdef create_task9
		myTask09_attributes.name = NAME_TASK9;
		myTask09_attributes.stack_size = RAM_TASK9 * 4;
		myTask09_attributes.priority = PRIORITY_TASK9;

		myTask09_Handle = osThreadNew(StartTask09, NULL, &myTask09_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK9_TRIGGER_H_ */
