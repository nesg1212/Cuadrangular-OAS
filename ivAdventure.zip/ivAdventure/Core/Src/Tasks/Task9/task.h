/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK9_TASK_H_
#define SRC_TASKS_TASK9_TASK_H_

TIM_HandleTypeDef htim2;
#include "../Base_Tasks.h"

#ifdef create_task9

#if defined(STM32F411xE)

	#include <stdio.h>
	#include "../../Extensions/MAX31855.h"
	#include "../../Extensions/InputCapture.h"
	#include "../../Extensions/PWM.h"
	#include "../../Extensions/PID/pid.h"

	MAX31855 ThermoCouple1;
	InputCapture inputCapture(TIM2);
	bool EstadoSalidas[numero_actuadores_interruptor];
	bool EstadoSalidasElectroventilador[numero_ventiladores];
	char OutBuf[50];
	double PIDOut[numero_ventiladores];
	PID pid[numero_ventiladores];
	PWM pwm(TIM5);

	MAX31855_STATUS ReadStatus;

	void StartTask09(void *argument)
	{
		uint32_t Ti=millis();
		uint32_t Ti_digital=millis();
		uint32_t Ti_pid=millis();
		ThermoCouple1.init(Spi2, THERMOCOUPLE1_PORT_SS, THERMOCOUPLE1_PIN_SS);
		Serial2.waitAndTakeSemaphore();
		Serial2.println("Tarea 9 -> TERMOCUPLA INICIALIZADA");
		Serial2.setSemaphore(FREE);

		pinMode(DIGITAL_INPUT_1_PORT, DIGITAL_INPUT_1_PIN, INPUT);
		pinMode(DIGITAL_INPUT_2_PORT, DIGITAL_INPUT_2_PIN, INPUT);
		pinMode(DIGITAL_INPUT_3_PORT, DIGITAL_INPUT_3_PIN, INPUT);
		pinMode(DIGITAL_INPUT_4_PORT, DIGITAL_INPUT_4_PIN, INPUT);

		pinMode(DIGITAL_OUTPUT_1_PORT, DIGITAL_OUTPUT_1_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_2_PORT, DIGITAL_OUTPUT_2_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_3_PORT, DIGITAL_OUTPUT_3_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_4_PORT, DIGITAL_OUTPUT_4_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_5_PORT, DIGITAL_OUTPUT_5_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_6_PORT, DIGITAL_OUTPUT_6_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_7_PORT, DIGITAL_OUTPUT_7_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_8_PORT, DIGITAL_OUTPUT_8_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_9_PORT, DIGITAL_OUTPUT_9_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_10_PORT, DIGITAL_OUTPUT_10_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_11_PORT, DIGITAL_OUTPUT_11_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_12_PORT, DIGITAL_OUTPUT_12_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_13_PORT, DIGITAL_OUTPUT_13_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_14_PORT, DIGITAL_OUTPUT_14_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_15_PORT, DIGITAL_OUTPUT_15_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_16_PORT, DIGITAL_OUTPUT_16_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_17_PORT, DIGITAL_OUTPUT_17_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_18_PORT, DIGITAL_OUTPUT_18_PIN, OUTPUT);

		inputCapture.init();
		inputCapture.begin(TIM_CHANNEL_1);
		inputCapture.begin(TIM_CHANNEL_2);
		inputCapture.begin(TIM_CHANNEL_3);
		inputCapture.begin(TIM_CHANNEL_4);
		inputCapture.startTimers(TIM_CHANNEL_1);
		inputCapture.startTimers(TIM_CHANNEL_2);
		inputCapture.startTimers(TIM_CHANNEL_3);
		inputCapture.startTimers(TIM_CHANNEL_4);


		for(int i=0;i<numero_ventiladores;i++){
			if(actuadoresVentiladores[i].pid.available == 1){
				pwm.begin(500);
				pwm.write(0, (CHANNEL_PWM)((int)TIM_CHANNEL_1_SELECTED + i)); //Inicia en 0%

				actuadoresVentiladores[i].pid.kp = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KP_PID));
				actuadoresVentiladores[i].pid.ki = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KI_PID));
				actuadoresVentiladores[i].pid.kd = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KD_PID));
				actuadoresVentiladores[i].pid.setpoint = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(SETPOINT_PID));
				actuadoresVentiladores[i].pid.output = getInt_eeprom(PID_LONG+(i*PID_LONG)+(OUTPUT_PID));

				pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
				pid[i].SetSampleTime(actuadoresVentiladores[i].pid.tm);
				pid[i].SetMode(_PID_MODE_AUTOMATIC);
				pid[i].SetOutputLimits(0, 100);
			}
			else{
				if(i == 0)
					pinMode(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, OUTPUT);
				if(i == 1)
					pinMode(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, OUTPUT);
				if(i == 2)
					pinMode(ELECTROVENTILADOR_OUTPUT_3_PORT, ELECTROVENTILADOR_OUTPUT_3_PIN, OUTPUT);
			}
		}

		for(;;)
		{
			if((millis()-Ti) >= TEMPERATURA_TERMOCUPLA_SAMPLE_TIME){
				Ti=millis();
				if(ThermoCouple1.read()){
					float tempInternal,tempCelsius;

					tempInternal = ThermoCouple1.getInternal();
					tempCelsius = ThermoCouple1.getCelsius();

					sensoresTemperatura[TERMOCUPLA_1].value = (-56);
					sensoresTemperatura[TERMOCUPLA_2].value = (-123);
					sensoresTemperatura[TERMOCUPLA_3].value = (567);

					Serial2.waitAndTakeSemaphore();
					Serial2.print("Tarea 9 -> MAX31855 :: T_EXT:");
					Serial2.print(tempCelsius);
					Serial2.print("°c T_INT:");
					Serial2.print(tempInternal);
					Serial2.println("°c");
					Serial2.setSemaphore(FREE);
				}
				else{
					Serial2.waitAndTakeSemaphore();
					if(ThermoCouple1.getStatus()==OPEN_CIRCUIT) Serial2.println("Tarea 9 -> MAX31855 :: Termocupla no conectada");
					else if(ThermoCouple1.getStatus()==SHORT_TO_GND) Serial2.println("Tarea 9 -> MAX31855 :: Termocupla aterrizada");
					else if(ThermoCouple1.getStatus()==SHORT_TO_VCC) Serial2.println("Tarea 9 -> MAX31855 :: Termocupla a VCC");
					else Serial2.println("Tarea 9 -> MAX31855 :: ERROR en termocupla");
					Serial2.setSemaphore(FREE);
				}
			}

			if((millis()-Ti_digital) >= DIGITAL_INPUT_SAMPLE_TIME){
				Ti_digital=millis();
				bool input_1 = digitalRead(DIGITAL_INPUT_1_PORT, DIGITAL_INPUT_1_PIN);
				bool input_2 = digitalRead(DIGITAL_INPUT_2_PORT, DIGITAL_INPUT_2_PIN);
				bool input_3 = digitalRead(DIGITAL_INPUT_3_PORT, DIGITAL_INPUT_3_PIN);
				bool input_4 = digitalRead(DIGITAL_INPUT_4_PORT, DIGITAL_INPUT_4_PIN);

				sensoresDigitales[DIGITAL_INPUT_1].value = input_1;
				sensoresDigitales[DIGITAL_INPUT_2].value = input_2;
				sensoresDigitales[DIGITAL_INPUT_3].value = input_3;
				sensoresDigitales[DIGITAL_INPUT_4].value = input_4;

				sensoresRPM[RPM_INPUT_1].value = inputCapture.getFrequency(TIM_CHANNEL_1);
				sensoresRPM[RPM_INPUT_2].value = inputCapture.getFrequency(TIM_CHANNEL_2);
				sensoresRPM[RPM_INPUT_3].value = inputCapture.getFrequency(TIM_CHANNEL_3);
				sensoresRPM[RPM_INPUT_4].value = inputCapture.getFrequency(TIM_CHANNEL_4);

				for(int i=0;i<numero_actuadores_interruptor;i++){
					if(salidasDigital[DIGITAL_OUTPUT_1 + i].value == 1)
						EstadoSalidas[i] = true;
					else
						EstadoSalidas[i] = false;
				}

				digitalWrite(DIGITAL_OUTPUT_1_PORT, DIGITAL_OUTPUT_1_PIN, EstadoSalidas[DIGITAL_OUTPUT_1]);
				digitalWrite(DIGITAL_OUTPUT_2_PORT, DIGITAL_OUTPUT_2_PIN, EstadoSalidas[DIGITAL_OUTPUT_2]);
				digitalWrite(DIGITAL_OUTPUT_3_PORT, DIGITAL_OUTPUT_3_PIN, EstadoSalidas[DIGITAL_OUTPUT_3]);
				digitalWrite(DIGITAL_OUTPUT_4_PORT, DIGITAL_OUTPUT_4_PIN, EstadoSalidas[DIGITAL_OUTPUT_4]);
				digitalWrite(DIGITAL_OUTPUT_5_PORT, DIGITAL_OUTPUT_5_PIN, EstadoSalidas[DIGITAL_OUTPUT_5]);
				digitalWrite(DIGITAL_OUTPUT_6_PORT, DIGITAL_OUTPUT_6_PIN, EstadoSalidas[DIGITAL_OUTPUT_6]);
				digitalWrite(DIGITAL_OUTPUT_7_PORT, DIGITAL_OUTPUT_7_PIN, EstadoSalidas[DIGITAL_OUTPUT_7]);
				digitalWrite(DIGITAL_OUTPUT_8_PORT, DIGITAL_OUTPUT_8_PIN, EstadoSalidas[DIGITAL_OUTPUT_8]);
				digitalWrite(DIGITAL_OUTPUT_9_PORT, DIGITAL_OUTPUT_9_PIN, EstadoSalidas[DIGITAL_OUTPUT_9]);
				digitalWrite(DIGITAL_OUTPUT_10_PORT, DIGITAL_OUTPUT_10_PIN, EstadoSalidas[DIGITAL_OUTPUT_10]);
				digitalWrite(DIGITAL_OUTPUT_11_PORT, DIGITAL_OUTPUT_11_PIN, EstadoSalidas[DIGITAL_OUTPUT_11]);
				digitalWrite(DIGITAL_OUTPUT_12_PORT, DIGITAL_OUTPUT_12_PIN, EstadoSalidas[DIGITAL_OUTPUT_12]);
				digitalWrite(DIGITAL_OUTPUT_13_PORT, DIGITAL_OUTPUT_13_PIN, EstadoSalidas[DIGITAL_OUTPUT_13]);
				digitalWrite(DIGITAL_OUTPUT_14_PORT, DIGITAL_OUTPUT_14_PIN, EstadoSalidas[DIGITAL_OUTPUT_14]);
				digitalWrite(DIGITAL_OUTPUT_15_PORT, DIGITAL_OUTPUT_15_PIN, EstadoSalidas[DIGITAL_OUTPUT_15]);
				digitalWrite(DIGITAL_OUTPUT_16_PORT, DIGITAL_OUTPUT_16_PIN, EstadoSalidas[DIGITAL_OUTPUT_16]);
				digitalWrite(DIGITAL_OUTPUT_17_PORT, DIGITAL_OUTPUT_17_PIN, EstadoSalidas[DIGITAL_OUTPUT_17]);
				digitalWrite(DIGITAL_OUTPUT_18_PORT, DIGITAL_OUTPUT_18_PIN, EstadoSalidas[DIGITAL_OUTPUT_18]);

				for(int i=0;i<numero_ventiladores;i++){
					if(actuadoresVentiladores[ELECTROVENTILADORES_OUTPUT_1 + i].value == 1)
						EstadoSalidasElectroventilador[i] = true;
					else
						EstadoSalidasElectroventilador[i] = false;
				}

			}

			if((millis()-Ti_pid) >= actuadoresVentiladores[0].pid.tm){
				Ti_pid = millis();
				for(int i=0;i<numero_ventiladores;i++){
					if(actuadoresVentiladores[i].pid.pid_flag.kp){
						double valor = actuadoresVentiladores[i].pid.kp;
						actuadoresVentiladores[i].pid.pid_flag.kp = false;
						setDouble_eeprom(valor, PID_LONG+(i*PID_LONG)+(KP_PID));
						Serial2.print(" SE RECIBIO KP=-> ");
						Serial2.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.ki){
						double valor = actuadoresVentiladores[i].pid.ki;
						actuadoresVentiladores[i].pid.pid_flag.ki = false;
						setDouble_eeprom(valor, PID_LONG+(i*PID_LONG)+(KI_PID));
						Serial2.print(" SE RECIBIO KI=-> ");
						Serial2.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.kd){
						double valor = actuadoresVentiladores[i].pid.kd;
						actuadoresVentiladores[i].pid.pid_flag.kd = false;
						setDouble_eeprom(valor, PID_LONG+(i*PID_LONG)+(KD_PID));
						//pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
						pid[i].SetTunings(actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd);

						Serial2.print(" SE RECIBIO KD=-> ");
						Serial2.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.available){
						int valor = actuadoresVentiladores[i].pid.available;
						actuadoresVentiladores[i].pid.pid_flag.available = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(HABIL_PID));
						Serial2.print(" SE RECIBIO HABIL=-> ");
						Serial2.println(valor);

						for(int i=0;i<numero_ventiladores;i++){
							if(actuadoresVentiladores[i].pid.available == 1){
								pwm.begin(500);
								pwm.write(0, (CHANNEL_PWM)((int)TIM_CHANNEL_1_SELECTED + i)); //Inicia en 0%

								actuadoresVentiladores[i].pid.kp = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KP_PID));
								actuadoresVentiladores[i].pid.ki = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KI_PID));
								actuadoresVentiladores[i].pid.kd = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KD_PID));
								actuadoresVentiladores[i].pid.setpoint = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(SETPOINT_PID));
								actuadoresVentiladores[i].pid.output = getInt_eeprom(PID_LONG+(i*PID_LONG)+(OUTPUT_PID));

								pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
								pid[i].SetSampleTime(actuadoresVentiladores[i].pid.tm);
								pid[i].SetMode(_PID_MODE_AUTOMATIC);
								pid[i].SetOutputLimits(0, 100);
							}
							else{
								if(i == 0)
									pinMode(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, OUTPUT);
								if(i == 1)
									pinMode(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, OUTPUT);
								if(i == 2)
									pinMode(ELECTROVENTILADOR_OUTPUT_3_PORT, ELECTROVENTILADOR_OUTPUT_3_PIN, OUTPUT);
							}
						}
					}
					if(actuadoresVentiladores[i].pid.pid_flag.tm){
						int valor = actuadoresVentiladores[i].pid.tm;
						actuadoresVentiladores[i].pid.pid_flag.tm = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(TM_PID));
						pid[i].SetSampleTime(actuadoresVentiladores[0].pid.tm);
						pid[i].SetSampleTime(actuadoresVentiladores[1].pid.tm);
						pid[i].SetSampleTime(actuadoresVentiladores[2].pid.tm);
						Serial2.print(" SE RECIBIO TM=-> ");
						Serial2.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.output){
						int valor = actuadoresVentiladores[i].pid.output;
						actuadoresVentiladores[i].pid.pid_flag.output = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(OUTPUT_PID));
						Serial2.print(" SE RECIBIO OUTPUT=-> ");
						Serial2.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.setpoint){
						int valor = actuadoresVentiladores[i].pid.setpoint;
						actuadoresVentiladores[i].pid.pid_flag.setpoint = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(SETPOINT_PID));
						if(getInt_eeprom(PID_LONG+(i*PID_LONG)+(HABIL_PID)) == 1)
							pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
						Serial2.print(" SE RECIBIO SETPOINT=-> ");
						Serial2.println(valor);
					}


					if(actuadoresVentiladores[i].pid.available == 1){
						pid[i].Compute();
						pwm.write((int)actuadoresVentiladores[i].pid.output, (CHANNEL_PWM)((int)TIM_CHANNEL_1_SELECTED + i));
					}
					else{
						if(actuadoresVentiladores[i].value == 0){
							if(i == 0)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, LOW);
							if(i == 1)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, LOW);
							if(i == 2)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_3_PORT, ELECTROVENTILADOR_OUTPUT_3_PIN, LOW);
						}
						else{
							if(i == 0)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, HIGH);
							if(i == 1)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, HIGH);
							if(i == 2)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_3_PORT, ELECTROVENTILADOR_OUTPUT_3_PIN, HIGH);
						}
					}
				}
			}

			osDelay(10);
		}
	  /* USER CODE END StartTask02 */
	}

#elif defined(STM32F107xC)

	#include <stdio.h>
	#include "../../Extensions/PWM.h"
	#include "../../Extensions/PID/pid.h"


	bool EstadoSalidas[numero_actuadores_interruptor];
	bool EstadoSalidasElectroventilador[numero_ventiladores];
	char OutBuf[50];
	double PIDOut[numero_ventiladores];
	PWM pwm(TIM3);
	PID pid[numero_ventiladores];

	void StartTask09(void *argument)
	{
		uint32_t Ti=millis();
		uint32_t Ti_digital=millis();
		uint32_t Ti_pid=millis();

		Serial3.waitAndTakeSemaphore();
		Serial3.println("Tarea 9 -> ENTRADAS + SALIDAS DIGITALES");
		Serial3.setSemaphore(FREE);

		pinMode(DIGITAL_INPUT_1_PORT, DIGITAL_INPUT_1_PIN, INPUT);
		pinMode(DIGITAL_INPUT_2_PORT, DIGITAL_INPUT_2_PIN, INPUT);
		pinMode(DIGITAL_INPUT_3_PORT, DIGITAL_INPUT_3_PIN, INPUT);
		pinMode(DIGITAL_INPUT_4_PORT, DIGITAL_INPUT_4_PIN, INPUT);

		pinMode(DIGITAL_OUTPUT_3_PORT, DIGITAL_OUTPUT_3_PIN, OUTPUT);
		pinMode(DIGITAL_OUTPUT_4_PORT, DIGITAL_OUTPUT_4_PIN, OUTPUT);

		for(int i=0;i<numero_ventiladores;i++){
			if(actuadoresVentiladores[i].pid.available == 1){
				pwm.begin(500);
				pwm.write(0, (CHANNEL_PWM)((int)TIM_CHANNEL_1_SELECTED + i)); //Inicia en 0%

				actuadoresVentiladores[i].pid.kp = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KP_PID));
				actuadoresVentiladores[i].pid.ki = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KI_PID));
				actuadoresVentiladores[i].pid.kd = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KD_PID));
				actuadoresVentiladores[i].pid.setpoint = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(SETPOINT_PID));
				actuadoresVentiladores[i].pid.output = getInt_eeprom(PID_LONG+(i*PID_LONG)+(OUTPUT_PID));

				pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
				pid[i].SetSampleTime(actuadoresVentiladores[i].pid.tm);
				pid[i].SetMode(_PID_MODE_AUTOMATIC);
				pid[i].SetOutputLimits(0, 100);
			}
			else{
				if(i == 0)
					pinMode(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, OUTPUT);
				if(i == 1)
					pinMode(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, OUTPUT);
			}
		}

		for(;;)
		{
			if((millis()-Ti_digital) >= DIGITAL_INPUT_SAMPLE_TIME){
				Ti_digital=millis();
				bool input_1 = digitalRead(DIGITAL_INPUT_1_PORT, DIGITAL_INPUT_1_PIN);
				bool input_2 = digitalRead(DIGITAL_INPUT_2_PORT, DIGITAL_INPUT_2_PIN);
				bool input_3 = digitalRead(DIGITAL_INPUT_3_PORT, DIGITAL_INPUT_3_PIN);
				bool input_4 = digitalRead(DIGITAL_INPUT_4_PORT, DIGITAL_INPUT_4_PIN);

				sensoresDigitales[DIGITAL_INPUT_1].value = input_1;
				sensoresDigitales[DIGITAL_INPUT_2].value = input_2;
				sensoresDigitales[DIGITAL_INPUT_3].value = input_3;
				sensoresDigitales[DIGITAL_INPUT_4].value = input_4;

				for(int i=0;i<numero_actuadores_interruptor;i++){
					if(salidasDigital[DIGITAL_OUTPUT_1 + i].value == 1)
						EstadoSalidas[i] = true;
					else
						EstadoSalidas[i] = false;
				}

				digitalWrite(DIGITAL_OUTPUT_3_PORT, DIGITAL_OUTPUT_3_PIN, EstadoSalidas[DIGITAL_OUTPUT_3]);
				digitalWrite(DIGITAL_OUTPUT_4_PORT, DIGITAL_OUTPUT_4_PIN, EstadoSalidas[DIGITAL_OUTPUT_4]);
			}

			if((millis()-Ti_pid) >= actuadoresVentiladores[0].pid.tm){
				Ti_pid = millis();
				for(int i=0;i<numero_ventiladores;i++){
					if(actuadoresVentiladores[i].pid.pid_flag.kp){
						double valor = actuadoresVentiladores[i].pid.kp;
						actuadoresVentiladores[i].pid.pid_flag.kp = false;
						setDouble_eeprom(valor, PID_LONG+(i*PID_LONG)+(KP_PID));
						Serial3.print(" SE RECIBIO KP=-> ");
						Serial3.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.ki){
						double valor = actuadoresVentiladores[i].pid.ki;
						actuadoresVentiladores[i].pid.pid_flag.ki = false;
						setDouble_eeprom(valor, PID_LONG+(i*PID_LONG)+(KI_PID));
						Serial3.print(" SE RECIBIO KI=-> ");
						Serial3.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.kd){
						double valor = actuadoresVentiladores[i].pid.kd;
						actuadoresVentiladores[i].pid.pid_flag.kd = false;
						setDouble_eeprom(valor, PID_LONG+(i*PID_LONG)+(KD_PID));
						//pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
						pid[i].SetTunings(actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd);

						Serial3.print(" SE RECIBIO KD=-> ");
						Serial3.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.available){
						int valor = actuadoresVentiladores[i].pid.available;
						actuadoresVentiladores[i].pid.pid_flag.available = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(HABIL_PID));
						Serial3.print(" SE RECIBIO HABIL=-> ");
						Serial3.println(valor);

						if(actuadoresVentiladores[i].pid.available == 1){
							pwm.begin(500);
							pwm.write(0, (CHANNEL_PWM)((int)TIM_CHANNEL_1_SELECTED + i)); //Inicia en 0%

							actuadoresVentiladores[i].pid.kp = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KP_PID));
							actuadoresVentiladores[i].pid.ki = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KI_PID));
							actuadoresVentiladores[i].pid.kd = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(KD_PID));
							actuadoresVentiladores[i].pid.setpoint = getDouble_eeprom(PID_LONG+(i*PID_LONG)+(SETPOINT_PID));
							actuadoresVentiladores[i].pid.output = getInt_eeprom(PID_LONG+(i*PID_LONG)+(OUTPUT_PID));

							pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
							pid[i].SetSampleTime(actuadoresVentiladores[i].pid.tm);
							pid[i].SetMode(_PID_MODE_AUTOMATIC);
							pid[i].SetOutputLimits(0, 100);
						}
						else{
							if(i == 0)
								pinMode(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, OUTPUT);
							if(i == 1)
								pinMode(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, OUTPUT);
						}
					}
					if(actuadoresVentiladores[i].pid.pid_flag.tm){
						int valor = actuadoresVentiladores[i].pid.tm;
						actuadoresVentiladores[i].pid.pid_flag.tm = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(TM_PID));
						pid[i].SetSampleTime(actuadoresVentiladores[0].pid.tm);
						pid[i].SetSampleTime(actuadoresVentiladores[1].pid.tm);
						pid[i].SetSampleTime(actuadoresVentiladores[2].pid.tm);
						Serial3.print(" SE RECIBIO TM=-> ");
						Serial3.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.output){
						int valor = actuadoresVentiladores[i].pid.output;
						actuadoresVentiladores[i].pid.pid_flag.output = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(OUTPUT_PID));
						Serial3.print(" SE RECIBIO OUTPUT=-> ");
						Serial3.println(valor);
					}
					if(actuadoresVentiladores[i].pid.pid_flag.setpoint){
						int valor = actuadoresVentiladores[i].pid.setpoint;
						actuadoresVentiladores[i].pid.pid_flag.setpoint = false;
						setInt_eeprom(valor, PID_LONG+(i*PID_LONG)+(SETPOINT_PID));
						if(getInt_eeprom(PID_LONG+(i*PID_LONG)+(HABIL_PID)) == 1)
							pid[i].Init(&actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.output, &actuadoresVentiladores[i].pid.setpoint, actuadoresVentiladores[i].pid.kp, actuadoresVentiladores[i].pid.ki, actuadoresVentiladores[i].pid.kd, _PID_P_ON_E, _PID_CD_DIRECT);
						Serial3.print(" SE RECIBIO SETPOINT=-> ");
						Serial3.println(valor);
					}


					if(actuadoresVentiladores[i].pid.available == 1){
						pid[i].Compute();
						pwm.write((int)actuadoresVentiladores[i].pid.output, (CHANNEL_PWM)((int)TIM_CHANNEL_1_SELECTED + i));
					}
					else{
						if(actuadoresVentiladores[i].value == 0){
							if(i == 0)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, LOW);
							if(i == 1)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, LOW);
						}
						else{
							if(i == 0)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_1_PORT, ELECTROVENTILADOR_OUTPUT_1_PIN, HIGH);
							if(i == 1)
								digitalWrite(ELECTROVENTILADOR_OUTPUT_2_PORT, ELECTROVENTILADOR_OUTPUT_2_PIN, HIGH);
						}
					}
				}
			}

			osDelay(10);
		}
	  /* USER CODE END StartTask02 */
	}
#endif

#endif
#endif /* SRC_TASKS_TASK9_TASK_H_ */
