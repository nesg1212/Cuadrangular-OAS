/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK3_TRIGGER_H_
#define SRC_TASKS_TASK3_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask03_Handle;
osThreadAttr_t myTask03_attributes;


void Trigger_Task03(){
	#ifdef create_task3
		myTask03_attributes.name = NAME_TASK3;
		myTask03_attributes.stack_size = RAM_TASK3 * 4;
		myTask03_attributes.priority = PRIORITY_TASK3;

		myTask03_Handle = osThreadNew(StartTask03, NULL, &myTask03_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK3_TRIGGER_H_ */
