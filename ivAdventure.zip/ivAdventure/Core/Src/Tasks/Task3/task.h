/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK3_TASK_H_
#define SRC_TASKS_TASK3_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task3

#if defined(STM32F411xE)
	#include "FreeRTOS.h"
	#include "cmsis_os.h"
	#include "semphr.h"

	#include "../../Extensions/Modbus/ModbusSlave.h"
	//#include "../../Config_pines/Modbus/ModbusMaster.h"

	ModbusSlave MbSlave;
	//ModbusMaster MbMaster;

	#ifdef PLACA_ONADVENTURE
		Serial Serial6(USART6);
	#endif
	#ifdef PLACA_ONADVENTURE_MINI
		Serial Serial6(USART6);
	#endif

	void StartTask03(void *argument)
	{
		uint32_t Ti=millis();

		//Serial6.begin(115200);
		//pinMode(RS485_EN_PORT,RS485_EN_PIN,OUTPUT);
		//digitalWrite(RS485_EN_PORT, RS485_EN_PIN, LOW);

		MbSlave.init(&huart6, ID_SLAVE);//el slaveID se configura con dipswitchs

		MbSlave.setHoldingRegister(0, 111);
		MbSlave.setHoldingRegister(1, 222);
		MbSlave.setHoldingRegister(2, 333);

		for(;;)
		{
			if((millis()-Ti)>=1000){
				Ti=millis();
				//Serial6.println("HOLA RS485");
				//Serial2.println("enviado RS485");
				MbSlave.waitAndTakeSemaphore();
				for(int i=0;i<8;i++){
					Serial2.print((int)MbSlave.getHoldingRegister(i));
					//Serial2.print((int)MbSlave.getCoilRegister(i));
					Serial2.print("-");
				}
				Serial2.println("");
				MbSlave.giveSemaphore();
			}

			osDelay(1);
		}

		/*
		MbMaster.init(&huart6);
		uint16_t miVectorMaster[20];
		  for(;;)
		  {
			 Serial2.println("Enviando dato desde maestro");
			 MbMaster.readHoldingRegister(1, 0, 5);
			 for(int i=0;i<100;i++){
				 Serial2.print("Se recibio a los ");
				 Serial2.print(i*100);
				 Serial2.print("s :: ");
				 MbMaster.update(5, miVectorMaster);
				 for(int i=0;i<5;i++){
					Serial2.print((int)miVectorMaster[i]);
					Serial2.print("-");
				 }
				 Serial2.println("");
				 osDelay(100);
			 }




		  }
	*/
	}

#elif defined(STM32F107xC)

	void StartTask03(void *argument){
		for(;;){
			osDelay(500);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK3_TASK_H_ */
