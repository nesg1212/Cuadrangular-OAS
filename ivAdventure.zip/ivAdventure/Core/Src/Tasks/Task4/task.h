/*
 * task.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK4_TASK_H_
#define SRC_TASKS_TASK4_TASK_H_

#include "../Base_Tasks.h"
#ifdef create_task4

#if defined(STM32F411xE)

	void StartTask04(void *argument)
	{
		for(;;)
		{
			Serial2.println("StartTask04");
			osDelay(500);
		}
	  /* USER CODE END StartTask02 */
	}

#elif defined(STM32F107xC)

	void StartTask04(void *argument)
	{
		for(;;)
		{
			Serial2.println("StartTask04");
			osDelay(500);
		}
	  /* USER CODE END StartTask02 */
	}
#endif

#endif

#endif /* SRC_TASKS_TASK4_TASK_H_ */
