/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK4_TRIGGER_H_
#define SRC_TASKS_TASK4_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask04_Handle;
osThreadAttr_t myTask04_attributes;


void Trigger_Task04(){
	#ifdef create_task4
		myTask04_attributes.name = NAME_TASK4;
		myTask04_attributes.stack_size = RAM_TASK4 * 4;
		myTask04_attributes.priority = PRIORITY_TASK4;

		myTask04_Handle = osThreadNew(StartTask04, NULL, &myTask04_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK4_TRIGGER_H_ */
