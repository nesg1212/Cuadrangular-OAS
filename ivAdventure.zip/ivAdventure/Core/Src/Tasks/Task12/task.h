/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : task.h
*	@funcion    : Esta tarea ajusta todas las configuraciones del modulo LORA, tanto hardware
*				  como logica de negocio para la comunicación con los Wearables
*/

#ifndef SRC_TASKS_TASK12_TASK_H_
#define SRC_TASKS_TASK12_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task12

#if defined(STM32F411xE)

	#include "../../Extensions/LORA/SX1278.h"

	SPI Spi3(SPI3, MASTER_MODE);
	SX1278_hw_t SX1278_hw;
	SX1278_t SX1278;

	bool master;
	int ret;
	char buffer[512];
	int message;
	int message_length;

	void StartTask12(void *argument)
	{
		GPIO_InitTypeDef GPIO_InitStruct = {0};

		digitalWrite(LORA_RESET_GPIO_PORT, LORA_RESET_PIN, LOW);
		digitalWrite(LORA_NSS_GPIO_PORT, LORA_NSS_PIN, LOW);

		pinMode(LORA_MODE_GPIO_PORT, LORA_MODE_PIN, INPUT);
		pinMode(LORA_DIO0_GPIO_PORT, LORA_DIO0_PIN, INPUT_EXTIN);
		pinMode(LORA_RESET_GPIO_PORT, LORA_RESET_PIN, OUTPUT);
		pinMode(LORA_NSS_GPIO_PORT, LORA_NSS_PIN, OUTPUT);

		HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

		Spi3.begin(SPI_SPEED_21MHZ);

		master = digitalRead(LORA_MODE_GPIO_PORT, LORA_MODE_PIN);

		if (master) {
			Serial2.println("Mode: Master");
			HAL_GPIO_WritePin(LORA_MODE_GPIO_PORT, LORA_MODE_PIN, GPIO_PIN_RESET);
		} else {
			Serial2.println("Mode: Slave");
			HAL_GPIO_WritePin(LORA_MODE_GPIO_PORT, LORA_MODE_PIN, GPIO_PIN_SET);
		}

		SX1278_hw.dio0.port = LORA_DIO0_GPIO_PORT;
		SX1278_hw.dio0.pin = LORA_DIO0_PIN;
		SX1278_hw.nss.port = LORA_NSS_GPIO_PORT;
		SX1278_hw.nss.pin = LORA_NSS_PIN;
		SX1278_hw.reset.port = LORA_RESET_GPIO_PORT;
		SX1278_hw.reset.pin = LORA_RESET_PIN;
		SX1278_hw.spi = Spi3.getSpi();
		SX1278.hw = &SX1278_hw;

		Serial2.println("Configuring LoRa module");
		SX1278_init(&SX1278, 434000000, SX1278_POWER_17DBM, SX1278_LORA_SF_7, SX1278_LORA_BW_125KHZ, SX1278_LORA_CR_4_5, SX1278_LORA_CRC_EN, 10);
		Serial2.println("Done configuring LoRaModule");

		if(master){
			ret = SX1278_LoRaEntryTx(&SX1278, 16, 2000);
		} else {
			ret = SX1278_LoRaEntryRx(&SX1278, 16, 2000);
		}

		for(;;)
		{
			if (master) {
				osDelay(1000);
				Serial2.println("Master Sending package (Jose)...");

				message_length = sprintf(buffer, "Hello %d", message);
				ret = SX1278_LoRaEntryTx(&SX1278, message_length, 2000);
				Serial2.print("Entry: ");
				Serial2.print(ret);
				Serial2.println("");

				Serial2.print("Sending ");
				Serial2.println(buffer);
				ret = SX1278_LoRaTxPacket(&SX1278, (uint8_t*) buffer, message_length, 2000);
				message += 1;

				Serial2.print("Transmission: ");
				Serial2.print(ret);
				Serial2.println("  Package sent...");
			}
			else {
				osDelay(300);
				Serial2.println("Slave Receiving package...");

				ret = SX1278_LoRaRxPacket(&SX1278);
				Serial2.print("Received: ");
				Serial2.println(ret);
				if (ret > 0) {
					SX1278_read(&SX1278, (uint8_t*) buffer, ret);
					Serial2.print("Content (:");
					Serial2.print(ret);
					Serial2.print("): ");
					Serial2.println(buffer);
				}
				Serial2.println("Package received ...");

			}
			osDelay(10);
		}
	}

#elif defined(STM32F107xC)

	void StartTask12(void *argument){
		for(;;){
			osDelay(500);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK11_TASK_H_ */
