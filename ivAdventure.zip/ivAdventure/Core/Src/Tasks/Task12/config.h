/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : config.h
*	@funcion    : define las configuraciones de la tarea
*/

#ifndef SRC_TASKS_TASK12_CONFIG_H_
#define SRC_TASKS_TASK12_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK12 = 1024;
const char* NAME_TASK12 = "Task11 - LORA";
osPriority_t PRIORITY_TASK12 = (osPriority_t) osPriorityNormal;




#endif /* SRC_TASKS_TASK12_CONFIG_H_ */
