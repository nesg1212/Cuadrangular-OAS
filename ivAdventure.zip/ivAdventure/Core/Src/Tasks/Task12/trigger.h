/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK12_TRIGGER_H_
#define SRC_TASKS_TASK12_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask12_Handle;
osThreadAttr_t myTask12_attributes;


void Trigger_Task12(){
	#ifdef create_task12
		myTask12_attributes.name = NAME_TASK12;
		myTask12_attributes.stack_size = RAM_TASK12 * 4;
		myTask12_attributes.priority = PRIORITY_TASK12;

		myTask12_Handle = osThreadNew(StartTask12, NULL, &myTask12_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK11_TRIGGER_H_ */
