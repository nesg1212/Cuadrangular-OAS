/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : task.h
*	@funcion    : Tarea encargada de la lectura de votajes de batería y los niveles de liquido en los tanques.
*/

#ifndef SRC_TASKS_TASK6_TASK_H_
#define SRC_TASKS_TASK6_TASK_H_

#ifdef create_task6

#if defined(STM32F411xE)

	#include "../Base_Tasks.h"
	#include "../../Extensions/CD4067.h"
	#include "../../Library/Deposito.h"

	CD4067 Mux1(ADC_CHANNEL_0,MUX1_PIN_SA,MUX1_PORT_SA,MUX1_PIN_SB,MUX1_PORT_SB,MUX1_PIN_SC,MUX1_PORT_SC,MUX1_PIN_SD,MUX1_PORT_SD,MUX1_PIN_ENABLE,MUX1_PORT_ENABLE);
	Deposito Depositos[5];

	float MuxADC[16];
	float ADC_Channel;
	float RA;

	void StartTask06(void *argument)
	{
		uint32_t Ti=millis();

		Mux1.init();
		Serial2.waitAndTakeSemaphore();
		Serial2.println("Tarea 6 -> CD4067 OK");
		Serial2.setSemaphore(FREE);

		for(int i=0;i<numero_sensores_liquido;i++){
			int tanqueHabilitado = getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));
			TankType tipoTanque = (TankType)getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));

			if((tanqueHabilitado == 1) && (tipoTanque == REGULAR)){
				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+1), 1);
				Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+0)), 0);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6), 6);
				Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9)), 9);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7), 7);
				Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+0)), 0);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8),8);
				Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9)), 9);

				Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+0)), 0);
				Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9)), 9);
				Depositos[i].registerTank(i, getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST)), tipoTanque);
				Depositos[i].setAvailable(true);
			}
			if((tanqueHabilitado == 1) && (tipoTanque == IRREGULAR_SIMPLE)){
				int niveles = getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));

				for(int contador_punto_inflexion=0;contador_punto_inflexion<(niveles*2)-1;contador_punto_inflexion++){
					Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+contador_punto_inflexion)), contador_punto_inflexion);
					Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+contador_punto_inflexion)), contador_punto_inflexion);
					Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+contador_punto_inflexion)), contador_punto_inflexion);
					if(contador_punto_inflexion % 2 == 0){
						Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+((contador_punto_inflexion/2)+1)), (contador_punto_inflexion/2)+1);
					}
					else{
						Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+contador_punto_inflexion-1)), contador_punto_inflexion-1);
					}

					Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6), 6);
					Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9)), 9);
					Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9)), 9);
					Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9)), 9);
				}

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7), 7);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8), 8);

				Depositos[i].registerTank(i, getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST)), tipoTanque);
				Depositos[i].setAvailable(true);

			}
			if((tanqueHabilitado == 1) && (tipoTanque == IRREGULAR_EXCEL)){
				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+1), 1);
				Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+0)), 0);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6), 6);
				Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9)), 9);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7), 7);
				Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+0)), 0);

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8),8);
				Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9)), 9);

				Depositos[i].registerTank(i, getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST)), tipoTanque);
				for(int j=0;j<101;j++){
					sensoresLiquidoTanques[i].valores_depositos[j] = getDouble_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(EX_BASE+j));
				}
				Depositos[i].setVolumes(sensoresLiquidoTanques[i].valores_depositos,101);
				Depositos[i].setAvailable(true);
			}
		}

		for(;;)
		{
			if((millis()-Ti) >= AFORADOR_SAMPLE_TIME){
				Ti=millis();

				for(int i=0;i<numero_sensores_liquido;i++){
					Mux1.setChannel(i);
					ADC_Channel=Mux1.getADC();
					RA=Depositos[i].getR(ADC_Channel);

	/**************************************************************************************************/
	/******************************  TANQUES TIPO 1   *************************************************/
	/**************************************************************************************************/
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.zero_absoluto){
						Depositos[i].setResistor(RA,1);
						Depositos[i].setDimensionL(sensoresLiquidoTanques[i].medidas_tanque_inferior.largo, 0);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+1);
						setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_inferior.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+0));

						sensoresLiquidoTanques[i].orden_almacenar_resistencia.zero_absoluto=false;
						//Serial2.println(sensoresLiquidoTanques[i].medidas_tanque_inferior.largo);
						//Serial2.println("************zero***********");

					}
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.maximo_absoluto){
						Depositos[i].setResistor(RA,6);
						Depositos[i].setDimensionW(sensoresLiquidoTanques[i].medidas_tanque_superior.ancho, 9);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6);
						setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_superior.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9));

						sensoresLiquidoTanques[i].orden_almacenar_resistencia.maximo_absoluto=false;
						//Serial2.println(sensoresLiquidoTanques[i].medidas_tanque_superior.ancho);
						//Serial2.println("************max***********");
					}
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_minimo){
						Depositos[i].setResistor(RA,7);
						Depositos[i].setDimensionW(sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho, 0);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7);
						setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+0));

						sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_minimo=false;
						//Serial2.println(sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho);
						//Serial2.println("************offmin***********");

					}
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_maximo){
						Depositos[i].setResistor(RA,8);
						Depositos[i].setDimensionL(sensoresLiquidoTanques[i].medidas_tanque_superior.largo, 9);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8);
						setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_superior.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9));

						sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_maximo=false;
						//Serial2.println("************offmax***********");
						//Serial2.println(sensoresLiquidoTanques[i].medidas_tanque_superior.largo);
					}
					if(sensoresLiquidoTanques[i].matricular_tanque){
						Depositos[i].setDimensionH(0, 0);
						Depositos[i].setDimensionH(sensoresLiquidoTanques[i].medidas_tanque_superior.alto, 9);
						setInt_eeprom(0, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+0));
						setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_superior.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9));

						Depositos[i].registerTank(i, 1, REGULAR);
						Depositos[i].setAvailable(true);
						setInt_eeprom(1, TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));
						setInt_eeprom(REGULAR, TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));
						setInt_eeprom(true, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));

						sensoresLiquidoTanques[i].matricular_tanque=false;
						//Serial2.println(sensoresLiquidoTanques[i].medidas_tanque_superior.alto);
					}
					if(sensoresLiquidoTanques[i].desmatricular_tanque){
						Depositos[i].setAvailable(false);
						setInt_eeprom(false, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));

						sensoresLiquidoTanques[i].desmatricular_tanque=false;
					}
	/**************************************************************************************************/
	/**************************************  TANQUES TIPO 2  ******************************************/
	/**************************************************************************************************/
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.inflexion){
						Depositos[i].setDimensionL(sensoresLiquidoTanques[i].punto_inflexion.largo, sensoresLiquidoTanques[i].contador_punto_inflexion);
						Depositos[i].setDimensionW(sensoresLiquidoTanques[i].punto_inflexion.ancho, sensoresLiquidoTanques[i].contador_punto_inflexion);
						Depositos[i].setDimensionH(sensoresLiquidoTanques[i].punto_inflexion.alto, sensoresLiquidoTanques[i].contador_punto_inflexion);

						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion));
						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion));
						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion));

						if(sensoresLiquidoTanques[i].contador_punto_inflexion % 2 == 0){
							Depositos[i].setResistor(RA,(sensoresLiquidoTanques[i].contador_punto_inflexion/2)+1);
							setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+((sensoresLiquidoTanques[i].contador_punto_inflexion/2)+1));
						}
						else{
							Depositos[i].setDimensionH(sensoresLiquidoTanques[i].punto_inflexion.alto, sensoresLiquidoTanques[i].contador_punto_inflexion - 1);
							setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion-1));
						}

						Depositos[i].setResistor(RA,6);
						Depositos[i].setDimensionL(sensoresLiquidoTanques[i].punto_inflexion.largo, 9);
						Depositos[i].setDimensionW(sensoresLiquidoTanques[i].punto_inflexion.ancho, 9);
						Depositos[i].setDimensionH(sensoresLiquidoTanques[i].punto_inflexion.alto, 9);
						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9));
						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9));
						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9));

						sensoresLiquidoTanques[i].contador_punto_inflexion++;
						sensoresLiquidoTanques[i].orden_almacenar_resistencia.inflexion=false;
						//Serial2.println("**************************RINF****************************************");
						//Serial2.println(sensoresLiquidoTanques[i].punto_inflexion.largo);
						//Serial2.println(sensoresLiquidoTanques[i].punto_inflexion.ancho);
						//Serial2.println(sensoresLiquidoTanques[i].punto_inflexion.alto);
					}
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_minimo){
						Depositos[i].setResistor(RA,7);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7);

						sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_minimo=false;
						//Serial2.println("offMin en tarea");
					}
					if(sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_maximo){
						Depositos[i].setResistor(RA,8);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8);

						sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_maximo=false;
						//Serial2.println("offMax en tarea");
					}
					if(sensoresLiquidoTanques[i].matricular_tanque_2){
						Depositos[i].registerTank(i, int(sensoresLiquidoTanques[i].contador_punto_inflexion/2),IRREGULAR_SIMPLE);
						Depositos[i].setAvailable(true);
						setInt_eeprom(int(sensoresLiquidoTanques[i].contador_punto_inflexion/2), TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));
						setInt_eeprom(IRREGULAR_SIMPLE, TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));
						setInt_eeprom(true, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));

						sensoresLiquidoTanques[i].matricular_tanque_2=false;
						//Serial2.println("Matricula en tarea");
					}
	/**************************************************************************************************/
	/******************************  TANQUES TIPO 3  *************************************************/
	/**************************************************************************************************/
					if(sensoresLiquidoTanques[i].valores_depositos_disponible){
						Depositos[i].registerTank(i, 1, IRREGULAR_EXCEL);
						Depositos[i].setVolumes(sensoresLiquidoTanques[i].valores_depositos,101);
						Depositos[i].setAvailable(true);

						setInt_eeprom(1, TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));
						setInt_eeprom(IRREGULAR_EXCEL, TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));
						setInt_eeprom(true, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));
						for(int j=0;j<101;j++){
							setDouble_eeprom(sensoresLiquidoTanques[i].valores_depositos[j], TANQUE_BASE+(i*TANQUE_LONG)+(EX_BASE+j));
						}

						sensoresLiquidoTanques[i].valores_depositos_disponible=false;
					}

	/******************************  CONSULTA A sensoresLiquidoTanques DISPONIBLES  *************************************************/
					if(Depositos[i].isAvailable()){
						sensoresLiquidoTanques[i].value = int(Depositos[i].PercentWithOffset(RA));
						sensoresLiquidoTanques[i].value2 = int(Depositos[i].VolumeWithOffset(RA));
						sensoresLiquidoTanques[i].value3 = int(Depositos[i].totalPercent(RA));
						sensoresLiquidoTanques[i].value4 = int(Depositos[i].totalVolume(RA));
						sensoresLiquidoTanques[i].value5 = (int)Depositos[i].getType();
					}
					else{
						sensoresLiquidoTanques[i].value = 0;
						sensoresLiquidoTanques[i].value2 = 0;
						sensoresLiquidoTanques[i].value3 = 0;
						sensoresLiquidoTanques[i].value4 = 0;
						sensoresLiquidoTanques[i].value5 = 0;
					}
				}

				for(int i=0;i<16;i++){
					Mux1.setChannel(i);
					MuxADC[i]=Mux1.getADC();
				}

				Mux1.setChannel(0);//adquisicion con 100ohm en configuracion divisor de tension

				sensoresVoltaje[VOLTAJE_BATERIA_1].value = int(MuxADC[0]*10);
				sensoresVoltaje[VOLTAJE_BATERIA_1].value = int(MuxADC[1]*10);
				sensoresVoltaje[VOLTAJE_BATERIA_2].value = int(MuxADC[2]*10);
				sensoresVoltaje[VOLTAJE_BATERIA_3].value = int(MuxADC[3]*10);

				for(int i=0;i<numero_sensores_analogicos;i++){
					int habilitadoA = getInt_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));

					if(habilitadoA == 1){
						double pendiente = getDouble_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(PENDIENTE_A));
						double interseccion = getDouble_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(INTERSECCION_A));
						double valorAnalogico = Mux1.getVoltage();

						sensoresAnalogicos[ANALOG_INPUT_1+i].value = ((pendiente*valorAnalogico) + interseccion) * 10;
					}
					else{
						sensoresAnalogicos[ANALOG_INPUT_1+i].value = 0;
					}
				}
			}
			osDelay(1);
		}
	}

#elif defined(STM32F107xC)

#include "../Base_Tasks.h"
#include "../../Library/Deposito.h"

#define CHANNEL_TANQ1 ADC_CHANNEL_14
#define CHANNEL_TANQ2 ADC_CHANNEL_15
#define CHANNEL_TANQ3 ADC_CHANNEL_2
#define CHANNEL_TANQ4 ADC_CHANNEL_3

#define CHANNEL_VOLT1 ADC_CHANNEL_0
#define CHANNEL_VOLT2 ADC_CHANNEL_1
#define CHANNEL_VOLT3 ADC_CHANNEL_4
#define CHANNEL_VOLT4 ADC_CHANNEL_4

#define CHANNEL_POT1 ADC_CHANNEL_13
#define CHANNEL_POT2 ADC_CHANNEL_12
#define CHANNEL_POT3 ADC_CHANNEL_11
#define CHANNEL_POT4 ADC_CHANNEL_10

Deposito Depositos[numero_sensores_liquido];

float ADC_Channel;
float RA;
uint32_t canalesTanque[numero_sensores_liquido] = {CHANNEL_TANQ1, CHANNEL_TANQ2, CHANNEL_TANQ3, CHANNEL_TANQ4};
uint32_t canalesVolt[4] = {CHANNEL_VOLT1, CHANNEL_VOLT2, CHANNEL_VOLT3, CHANNEL_VOLT4};
uint32_t canalesPotenciometro[4] = {CHANNEL_POT1, CHANNEL_POT2, CHANNEL_POT3, CHANNEL_POT4};

void StartTask06(void *argument)
{
	uint32_t Ti=millis();

	Serial3.waitAndTakeSemaphore();
	Serial3.println("Tarea 6 -> TANQUES ACTIVOS");
	Serial3.setSemaphore(FREE);

	pinMode(SWITCH_1_ADC_PORT, SWITCH_1_ADC_PIN, INPUT);
	pinMode(SWITCH_2_ADC_PORT, SWITCH_2_ADC_PIN, INPUT);
	pinMode(SWITCH_3_ADC_PORT, SWITCH_3_ADC_PIN, INPUT);
	pinMode(SWITCH_4_ADC_PORT, SWITCH_4_ADC_PIN, INPUT);

	for(int i=0;i<numero_sensores_liquido;i++){
		int tanqueHabilitado = getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));
		TankType tipoTanque = (TankType)getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));

		if((tanqueHabilitado == 1) && (tipoTanque == REGULAR)){
			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+1), 1);
			Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+0)), 0);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6), 6);
			Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9)), 9);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7), 7);
			Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+0)), 0);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8),8);
			Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9)), 9);

			Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+0)), 0);
			Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9)), 9);
			Depositos[i].registerTank(i, getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST)), tipoTanque);
			Depositos[i].setAvailable(true);
		}
		if((tanqueHabilitado == 1) && (tipoTanque == IRREGULAR_SIMPLE)){
			int niveles = getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));

			for(int contador_punto_inflexion=0;contador_punto_inflexion<(niveles*2)-1;contador_punto_inflexion++){
				Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+contador_punto_inflexion)), contador_punto_inflexion);
				Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+contador_punto_inflexion)), contador_punto_inflexion);
				Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+contador_punto_inflexion)), contador_punto_inflexion);
				if(contador_punto_inflexion % 2 == 0){
					Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+((contador_punto_inflexion/2)+1)), (contador_punto_inflexion/2)+1);
				}
				else{
					Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+contador_punto_inflexion-1)), contador_punto_inflexion-1);
				}

				Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6), 6);
				Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9)), 9);
				Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9)), 9);
				Depositos[i].setDimensionH(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9)), 9);
			}

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7), 7);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8), 8);

			Depositos[i].registerTank(i, getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST)), tipoTanque);
			Depositos[i].setAvailable(true);

		}
		if((tanqueHabilitado == 1) && (tipoTanque == IRREGULAR_EXCEL)){
			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+1), 1);
			Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+0)), 0);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6), 6);
			Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9)), 9);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7), 7);
			Depositos[i].setDimensionW(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+0)), 0);

			Depositos[i].setResistor(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8),8);
			Depositos[i].setDimensionL(getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9)), 9);

			Depositos[i].registerTank(i, getInt_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST)), tipoTanque);
			for(int j=0;j<101;j++){
				sensoresLiquidoTanques[i].valores_depositos[j] = getDouble_eeprom(TANQUE_BASE+(i*TANQUE_LONG)+(EX_BASE+j));
			}
			Depositos[i].setVolumes(sensoresLiquidoTanques[i].valores_depositos,101);
			Depositos[i].setAvailable(true);
		}
	}

	for(;;)
	{
		if((millis()-Ti) >= AFORADOR_SAMPLE_TIME){
			Ti=millis();

			for(int i=0;i<numero_sensores_liquido;i++){
				ADC_Channel = analogRead(canalesTanque[i]);
				RA=Depositos[i].getR(ADC_Channel);

/**************************************************************************************************/
/******************************  TANQUES TIPO 1   *************************************************/
/**************************************************************************************************/
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.zero_absoluto){
					Depositos[i].setResistor(RA,1);
					Depositos[i].setDimensionL(sensoresLiquidoTanques[i].medidas_tanque_inferior.largo, 0);
					setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+1);
					setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_inferior.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+0));

					sensoresLiquidoTanques[i].orden_almacenar_resistencia.zero_absoluto=false;
					//Serial3.println(sensoresLiquidoTanques[i].medidas_tanque_inferior.largo);
					//Serial3.println("************zero***********");

				}
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.maximo_absoluto){
					Depositos[i].setResistor(RA,6);
					Depositos[i].setDimensionW(sensoresLiquidoTanques[i].medidas_tanque_superior.ancho, 9);
					setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+6);
					setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_superior.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9));

					sensoresLiquidoTanques[i].orden_almacenar_resistencia.maximo_absoluto=false;
					//Serial3.println(sensoresLiquidoTanques[i].medidas_tanque_superior.ancho);
					//Serial3.println("************max***********");
				}
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_minimo){
					Depositos[i].setResistor(RA,7);
					Depositos[i].setDimensionW(sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho, 0);
					setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7);
					setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+0));

					sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_minimo=false;
					//Serial3.println(sensoresLiquidoTanques[i].medidas_tanque_inferior.ancho);
					//Serial3.println("************offmin***********");

				}
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_maximo){
					Depositos[i].setResistor(RA,8);
					Depositos[i].setDimensionL(sensoresLiquidoTanques[i].medidas_tanque_superior.largo, 9);
					setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8);
					setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_superior.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9));

					sensoresLiquidoTanques[i].orden_almacenar_resistencia.offset_maximo=false;
					//Serial3.println("************offmax***********");
					//Serial3.println(sensoresLiquidoTanques[i].medidas_tanque_superior.largo);
				}
				if(sensoresLiquidoTanques[i].matricular_tanque){
					Depositos[i].setDimensionH(0, 0);
					Depositos[i].setDimensionH(sensoresLiquidoTanques[i].medidas_tanque_superior.alto, 9);
					setInt_eeprom(0, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+0));
					setInt_eeprom(sensoresLiquidoTanques[i].medidas_tanque_superior.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9));

					Depositos[i].registerTank(i, 1, REGULAR);
					Depositos[i].setAvailable(true);
					setInt_eeprom(1, TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));
					setInt_eeprom(REGULAR, TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));
					setInt_eeprom(true, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));

					sensoresLiquidoTanques[i].matricular_tanque=false;
					//Serial3.println(sensoresLiquidoTanques[i].medidas_tanque_superior.alto);
				}
				if(sensoresLiquidoTanques[i].desmatricular_tanque){
					Depositos[i].setAvailable(false);
					setInt_eeprom(false, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));

					sensoresLiquidoTanques[i].desmatricular_tanque=false;
				}
/**************************************************************************************************/
/**************************************  TANQUES TIPO 2  ******************************************/
/**************************************************************************************************/
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia.inflexion){
					Depositos[i].setDimensionL(sensoresLiquidoTanques[i].punto_inflexion.largo, sensoresLiquidoTanques[i].contador_punto_inflexion);
					Depositos[i].setDimensionW(sensoresLiquidoTanques[i].punto_inflexion.ancho, sensoresLiquidoTanques[i].contador_punto_inflexion);
					Depositos[i].setDimensionH(sensoresLiquidoTanques[i].punto_inflexion.alto, sensoresLiquidoTanques[i].contador_punto_inflexion);

					setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion));
					setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion));
					setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion));

					if(sensoresLiquidoTanques[i].contador_punto_inflexion % 2 == 0){
						Depositos[i].setResistor(RA,(sensoresLiquidoTanques[i].contador_punto_inflexion/2)+1);
						setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+((sensoresLiquidoTanques[i].contador_punto_inflexion/2)+1));
					}
					else{
						Depositos[i].setDimensionH(sensoresLiquidoTanques[i].punto_inflexion.alto, sensoresLiquidoTanques[i].contador_punto_inflexion - 1);
						setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+sensoresLiquidoTanques[i].contador_punto_inflexion-1));
					}

					Depositos[i].setResistor(RA,6);
					Depositos[i].setDimensionL(sensoresLiquidoTanques[i].punto_inflexion.largo, 9);
					Depositos[i].setDimensionW(sensoresLiquidoTanques[i].punto_inflexion.ancho, 9);
					Depositos[i].setDimensionH(sensoresLiquidoTanques[i].punto_inflexion.alto, 9);
					setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.largo, TANQUE_BASE+(i*TANQUE_LONG)+(LT_BASE+9));
					setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.ancho, TANQUE_BASE+(i*TANQUE_LONG)+(WT_BASE+9));
					setInt_eeprom(sensoresLiquidoTanques[i].punto_inflexion.alto, TANQUE_BASE+(i*TANQUE_LONG)+(HT_BASE+9));

					sensoresLiquidoTanques[i].contador_punto_inflexion++;
					sensoresLiquidoTanques[i].orden_almacenar_resistencia.inflexion=false;
					//Serial3.println("**************************RINF****************************************");
					//Serial3.println(sensoresLiquidoTanques[i].punto_inflexion.largo);
					//Serial3.println(sensoresLiquidoTanques[i].punto_inflexion.ancho);
					//Serial3.println(sensoresLiquidoTanques[i].punto_inflexion.alto);
				}
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_minimo){
					Depositos[i].setResistor(RA,7);
					setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+7);

					sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_minimo=false;
					//Serial2.println("offMin en tarea");
				}
				if(sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_maximo){
					Depositos[i].setResistor(RA,8);
					setInt_eeprom(RA, TANQUE_BASE+(i*TANQUE_LONG)+(RT_BASE-1)+8);

					sensoresLiquidoTanques[i].orden_almacenar_resistencia_inflexion.offset_maximo=false;
					//Serial3.println("offMax en tarea");
				}
				if(sensoresLiquidoTanques[i].matricular_tanque_2){
					Depositos[i].registerTank(i, int(sensoresLiquidoTanques[i].contador_punto_inflexion/2),IRREGULAR_SIMPLE);
					Depositos[i].setAvailable(true);
					setInt_eeprom(int(sensoresLiquidoTanques[i].contador_punto_inflexion/2), TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));
					setInt_eeprom(IRREGULAR_SIMPLE, TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));
					setInt_eeprom(true, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));

					sensoresLiquidoTanques[i].matricular_tanque_2=false;
					//Serial3.println("Matricula en tarea");
				}
/**************************************************************************************************/
/******************************  TANQUES TIPO 3  *************************************************/
/**************************************************************************************************/
				if(sensoresLiquidoTanques[i].valores_depositos_disponible){
					Depositos[i].registerTank(i, 1, IRREGULAR_EXCEL);
					Depositos[i].setVolumes(sensoresLiquidoTanques[i].valores_depositos,101);
					Depositos[i].setAvailable(true);

					setInt_eeprom(1, TANQUE_BASE+(i*TANQUE_LONG)+(NIVELEST));
					setInt_eeprom(IRREGULAR_EXCEL, TANQUE_BASE+(i*TANQUE_LONG)+(TIPOT));
					setInt_eeprom(true, TANQUE_BASE+(i*TANQUE_LONG)+(HABILT));
					for(int j=0;j<101;j++){
						setDouble_eeprom(sensoresLiquidoTanques[i].valores_depositos[j], TANQUE_BASE+(i*TANQUE_LONG)+(EX_BASE+j));
					}
					sensoresLiquidoTanques[i].valores_depositos_disponible=false;
				}

/******************************  CONSULTA A sensoresLiquidoTanques DISPONIBLES  *************************************************/
				if(Depositos[i].isAvailable()){
					sensoresLiquidoTanques[i].value = int(Depositos[i].PercentWithOffset(RA));
					sensoresLiquidoTanques[i].value2 = int(Depositos[i].VolumeWithOffset(RA));
					sensoresLiquidoTanques[i].value3 = int(Depositos[i].totalPercent(RA));
					sensoresLiquidoTanques[i].value4 = int(Depositos[i].totalVolume(RA));
					sensoresLiquidoTanques[i].value5 = (int)Depositos[i].getType();
				}
				else{
					sensoresLiquidoTanques[i].value = 0;
					sensoresLiquidoTanques[i].value2 = 0;
					sensoresLiquidoTanques[i].value3 = 0;
					sensoresLiquidoTanques[i].value4 = 0;
					sensoresLiquidoTanques[i].value5 = 0;
				}
			}


			for(int i=ANALOG_INPUT_1;i<=ANALOG_INPUT_4;i++){
				int habilitadoA = getInt_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));

				if(habilitadoA == 1){
					double pendiente = getDouble_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(PENDIENTE_A));
					double interseccion = getDouble_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(INTERSECCION_A));

					ADC_Channel = analogRead(canalesVolt[i]) * 3.3 / float(4095);
					double valorAnalogico = ADC_Channel * (float(150)/1000.0); //Conversión por divisor de tension
					sensoresAnalogicos[i].value = ((pendiente*valorAnalogico) + interseccion) * 10;
				}
				else{
					sensoresAnalogicos[i].value = 0;
				}
			}

			for(int i=ANALOG_INPUT_5;i<=ANALOG_INPUT_8;i++){
				int habilitadoA = getInt_eeprom(ANALOGICO_BASE+(i*ANALOGICO_LONG)+(HABIL_A));

				if(habilitadoA == 1){
					ADC_Channel = analogRead(canalesPotenciometro[i]) * 3.3 / float(4095);
					double valorAnalogico = ADC_Channel / 2; //Conversión por divisor de tension
					sensoresAnalogicos[i].value = valorAnalogico * 10;
				}
				else{
					sensoresAnalogicos[ANALOG_INPUT_1+i].value = 0;
				}
			}

		}
		osDelay(1);
	}
}
#endif


#endif

#endif /* SRC_TASKS_TASK6_TASK_H_ */
