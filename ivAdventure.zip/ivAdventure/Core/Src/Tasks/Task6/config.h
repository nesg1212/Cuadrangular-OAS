/*
 * config.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK6_CONFIG_H_
#define SRC_TASKS_TASK6_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK6 = 256;
const char* NAME_TASK6 = "Prueba Task 6";
osPriority_t PRIORITY_TASK6 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK6_CONFIG_H_ */
