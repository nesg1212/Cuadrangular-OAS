/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK6_TRIGGER_H_
#define SRC_TASKS_TASK6_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask06_Handle;
osThreadAttr_t myTask06_attributes;


void Trigger_Task06(){
	#ifdef create_task6
		myTask06_attributes.name = NAME_TASK6;
		myTask06_attributes.stack_size = RAM_TASK6 * 4;
		myTask06_attributes.priority = PRIORITY_TASK6;

		myTask06_Handle = osThreadNew(StartTask06, NULL, &myTask06_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK6_TRIGGER_H_ */
