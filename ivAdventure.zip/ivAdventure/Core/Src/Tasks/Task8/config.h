/*
 * config.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK8_CONFIG_H_
#define SRC_TASKS_TASK8_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK8 = 256;
const char* NAME_TASK8 = "Prueba Task 8";
osPriority_t PRIORITY_TASK8 = (osPriority_t) osPriorityAboveNormal7;




#endif /* SRC_TASKS_TASK8_CONFIG_H_ */
