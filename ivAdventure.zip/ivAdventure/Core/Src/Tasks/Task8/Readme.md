Tarea Almacenamiento EEPROM y QSPI y RTC_clock.

RTC
    Funciones
        init -> inicializa el reloj utilizando el I2C seleccionado y la direccion del dispositivo
        setTime -> funcion para grabar hora en memoria del DS3231
            - dayW = dia de la semana (1-7 : domingo-sabado)
            - dayM = dia del mes (0-30 dependiendo del mes)
        getTime -> devuelve un struct TIME que contiene el tiempo contado segun DS3231
    Struct
        Time -> involucra los valores en tiempo calendario que maneja el modulo
        
EEPROM
    Funciones
        init -> inicializa la EEPROM utilizando el I2C seleccionado y la direccion del dispositivo
        write -> Escribe 1 byte en la celda seleccionada [0-255]
        write_16bits -> Escribe 2 bytes en la celda seleccionada y la inmediatamente posterior [0-65535]
        write_float -> Escribe 2 bits repartidos asi
            Byte 1: parte entera del numero [0-255]
            Byte 2: parte decimal del numero [0-255]
            nota: usar valores de xx.00 a xx.99, es decir, solo  2 decimas
            
FLASH
    NO IMPLEMENTADA PORQUE LA PLACA NUCLEO NO POSEE LA COMUNICACION QSPI