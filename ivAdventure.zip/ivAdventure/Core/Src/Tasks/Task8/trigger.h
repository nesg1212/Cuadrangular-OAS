/*
 * trigger.h
 *
 *  Created on: Aug 1, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK8_TRIGGER_H_
#define SRC_TASKS_TASK8_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask08_Handle;
osThreadAttr_t myTask08_attributes;


void Trigger_Task08(){
	#ifdef create_task8
		myTask08_attributes.name = NAME_TASK8;
		myTask08_attributes.stack_size = RAM_TASK8 * 4;
		myTask08_attributes.priority = PRIORITY_TASK8;

		myTask08_Handle = osThreadNew(StartTask08, NULL, &myTask08_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK8_TRIGGER_H_ */
