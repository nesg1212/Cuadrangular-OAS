/*
*	Copyright ACTIONTRACKER SOLUTIONS LA ©
*	@Archivo    : task.h
*	@funcion    : Tarea #8 :: Tarea destinada a la lectura de tiempo por chip REAL TIME CLOCK
*				  y el seguimiento de maximo 10 temporizadores
*/

#ifndef SRC_TASKS_TASK8_TASK_H_
#define SRC_TASKS_TASK8_TASK_H_

#include "../Base_Tasks.h"
#ifdef create_task8

#if defined(STM32F411xE)

	#include "../../Extensions/DS3231.h"
	#include "../../Library/CuentaHoras.h"

	#define TIME_UPDATE 10

	DS3231 RTC1;
	TIME timeRTC1;
	CuentaHoras cuentaHoras[numero_sensores_temporizadores];
	bool primeraEjecucion = true;

	/* USER CODE BEGIN Header_StartTask02 */
	/**
	* @brief Function implementing the myTask02 thread.
	* @param argument: Not used
	* @retval None
	*/
	/* USER CODE END Header_StartTask02 */
	void StartTask08(void *argument)
	{
		uint32_t Ti_RTC=millis();

		Wire3.waitAndTakeSemaphore();
		RTC1.init(Wire3.getWire(),RTC1_ADDRESS);
		Wire3.setSemaphore(FREE);

		do{
			Wire3.waitAndTakeSemaphore();
			timeRTC1=RTC1.getTime();
			Wire3.setSemaphore(FREE);
			if(timeRTC1.isValid)
				break;
			Serial2.waitAndTakeSemaphore();
			Serial2.println(" ERROR! RTC no Encontrado! | ");
			Serial2.setSemaphore(FREE);
			osDelay(300);
		}while(!timeRTC1.isValid);

		Serial2.waitAndTakeSemaphore();
		Serial2.println(" RTC Encontrado");
		Serial2.setSemaphore(FREE);
	//	RTC1.setTime(15, 31, 30, MARTES, 10, 8, 21);

		for(int i=0;i<numero_sensores_temporizadores;i++){
			if(getInt_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HABILTEMP) == 1)
				sensoresTemporizadores[i].habilitado = true;
			if(getInt_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+ESTADO_MEM) == 1)
				sensoresTemporizadores[i].pause = true;

			if(sensoresTemporizadores[i].habilitado){
				sensoresTemporizadores[i].minutosTranscurridos = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+MINUTOSMEM);
				sensoresTemporizadores[i].segundosTranscurridos = 0;
				sensoresTemporizadores[i].horaReg = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HORAREG);
				sensoresTemporizadores[i].fechaReg = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+FECHAREG);
				cuentaHoras[i].init(timeRTC1.hour, timeRTC1.minutes, timeRTC1.seconds);
			}

		}

		for(;;)
		{

			if((millis()-Ti_RTC) >= TEMPORIZADORES_SAMPLE_TIME){
				Ti_RTC=millis();
				Wire3.waitAndTakeSemaphore();
				timeRTC1=RTC1.getTime();
				Wire3.setSemaphore(FREE);

				for(int i=0;i<numero_sensores_temporizadores;i++){
					if(sensoresTemporizadores[i].orden_habilitado){
						long horaRegistro = (timeRTC1.hour*10000) + (timeRTC1.minutes*100) + (timeRTC1.seconds);
						long fechaRegistro = (timeRTC1.year*10000) + (timeRTC1.month*100) + (timeRTC1.dayMonth);

						setLong_eeprom(horaRegistro, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HORAREG);
						setLong_eeprom(fechaRegistro, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+FECHAREG);
						setInt_eeprom((int)true, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HABILTEMP);
						setInt_eeprom((int)false, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+ESTADO_MEM);
						cuentaHoras[i].init(timeRTC1.hour, timeRTC1.minutes, timeRTC1.seconds);
						sensoresTemporizadores[i].orden_habilitado = false;
						sensoresTemporizadores[i].habilitado = true;
						sensoresTemporizadores[i].pause = false;
						sensoresTemporizadores[i].horaReg = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HORAREG);
						sensoresTemporizadores[i].fechaReg = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+FECHAREG);

						Serial2.println("***ORDEN DE HABILITACION***");
					}
					if(sensoresTemporizadores[i].orden_pause){
						//almacenar en EEPROM
						sensoresTemporizadores[i].orden_pause = false;
						sensoresTemporizadores[i].pause = true;
						sensoresTemporizadores[i].play = false;
						setInt_eeprom((int)true, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+ESTADO_MEM);
					}
					if(sensoresTemporizadores[i].orden_play){
						//almacenar en EEPROM
						sensoresTemporizadores[i].orden_play = false;
						sensoresTemporizadores[i].play = true;
						sensoresTemporizadores[i].pause = false;
						cuentaHoras[i].init(timeRTC1.hour, timeRTC1.minutes, timeRTC1.seconds);
						cuentaHoras[i].substractTime(&sensoresTemporizadores[i].minTras, &sensoresTemporizadores[i].secTras);
						setInt_eeprom((int)false, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+ESTADO_MEM);
					}
					if(sensoresTemporizadores[i].orden_reset){
						//almacenar en EEPROM
						sensoresTemporizadores[i].orden_reset = false;
						sensoresTemporizadores[i].reset = true;
						setLong_eeprom(0, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+MINUTOSMEM);

						long horaRegistro = (timeRTC1.hour*10000) + (timeRTC1.minutes*100) + (timeRTC1.seconds);
						long fechaRegistro = (timeRTC1.year*10000) + (timeRTC1.month*100) + (timeRTC1.dayMonth);

						setLong_eeprom(horaRegistro, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HORAREG);
						setLong_eeprom(fechaRegistro, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+FECHAREG);
						cuentaHoras[i].init(timeRTC1.hour, timeRTC1.minutes, timeRTC1.seconds);
					}
					if(sensoresTemporizadores[i].orden_remove){
						//almacenar en EEPROM
						sensoresTemporizadores[i].orden_remove = false;
						sensoresTemporizadores[i].remove = true;
						sensoresTemporizadores[i].habilitado = false;
						setLong_eeprom(0, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+MINUTOSMEM);
						setLong_eeprom(0, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HORAREG);
						setLong_eeprom(0, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+FECHAREG);
						setInt_eeprom((int)false, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+ESTADO_MEM);
						setInt_eeprom((int)false, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HABILTEMP);
					}

		/******************************  CONSULTA A TEMPORIZADORES DISPONIBLES  *************************************************/
					if(sensoresTemporizadores[i].habilitado){
						if(timeRTC1.isValid){
							if(!sensoresTemporizadores[i].pause){
								bool timeOut = cuentaHoras[i].diff(timeRTC1.hour, timeRTC1.minutes, timeRTC1.seconds, &sensoresTemporizadores[i].minTras, &sensoresTemporizadores[i].secTras, TIME_UPDATE);
								if(timeOut){
									long minutosMem = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+MINUTOSMEM);
									setLong_eeprom(minutosMem+TIME_UPDATE, TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+MINUTOSMEM);
								}
							}
							sensoresTemporizadores[i].minutosTranscurridos = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+MINUTOSMEM) + (long)sensoresTemporizadores[i].minTras;
							sensoresTemporizadores[i].segundosTranscurridos = (int)sensoresTemporizadores[i].secTras;
						}
						sensoresTemporizadores[i].horaReg = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+HORAREG);
						sensoresTemporizadores[i].fechaReg = getLong_eeprom(TEMPORIZADOR_BASE+(i*TEMPORIZADOR_LONG)+FECHAREG);
					}
					else{
						sensoresTemporizadores[i].minutosTranscurridos = 0;
						sensoresTemporizadores[i].segundosTranscurridos = 0;
						sensoresTemporizadores[i].horaReg = 0;
						sensoresTemporizadores[i].fechaReg = 0;
					}
				}
				//Serial2.print("horaReg:");Serial2.println((int)sensoresTemporizadores[0].horaReg);
				//Serial2.print("fechaReg:");Serial2.println((int)sensoresTemporizadores[0].fechaReg);
				//Serial2.print("MinTras:");Serial2.println((int)sensoresTemporizadores[0].minutosTranscurridos);
				//Serial2.print("secTras:");Serial2.println((int)sensoresTemporizadores[0].segundosTranscurridos);
	}

			osDelay(1);
		}
	  /* USER CODE END StartTask02 */
	}

#elif defined(STM32F107xC)

	void StartTask08(void *argument){
		for(;;){
			osDelay(500);
		}
	}
#endif

#endif
#endif /* SRC_TASKS_TASK8_TASK_H_ */
