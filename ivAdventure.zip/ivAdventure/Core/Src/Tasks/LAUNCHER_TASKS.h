/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : LAUNCHER_TASK.h
*	@funcion    : Lanzador de tareas. Llama a todas las tareas, sus configuraciones e inicializa el kernel
*				  del FreeRTOS del STM32
*/

#ifndef SRC_TASKS_LAUNCHER_TASKS_H_
#define SRC_TASKS_LAUNCHER_TASKS_H_

//include all tasks
#include "Task0/trigger.h"
#include "Task0b/trigger.h"
#include "Task1/trigger.h"
#include "Task2/trigger.h"
#include "Task3/trigger.h"
#include "Task4/trigger.h"
#include "Task5/trigger.h"
#include "Task6/trigger.h"
#include "Task7/trigger.h"
#include "Task8/trigger.h"
#include "Task9/trigger.h"
#include "Task10/trigger.h"
#include "Task11/trigger.h"
#include "Task12/trigger.h"
#include "Task13/trigger.h"
#include "Task14/trigger.h"


void LAUNCHER_TASK(){
	osKernelInitialize();

	inicializar_eeprom();

	InitSemaphore();

	Trigger_Task0();
	Trigger_Task0b();
	Trigger_Task1();
	Trigger_Task02();
	Trigger_Task03();
	Trigger_Task04();
	Trigger_Task05();
	Trigger_Task06();
	Trigger_Task07();
	Trigger_Task08();
	Trigger_Task09();
	Trigger_Task10();
	Trigger_Task11();
	Trigger_Task12();
	Trigger_Task13();
	Trigger_Task14();

	osKernelStart();  /* Start scheduler */
}


#endif /* SRC_TASKS_LAUNCHER_TASKS_H_ */
