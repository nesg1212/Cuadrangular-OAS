/*
 * config.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK2_CONFIG_H_
#define SRC_TASKS_TASK2_CONFIG_H_

#include "../Base_Tasks.h"

uint32_t RAM_TASK2 = 256;
const char* NAME_TASK2 = "myTask02";
osPriority_t PRIORITY_TASK2 = (osPriority_t) osPriorityHigh;



#endif /* SRC_TASKS_TASK2_CONFIG_H_ */
