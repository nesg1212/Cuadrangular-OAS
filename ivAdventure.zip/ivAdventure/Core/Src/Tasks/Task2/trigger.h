/*
 * trigger.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK2_TRIGGER_H_
#define SRC_TASKS_TASK2_TRIGGER_H_

#include "../Base_Tasks.h"
#include "config.h"
#include "task.h"

osThreadId_t myTask02Handle;
osThreadAttr_t myTask02_attributes;


void Trigger_Task02(){
	#ifdef create_task2
		myTask02_attributes.name = NAME_TASK2;
		myTask02_attributes.stack_size = RAM_TASK2 * 4;
		myTask02_attributes.priority = PRIORITY_TASK2;

		myTask02Handle = osThreadNew(StartTask02, NULL, &myTask02_attributes);
	#endif
}



#endif /* SRC_TASKS_TASK2_TRIGGER_H_ */
