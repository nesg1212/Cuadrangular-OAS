/*
 * task2.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK2_TASK_ORIGINAL_H_
#define SRC_TASKS_TASK2_TASK_ORIGINAL_H_

#ifdef create_task2

#include "../Base_Tasks.h"
#include "../../Extensions/LSM9DS1/LSM9DS1.h"
#include "../../Library/Suspension.h"

//Wire Wire1(I2C1,MASTER);
LSM9DS1 IMU;
Suspension IMU_SUSP(COMPLEMENTARY_FILTER);

float ax, ay, az, gx, gy, gz, mx, my, mz;
uint32_t previousTime, currentTime=0, elapsedTime;

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the myTask02 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */

void StartTask02(void *argument)
{
	bool IMU_Working;

	osDelay(100);

	Wire3.waitAndTakeSemaphore();
	IMU_Working=IMU.begin(ACC_GIRO_ADDRESS, MAG_ADDRESS,Wire3.getWire());
	IMU.setMagScale(16);
	IMU.setAccelScale(16);
	IMU.setGyroScale(2000);
	Wire3.setSemaphore(FREE);

	Serial2.waitAndTakeSemaphore();

	//Serial2.println("NOV,ROLL,PITCH,YAW,NNOV");
	//if(IMU_Working)
		//Serial2.println("Tarea 2 -> IMU ENCONTRADA");
	//else
		//Serial2.println("Tarea 2 -> ERROR! LSM9DS1 NO ENCONTRADA");
	Serial2.setSemaphore(FREE);
	IMU.setGyroODR(6);
	uint32_t Ti=millis();
	int cont=0;

	for(;;)
	{
		Wire3.waitAndTakeSemaphore();
		IMU.readAccel(&ax,&ay,&az);
		IMU.readGyro(&gx,&gy,&gz);
		IMU.readMag(&mx,&my,&mz);
		Wire3.setSemaphore(FREE);
		//gx=gx+0.8;
		IMU_SUSP.setDofValues(ax, ay, az, gx, gy, gz, mx, my, mz);
/*
		Serial2.print("A->");Serial2.print(ax);
		Serial2.print(",");Serial2.print(ay);
		Serial2.print(",");Serial2.print(az);Serial2.println("");
		Serial2.print("G->");Serial2.print(gx);
		Serial2.print(",");Serial2.print(gy);
		Serial2.print(",");Serial2.print(gz);Serial2.println("");
		Serial2.print("M->");Serial2.print(mx);
		Serial2.print(",");Serial2.print(my);
		Serial2.print(",");Serial2.println(mz);

		Serial2.print(int(millis()-Ti));Serial2.print(",");
		Serial2.print(ax);Serial2.print(",");
		Serial2.print(ay);Serial2.print(",");
		Serial2.print(az);Serial2.print(",");
		Serial2.print(gx);Serial2.print(",");
		Serial2.print(gy);Serial2.print(",");
		Serial2.print(gz);Serial2.print(",");
		Serial2.print(mx);Serial2.print(",");
		Serial2.print(my);Serial2.print(",");
		Serial2.print(mz);Serial2.print(",");
*/
		Ti= millis();
		float roll = IMU_SUSP.getRoll(ACC_MAG_GYRO_CF,DEGREES);
		float pitch = IMU_SUSP.getPitch(ACC_MAG_GYRO_CF,DEGREES);
		float yaw = IMU_SUSP.getYaw(ACC_MAG_GYRO_CF,DEGREES);

		//Serial2.print(roll);Serial2.print(",");
		//Serial2.print(pitch);Serial2.print(",");
		//Serial2.print(yaw);

		sensoresInclinaciones[IMU_LSM9DS1_1].value = 12;
		sensoresInclinaciones[IMU_LSM9DS1_1].value2 = 15;
		sensoresInclinaciones[IMU_LSM9DS1_1].value3 = 18;

		Serial2.waitAndTakeSemaphore();
		/*
		Serial2.print(90);Serial2.print(",");
		Serial2.print(roll);Serial2.print(",");
		Serial2.print(pitch);Serial2.print(",");
		Serial2.print(yaw);Serial2.print(",");
		Serial2.println(-90);
		*/
		Serial2.println("");
		Serial2.setSemaphore(FREE);
		osDelay(8);
	}
	  /* USER CODE END StartTask02 */
}

#endif

#endif /* SRC_TASKS_TASK2_TASK_ORIGINAL_H_ */
