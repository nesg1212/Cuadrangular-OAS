/*
 * task2.h
 *
 *  Created on: Jul 21, 2020
 *      Author: compr
 */

#ifndef SRC_TASKS_TASK2_TASK_H_
#define SRC_TASKS_TASK2_TASK_H_

#include "../Base_Tasks.h"

#ifdef create_task2

#if defined(STM32F411xE)

	#include "../../Config_pines/LSM9DS1/LSM9DS1.h"
	#include "../../Library/Suspension.h"
	#include <stdint.h>
	#include "RandomForestClasificador_V.0.h"

	LSM9DS1 IMU;
	Suspension IMU_SUSP(COMPLEMENTARY_FILTER);
	Eloquent::ML::Port::RandomForest clf;//constructor del modelo de IA

	float ax, ay, az, gx, gy, gz, mx, my, mz;
	uint32_t previousTime, currentTime=0, elapsedTime;

	typedef struct{
	  float x;
	  float y;
	  float z;
	}Plano_cartesiano;

	typedef struct{
	  float constan_1;
	  float constan_2;
	  float constan_3;
	}Constante_persona;

	Plano_cartesiano acelerometro;
	Plano_cartesiano giroscopo;
	Plano_cartesiano magnetometro;
	Constante_persona constante_persona_para_esp32;

	int Prediccion_modelo_inteligencia_artificial(Plano_cartesiano ace, Plano_cartesiano mag, Plano_cartesiano gir, Constante_persona constant);


	/* USER CODE BEGIN Header_StartTask02 */
	/**
	* @brief Function implementing the myTask02 thread.
	* @param argument: Not used
	* @retval None
	*/
	/* USER CODE END Header_StartTask02 */

	void StartTask02(void *argument)
	{
		bool IMU_Working;

		osDelay(100);

		Wire3.waitAndTakeSemaphore();
		IMU_Working=IMU.begin(ACC_GIRO_ADDRESS, MAG_ADDRESS,Wire3.getWire());
		IMU.setMagScale(16);
		IMU.setAccelScale(16);
		IMU.setGyroScale(2000);
		Wire3.setSemaphore(FREE);

		Serial2.waitAndTakeSemaphore();
		Serial2.println("NOV,ROLL,PITCH,YAW,NNOV");
		Serial2.setSemaphore(FREE);

		IMU.setGyroODR(6);
		uint32_t Ti=millis();
		int cont=0;

		acelerometro.x = -2.86;
		acelerometro.y = 4.54;
		acelerometro.z = 8.10;

		giroscopo.x = 46.48;
		giroscopo.y = 21.89;
		giroscopo.z = 11.10;

		magnetometro.x = 0;
		magnetometro.y = 0;
		magnetometro.z = 0;

		constante_persona_para_esp32.constan_1 = 1;// ESP32 prueba... dejar fijo por ahora.
		constante_persona_para_esp32.constan_2 = 0;
		constante_persona_para_esp32.constan_3 = 0;

		for(;;)
		{
			Wire3.waitAndTakeSemaphore();
			IMU.readAccel(&ax,&ay,&az);
			IMU.readGyro(&gx,&gy,&gz);
			IMU.readMag(&mx,&my,&mz);
			Wire3.setSemaphore(FREE);

			IMU_SUSP.setDofValues(ax, ay, az, gx, gy, gz, mx, my, mz);
			acelerometro.x = ax;
			acelerometro.y = ay;
			acelerometro.z = az;
			giroscopo.x = gx;
			giroscopo.y = gy;
			giroscopo.z = gz;

			int respuesta_prediccion = Prediccion_modelo_inteligencia_artificial(acelerometro, magnetometro, giroscopo, constante_persona_para_esp32);

			Serial2.waitAndTakeSemaphore();
			Serial2.print(respuesta_prediccion);Serial2.print(",");
			Serial2.print(int(millis()-Ti));Serial2.print(",");
			Serial2.print(ax);Serial2.print(",");
			Serial2.print(ay);Serial2.print(",");
			Serial2.print(az);Serial2.print(",");
			Serial2.print(gx);Serial2.print(",");
			Serial2.print(gy);Serial2.print(",");
			Serial2.print(gz);Serial2.print(",");
			Serial2.print(mx);Serial2.print(",");
			Serial2.print(my);Serial2.print(",");
			Serial2.print(mz);Serial2.print(",");

			Ti= millis();

			//Serial.print("estado [0 - Caminar; 1 - subir escalera]: ");
			  //Serial.print(respuesta_prediccion);
			  //Serial.println(" ");

			Serial2.println("");
			Serial2.setSemaphore(FREE);
			osDelay(8);
		}
		  /* USER CODE END StartTask02 */
	}

	int Prediccion_modelo_inteligencia_artificial(Plano_cartesiano ace, Plano_cartesiano mag, Plano_cartesiano gir, Constante_persona constant){
	  float data[12];
	  data[0] = ace.x;
	  data[1] = ace.y;
	  data[2] = ace.z;

	  data[3] = gir.x;
	  data[4] = gir.y;
	  data[5] = gir.z;

	  data[6] = mag.x;
	  data[7] = mag.y;
	  data[8] = mag.z;

	  data[9] = constant.constan_1;
	  data[10] = constant.constan_2;
	  data[11] = constant.constan_3;

	  return clf.predict(data);
	}

#elif defined(STM32F107xC)

	#include "../../Extensions/ADXL.h"

	SPI Spi2(SPI2,MASTER_MODE);
	ADXL adxl;
	ADXL_InitTypeDef adxlDef;

	void StartTask02(void *argument){

		uint32_t Ti=millis();
		uint16_t dataACC[3];
		Spi2.begin(SPI_SPEED_18MHZ);
		adxl.begin(Spi2, SPI2_ADXL_PORT, SPI2_ADXL_PIN);

		adxlDef.AutoSleep = AUTOSLEEPOFF;
		adxlDef.IntMode = INT_ACTIVEHIGH;
		adxlDef.Justify = JUSTIFY_MSB;
		adxlDef.LPMode = LPMODE_NORMAL;
		adxlDef.LinkMode = LINKMODEON;
		adxlDef.Range = RANGE_8G;
		adxlDef.Rate = BWRATE_800;
		adxlDef.Resolution = RESOLUTION_FULL;
		adxlDef.SPIMode = SPIMODE_4WIRE;
		adxl.Init(&adxlDef);

		adxl.disableActivity();
		adxl.disableDoubleTap();
		adxl.disableFreeFall();
		adxl.disableSelfTest();
		adxl.disableSingleTap();
		adxl.measure(ON);

		for(;;){
			if((millis()-Ti) >= 1000){
				adxl.getAccel(dataACC, OUTPUT_SIGNED);
				Serial3.waitAndTakeSemaphore();
				Serial3.print("A_X:");
				Serial3.print(dataACC[1]);
				Serial3.print("  A_Y:");
				Serial3.print(dataACC[2]);
				Serial3.print("  A_Z:");
				Serial3.print(dataACC[3]);
				Serial3.setSemaphore(FREE);
			}
		}
	}

#endif
#endif
#endif /* SRC_TASKS_TASK2_TASK_H_ */
