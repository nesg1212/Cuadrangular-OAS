/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : EEPROM.h
*	@funcion    : define las funciones necesarias para manejo de la EEPROM
*				  de caracter independiente a los ticks de las tareas, es decir
*				  que se convierte en una ejecución que todas las tareas pueden llamar
*				  en cualquier momento.
*/

#ifndef SRC_UTIL_EEPROM_H_
#define SRC_UTIL_EEPROM_H_

#if defined(STM32F411xE)

	#include "../Extensions/EEPROM_24LCxxx.h"
	#include "../Tasks/SemaphoreData/MemoryBlock.h"

	#define EEPROM_SIZE 1000*3
	EEPROM_24LCxxx Memory1;
	uint8_t VectorSistema[EEPROM_SIZE];

	void refresh_eeprom_vector(){
		for(int i=0;i<EEPROM_SIZE;i++){
			VectorSistema[i] = Memory1.read(i);
		}
	}

	void inicializar_eeprom(){
	#if defined(STM32F411xE)
		Wire3.waitAndTakeSemaphore();
		bool EEPROM1_Working = Memory1.init(Wire3.getWire(), EEPROM1_ADDRESS);
		Wire3.setSemaphore(FREE);

		if(EEPROM1_Working) Serial2.println("EEPROM Encontrado");
		else Serial2.println(" ERROR! EEPROM no Encontrado!");
	#elif defined(STM32F107xC)
		Wire1.waitAndTakeSemaphore();
		bool EEPROM1_Working = Memory1.init(Wire1.getWire(), EEPROM1_ADDRESS);
		Wire1.setSemaphore(FREE);

		if(EEPROM1_Working) Serial3.println("EEPROM Encontrado");
		else Serial3.println(" ERROR! EEPROM no Encontrado!");
	#endif



		refresh_eeprom_vector();
	}

	int getInt_eeprom(uint32_t pos){
		pos*=3;
		int valor = ((VectorSistema[pos]<<8)&0xFF00) + VectorSistema[pos+1];
		if((VectorSistema[pos]>>7)&0x01){
			valor = valor&0x7FFF;
			valor *= -1;
		}

		return(valor);
	}

	long getLong_eeprom(uint32_t pos){
		pos*=3;
		long valor = ((VectorSistema[pos]<<16)) + (VectorSistema[pos+1]<<8) + VectorSistema[pos+2];
		if((VectorSistema[pos]>>15)&0x01){
			valor = valor&0x7FFFFF;
			valor *= -1;
		}

		return(valor);
	}

	double getDouble_eeprom(uint32_t pos){
		pos*=3;
		int valor_ = ((VectorSistema[pos]<<8)&0xFF00) + VectorSistema[pos+1];
		double decimal = double(VectorSistema[pos+2])/100.0;

		if((VectorSistema[pos]>>7)&0x01){
			valor_ = valor_ & 0x7FFF;
			valor_ *= -1;
			return(double(valor_) - decimal);
		}

		return(double(valor_) + decimal);
	}

	void setInt_eeprom(int dato, uint32_t pos){
		pos*=3;
		if(dato < 0){
			dato *= -1;
			dato |= 0x8000;
		}
		Memory1.write(pos, (dato>>8)&0xFF);
		VectorSistema[pos] = (dato>>8)&0xFF;
		HAL_Delay(2);
		Memory1.write(pos+1, (dato)&0xFF);
		VectorSistema[pos+1] = (dato)&0xFF;
		HAL_Delay(2);
	}

	void setLong_eeprom(long dato, uint32_t pos){
		pos*=3;
		if(dato < 0){
			dato *= -1;
			dato |= 0x800000;
		}
		Memory1.write(pos, (dato>>16)&0xFF);
		VectorSistema[pos] = (dato>>16)&0xFF;
		HAL_Delay(2);
		Memory1.write(pos+1, (dato>>8)&0xFF);
		VectorSistema[pos+1] = (dato>>8)&0xFF;
		HAL_Delay(2);
		Memory1.write(pos+2, (dato)&0xFF);
		VectorSistema[pos+2] = (dato)&0xFF;
		HAL_Delay(2);
	}

	void setDouble_eeprom(double dato, uint32_t pos){
		pos*=3;
		int entero = int(dato);
		int decimal = double(dato-entero)*100.0;

		if(decimal < 0){
			decimal *= -1;
		}
		if(entero < 0){
			entero *= -1;
			entero |= 0x8000;
		}

		Memory1.write(pos, (entero>>8)&0xFF);
		VectorSistema[pos] = (entero>>8)&0xFF;
		HAL_Delay(2);
		Memory1.write(pos+1, (entero)&0xFF);
		VectorSistema[pos+1] = (entero)&0xFF;
		HAL_Delay(2);
		Memory1.write(pos+2, decimal);
		VectorSistema[pos+2] = decimal;
		HAL_Delay(2);
	}

#elif defined(STM32F107xC)

	#include "../Extensions/INT_FLASH.h"
	#include "../Tasks/SemaphoreData/MemoryBlock.h"

	#define FLASH_PAGE_125 0x0803E800
	#define FLASH_PAGE_126 0x0803F000
	#define FLASH_PAGE_127 0x0803F800
	#define EEPROM_SIZE 1000//*3
	INT_FLASH Memory1;
	uint32_t VectorSistema[EEPROM_SIZE];

	void refresh_eeprom_vector(){//OK
		uint32_t RxBuf[1000];
		Memory1.read(FLASH_PAGE_125, RxBuf, 1000);
		memmove(VectorSistema, &RxBuf, sizeof(1000));//Page 125
		Memory1.read(FLASH_PAGE_126, RxBuf, 1000);
		memmove(VectorSistema, &RxBuf, sizeof(1000));//Page 126
		Memory1.read(FLASH_PAGE_127, RxBuf, 1000);
		memmove(VectorSistema, &RxBuf, sizeof(1000));//Page 127
	}

	void inicializar_eeprom(){//OK
		Serial3.println("LEYENDO BUFFER EN MEMORIA FLASH");
		refresh_eeprom_vector();
		Serial3.println("LECTURA FINALIZADA");
	}

	void writeGlobal_eeprom(){//OK
		uint32_t* temporal;
		memmove(temporal, &VectorSistema[0], sizeof(1000));
		Memory1.write(FLASH_PAGE_125, temporal, 1000);
		memmove(temporal, &VectorSistema[1000], sizeof(1000));
		Memory1.write(FLASH_PAGE_126, temporal, 1000);
		memmove(temporal, &VectorSistema[2000], sizeof(1000));
		Memory1.write(FLASH_PAGE_127, temporal, 1000);
	}

	int getInt_eeprom(uint32_t pos){//OK
		int valor = (int)VectorSistema[pos];
		if((VectorSistema[pos]>>7)&0x01){
			valor = valor&0x7FFF;
			valor *= -1;
		}

		return(valor);
	}

	long getLong_eeprom(uint32_t pos){//OK
		long valor = (long)VectorSistema[pos];
		if((VectorSistema[pos]>>15)&0x01){
			valor = valor&0x7FFFFF;
			valor *= -1;
		}

		return(valor);
	}

	double getDouble_eeprom(uint32_t pos){//OK
		int valor_ = (int)(VectorSistema[pos]>>8)&0xFF;
		double decimal = double(VectorSistema[pos]&0xFF)/100.0;

		if((VectorSistema[pos]>>24)&0x01){
			valor_ = valor_ & 0x7FFF00;
			valor_ *= -1;
			return(double(valor_) - decimal);
		}

		return(double(valor_) + decimal);
	}

	void setInt_eeprom(int dato, uint32_t pos){//OK
		if(dato < 0){
			dato *= -1;
			dato |= 0x8000;
		}
		VectorSistema[pos] = (uint32_t)dato;
		writeGlobal_eeprom();
		HAL_Delay(2);
	}

	void setLong_eeprom(long dato, uint32_t pos){//OK
		if(dato < 0){
			dato *= -1;
			dato |= 0x800000;
		}
		VectorSistema[pos] = (uint32_t)dato;
		writeGlobal_eeprom();
		HAL_Delay(2);
	}

	void setDouble_eeprom(double dato, uint32_t pos){//OK
		int entero = int(dato);
		int decimal = double(dato-entero)*100.0;

		if(decimal < 0){
			decimal *= -1;
		}
		if(entero < 0){
			entero *= -1;
			entero |= 0x8000;
		}

		VectorSistema[pos] = (uint32_t)((entero<<8)&0xFF) | ((uint32_t)(decimal)&0xFF);
		writeGlobal_eeprom();
		HAL_Delay(2);
	}
#endif



#endif /* SRC_UTIL_EEPROM_H_ */
