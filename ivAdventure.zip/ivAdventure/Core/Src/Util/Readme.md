/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : Struct.h & enum.h
*	@funcion    : Declaraciones de estructuras y variables ENUM de todo el sistema ivAdventure
				  Aqui se centralizan todas variables tipo ENUM que son aquellas que minimizan el uso de 
				  memoria en el microcontrolador STM32.
				  Adicionalmente las estructuras que son conjuntos de variables a las cuales es posible
				  asignar una acquitectura basada en POO.
*/

* DataESP32Datalogger;
- TipoSolicitud_Datalogger  tipoSolicitudDatalogger: Tipo de solicitud recibida, puede ser:
- uint8_t SlaveNumber: numero de esclavo que por ahora es 0.
- uint8_t SegmentosPendientes: cantidad de segmentos de tramas a guardar segmentado por la limitante de I2C
	de transmitir o recibir no mas de 255 Bytes.
- char trama[2000]={'\0'}: Vector donde se almacena la trama de datos recibida
- bool tramaAvailable: indica la disponibilidad de datos nuevos en la trama para ser almacenador.

