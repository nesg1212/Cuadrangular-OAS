/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : structs.h
*	@funcion    : Aqui se construyen todas las estructuras manejadas en el proyecto
*/

#ifndef SRC_UTIL_STRUCTS_H_
#define SRC_UTIL_STRUCTS_H_

#include "enums.h"

typedef struct dataESP32
{
	uint8_t SlaveNumber;
	TipoSolicitud tipoSolicitud;
	uint8_t Port;
	uint8_t new_value;
	uint8_t new_value2;
	uint8_t new_value3;
	ModulosApp modulo;
} DataESP32;

typedef struct{
	TipoSolicitud_Datalogger  tipoSolicitudDatalogger;
	uint8_t SlaveNumber;
	uint8_t SegmentosPendientes;
	char trama[2000]={'\0'};
	bool tramaAvailable;
} DataESP32Datalogger;

typedef struct tipoPort
{
	uint8_t port;
	uint8_t value;
} TipoPort;

typedef struct port
{
	uint8_t port;
	uint8_t value;
	TipoPuerto tipoPuerto;
	TipoEntrada tipoEntrada;
} Port;

typedef struct medidas_tanque
{
	uint16_t alto;
	uint16_t largo;
	uint16_t ancho;
} Medidas_tanques;

typedef struct almacenar_resistencia
{
	bool zero_absoluto;
	bool offset_minimo;
	bool offset_maximo;
	bool maximo_absoluto;
	bool inflexion;
} Almacenar_resistencia;

typedef struct inflexion //MOD_JOSE
{
	uint16_t alto;
	uint16_t largo;
	uint16_t ancho;
} Inflexion;

typedef struct tanque
{
	bool valores_depositos_disponible=false;
	uint8_t port;
	int value;
	int value2;
	int value3;
	int value4;
	int value5;

	uint8_t tipo_tanque;

	//tanque irregular 1
	Almacenar_resistencia orden_almacenar_resistencia;
	Medidas_tanques medidas_tanque_inferior;
	Medidas_tanques medidas_tanque_superior;
	bool matricular_tanque=false;
	bool desmatricular_tanque=false;

	//tanque irregular 2
	Inflexion punto_inflexion;
	uint8_t contador_punto_inflexion=0;
	Almacenar_resistencia orden_almacenar_resistencia_inflexion;
	bool matricular_tanque_2=false;

	//tanque irregular 3
	double valores_depositos[101];
} Tanque;

typedef struct{
	uint8_t port;
	long horaReg;
	long fechaReg;
	long minutosTranscurridos;
	int segundosTranscurridos;
	bool orden_habilitado;
	bool orden_reset;
	bool orden_pause;
	bool orden_play;
	bool orden_remove;
	bool habilitado;
	bool reset;
	bool pause;
	bool play;
	bool remove;
	uint8_t minTras;
	uint8_t secTras;
}Temporizador;

typedef struct{
	uint8_t port;
	int value;
	int value2;
	int value3;
	int value4;
	int value5;
}Sensor;

typedef struct {
	bool kp;
	bool ki;
	bool kd;
	bool available;
	bool tm;
	bool output;
	bool setpoint;
}PID_PARAM;

typedef struct{
	int available = 0;
	PID_PARAM pid_flag;
	double kp = 1;
	double ki = 0.01;
	double kd = 0.01;
	double setpoint = 0;
	int tm = 500;
	double output = 10;
}PID_VALUE;

typedef struct{
	uint8_t port;
	uint8_t value;
	PID_VALUE pid;
} Actuador;

typedef struct {
	uint8_t validez; //0->NO, 1->SI, 2-7->no implementado
	char *hora;
	uint8_t numSat;
	double logitud;
	double latitud;
	uint8_t port;
}GPS;

typedef struct sensor_RTC
{
	uint8_t year;
	uint8_t month;
	uint8_t day;
	uint8_t dayOfWeek;
	uint8_t hour;
	uint8_t minute;
	uint8_t seconds;
};

typedef struct ds18b20_info{
	bool scanner = false; //OK
	uint8_t ROM[8]={0}; //OK
	uint8_t offset=0; //OK
	uint8_t Temperatura=0; //OK
	uint8_t puerto=0;
	bool almacenar=false;
}DS18B20_info;

typedef struct{
	bool tramaAvailable;
	char trama[2000]={'\0'};
}SYSTEM_DATALOGGER;


#endif /* SRC_UTIL_STRUCTS_H_ */
