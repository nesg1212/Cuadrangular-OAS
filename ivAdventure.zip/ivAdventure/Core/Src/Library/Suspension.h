/*
 * Suspension.h
 *
 *  Created on: 20/11/2020
 *      Author: Ing.JoseBenitez
 */

#ifndef SRC_LIBRARY_SUSPENSION_H_
#define SRC_LIBRARY_SUSPENSION_H_

#include <math.h>

typedef enum{
	DEGREES,
	RADIANS
}TYPE_RESPONSE;

typedef enum{
	COMPLEMENTARY_FILTER,
	KALMAN_FILTER
}FILTER;

typedef enum{
	ACC,
	MAG,
	GYRO,
	ACC_MAG,
	ACC_MAG_GYRO_CF
}RPY_SOURCE;

class Suspension{
private:
	FILTER filterType;
	float ax, ay, az;
	float gx, gy, gz;
	float mx, my, mz;
	uint32_t tiempo_prev = 0;
	float dt = 0;
	float gyroRoll_1=0, gyroPitch_1=0, gyroYaw_1=0;
	float roll_1=0, pitch_1=0, yaw_1=0;
	float ACC_OFFSET=0.015*0;
	float GYRO_OFFSET=0.8;
	float MAG_OFFSET=0;
public:
	Suspension(FILTER filterType){
		this->filterType = filterType;
	}
	void setDofValues(float ax,float ay, float az, float gx,float gy, float gz, float mx,float my, float mz){
		this->ax = ax + ACC_OFFSET;
		this->ay = ay + ACC_OFFSET;
		this->az = az + ACC_OFFSET;
		this->gx = gx + GYRO_OFFSET;
		this->gy = gy + GYRO_OFFSET;
		this->gz = gz + GYRO_OFFSET;
		this->mx = mx + MAG_OFFSET;
		this->my = my + MAG_OFFSET;
		this->mz = mz + MAG_OFFSET;
		dt = getTimeElapsed();
	}
	float getRoll(RPY_SOURCE source, TYPE_RESPONSE typeResponse){
		float roll=0;

		if(source == ACC || source == ACC_MAG){
			roll = (-1) * (float)(atan2(ay,az));
			if(typeResponse == DEGREES) roll = RAD_TO_DEG(roll);
		}
		if(source == GYRO){
			roll = gyroRoll_1 + gx*dt;
			gyroRoll_1 = roll;
			if(typeResponse == RADIANS) roll = DEG_TO_RAD(roll);
		}
		if(source == ACC_MAG_GYRO_CF){
			float Aroll = (-1) * (float)(atan2(ay,az));
			Aroll = RAD_TO_DEG(Aroll);
			float Groll = (float)(gyroRoll_1 + gx*dt);
			gyroRoll_1 = Groll;
			roll = 0.98 * (roll_1 + gx*dt) + 0.02 * Aroll;
			roll_1=roll;
			if(typeResponse == RADIANS) roll = DEG_TO_RAD(roll);
		}

		return(roll);
	}
	float getPitch(RPY_SOURCE source, TYPE_RESPONSE typeResponse){
		float pitch=0;

		if(source == ACC || source == ACC_MAG){
			pitch = (-1) * (float)(atan2(-ax,sqrt(pow(ay,2)+pow(az,2))));
			if(typeResponse == DEGREES) pitch = RAD_TO_DEG(pitch);
		}
		if(source == GYRO){
			pitch = gyroPitch_1 + gy*dt;
			gyroPitch_1 = pitch;
			if(typeResponse == RADIANS) pitch = DEG_TO_RAD(pitch);
		}
		if(source == ACC_MAG_GYRO_CF){
			float Apitch = (-1) * (float)(atan2(-ax,az));
			Apitch = RAD_TO_DEG(Apitch);
			float Gpitch = (float)(gyroPitch_1 + gy*dt);
			gyroPitch_1 = Gpitch;
			pitch = 0.98 * (pitch_1 + gy*dt) + 0.02 * Apitch;
			pitch_1=pitch;
			if(typeResponse == RADIANS) pitch = DEG_TO_RAD(pitch);
		}
		return((-1) * pitch);
	}
	float getYaw(RPY_SOURCE source, TYPE_RESPONSE typeResponse){
		float yaw=0;

		if(source == MAG){
			yaw=(float)(atan2(my,mx));
			if(typeResponse == DEGREES) yaw = RAD_TO_DEG(yaw);
		}
		if(source == ACC_MAG){
			float ARoll = getRoll(ACC_MAG_GYRO_CF, RADIANS);
			float APitch = getPitch(ACC_MAG_GYRO_CF, RADIANS);
			float Mx = (mx*cos(APitch)) + (mz*sin(APitch));
			float My = (mx*sin(ARoll)*sin(APitch)) + (my*cos(ARoll)) - (mz*sin(ARoll)*cos(APitch));
			//float Mx = (mx*cos(APitch)) + (my*sin(ARoll)*sin(APitch)) + (mz*cos(ARoll)*sin(APitch));
			//float My = (my*cos(ARoll)) - (mz*sin(ARoll));
			yaw = atan2(-My,Mx);
			if(typeResponse == DEGREES) yaw = RAD_TO_DEG(yaw);
		}
		if(source == GYRO){
			yaw = gyroYaw_1 + gz*dt;
			gyroYaw_1 = yaw;
		}
		if(source == ACC_MAG_GYRO_CF){
			float ARoll = getRoll(ACC_MAG_GYRO_CF, RADIANS);
			float APitch = getPitch(ACC_MAG_GYRO_CF, RADIANS);
			float Mx = (mx*cos(APitch)) + (mz*sin(APitch));
			float My = (mx*sin(ARoll)*sin(APitch)) + (my*cos(ARoll) - (mz*sin(ARoll)*cos(APitch)));
			float Ayaw = atan2(-My,Mx);
			Ayaw = RAD_TO_DEG(Ayaw);
			float Gyaw = (float)(gyroYaw_1 + gz*dt);
			gyroYaw_1 = Gyaw;
			yaw = 0.98 * (yaw_1 + gz*dt) + 0.02 * Ayaw;
			yaw_1=yaw;
		}
		return(yaw);
	}

	float RAD_TO_DEG(float value){
		return(value*180/M_PI);
	}
	float DEG_TO_RAD(float value){
		return(value*M_PI/180);
	}

	float getTimeElapsed(){
		float dt = (float)(millis() - tiempo_prev) / (float)1000.0;
		tiempo_prev = millis();
		return(dt);
	}
};

#endif /* SRC_LIBRARY_SUSPENSION_H_ */
