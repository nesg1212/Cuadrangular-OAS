/*
*	Copyright ACTIONTRACKER©
*	@Archivo    : Deposito.h
*	@funcion    : Clase que integra contiene todas las operaciones internas de los tanques.
*/

#ifndef SRC_LIBRARY_DEPOSITO_H_
#define SRC_LIBRARY_DEPOSITO_H_

#define TANQUE_ACTIVO 0
#define TIPO_TANQUE 1
#define NUM_TANQUE 2
#define CANT_NIVELES 3
#define DIMENSION_L 4
#define DIMENSION_W 14
#define DIMENSION_H 24
#define RINF 34
#define RINFLEX 35
#define RSUP 39
#define ROFFL 40
#define ROFFH 41
#define VAL_FREE 42
#define VOL_POS_VECTOR 49

typedef enum{
	REGULAR=1,
	IRREGULAR_SIMPLE=2,
	IRREGULAR_EXCEL=3
}TankType;

typedef struct{
	bool active = false;

}TankPositions;

class Deposito{
private:
	bool available=false;

	int Rdiv=1000;
	TankType tankType;
	int tankNumber,numLevels;
	float L[10]={0},W[10]={0},H[10]={0};
	float PVPI[6]={0};
	float RIA,RSA,ROFFI,ROFFS;
	float RINFL[4];//RINF1,RINF2,RINF3,RINF4
	double VOL[101]={0};
public:
	Deposito(){

	}
	int getNumber(){
		return(tankNumber);
	}
	int getType(){
		return(tankType);
	}
	float getR(uint16_t ADC_value){
		return(Rdiv*ADC_value)/float(4095-ADC_value);
	}
 	void setDimensionL(uint16_t L, uint8_t position){
 		this->L[position]=(float)L;
 	}
 	void setDimensionW(uint16_t W, uint8_t position){
		this->W[position]=(float)W;
	}
 	void setDimensionH(uint16_t H, uint8_t position){
		this->H[position]=(float)H;
	}

 	void setVolumes(uint8_t* VOL){
 		for(int i=0;i<=100;i++){
 			this->VOL[i]=(float)VOL[i];
 		}
 	}
 	void setVolumes(double* VOL, int length){
		for(int i=0;i<length;i++){
			this->VOL[i]=(double)VOL[i];
		}
		//for(int i=0;i<=100;i++){
		//	Serial2.println(this->VOL[i]);
		//}
	}
 	void setResistor(float Resistor, int position){
 		if(position==1){
 			RIA=Resistor;
 		}
 		if(position==2){
 			RINFL[0]=Resistor;
 		}
 		if(position==3){
 			RINFL[1]=Resistor;
		}
 		if(position==4){
 			RINFL[2]=Resistor;
		}
 		if(position==5){
 			RINFL[3]=Resistor;
		}
 		if(position==6){
			RSA=Resistor;
		}
 		if(position==7){
			ROFFI=Resistor;
		}
 		if(position==8){
			ROFFS=Resistor;
		}
 	}
 	void registerTank(int tankNumber, int numLevels, TankType tankType){
 		this->tankNumber=tankNumber;
 		this->tankType=tankType;
 		this->numLevels=numLevels;

 		for(int i=1;i<numLevels;i++){
 			PVPI[i]=(100*(RINFL[i-1]-RIA)) / float(RSA-RIA);
		}
 		PVPI[0]=0;
 		PVPI[numLevels]=100;

 		for(int i=0;i<(numLevels*2);i++){
 			int j=i;
			while(j>1){
				j-=2;
				H[i]=H[i]-H[j];
			}
		}
 	}

 	float totalPercent(float R){//PVATT
 		float PVATT=10;
 		if(tankType==REGULAR){
 			PVATT = (100*(R-RIA)) / float(RSA-RIA);
 		}
 		if(tankType==IRREGULAR_SIMPLE){
 			PVATT = (100*totalVolume(R)) / totalVolume(RSA);
 		}
 		if(tankType==IRREGULAR_EXCEL){
 			float VARA=totalVolume(R);
 			float VATT=VOL[100];
 			PVATT = (100*VARA)/VATT;
 		}
 		return(PVATT);
 	}
 	float totalVolume(float R){
 		float VATT = 0;
 		if(tankType==REGULAR){
 			float VATTI = (L[0]*W[0]*H[9]*(totalPercent(R)/float(100)))/float(1000);
 			float VATTS = (L[9]*W[9]*H[9]*(totalPercent(R)/float(100)))/float(1000);
 			VATT=(1.5*VATTI)-(0.5*VATTS);
 		}
 		if(tankType==IRREGULAR_SIMPLE){
 			float PVATV = (100*(R-RIA)) / float(RSA-RIA);
 			float VATTS,VATTT;

 	 		for(int i=0;i<numLevels;i++){
 	 			if(PVATV<PVPI[i+1]){
 	 				VATTS=(L[(i*2)]*W[(i*2)]*H[(i*2)]*(PVATV-PVPI[i])) / float(1000*(PVPI[i+1]-PVPI[i]));
 	 				VATTT=(L[(i*2)+1]*W[(i*2)+1]*H[(i*2)+1]*(PVATV-PVPI[i])) / float(1000*(PVPI[i+1]-PVPI[i]));
 	 				VATT+=(1.5*VATTS)-(0.5*VATTT);
 	 				break;
 	 			}
 	 			else{
 	 				VATTS=(L[(i*2)]*W[(i*2)]*H[(i*2)]) / float(1000);
 	 				VATTT=(L[(i*2)+1]*W[(i*2)+1]*H[(i*2)+1]) / float(1000);
 	 				VATT+=(1.5*VATTS)-(0.5*VATTT);
 	 			}
 	 		}
 		}
 		if(tankType==IRREGULAR_EXCEL){
 			float PVARA = (100*(R-RIA)) / float(RSA-RIA);
 			if(PVARA<=0) PVARA=0;
 			if(PVARA>=100) PVARA=100;
 			float PVARA_decimal = (PVARA - float(int(PVARA)));
 			float VATT_low = VOL[int(PVARA)];
 			float VATT_high = VOL[int(PVARA)+1];
 			VATT = VATT_low + ((VATT_high-VATT_low) * PVARA_decimal);
 		}
 		return(VATT);
 	}
 	float PercentWithOffset(float R){
 		float PVAOFFU=0;
 		if(tankType==REGULAR){
 			PVAOFFU = (100*(R-ROFFI)) / float(ROFFS-ROFFI);
 		}
 		if(tankType==IRREGULAR_SIMPLE){
 			PVAOFFU = (100*VolumeWithOffset(R)) / (totalVolume(ROFFS) - totalVolume(ROFFI));
 		}
 		if(tankType==IRREGULAR_EXCEL){
 			float VAOFFU=VolumeWithOffset(R);
 			float VOFFI=VolumeWithOffset(ROFFI);
 			float VOFFS=VolumeWithOffset(ROFFS);
 			PVAOFFU = (100*VAOFFU) / (VOFFS - VOFFI);
 		}
 		return(PVAOFFU);
 	}

 	float VolumeWithOffset(float R){
 		float VAOFFU=0;
 		if(tankType==REGULAR){
 	 		float VATT=totalVolume(R);
 	 		float PVATTI=totalPercent(ROFFI);
 	 		float VATTI_temp = (L[0]*W[0]*H[9]*(PVATTI/float(100)))/float(1000);
			float VATTS_temp = (L[9]*W[9]*H[9]*(PVATTI/float(100)))/float(1000);
			float VATTI=(1.5*VATTI_temp)-(0.5*VATTS_temp);
 	 		VAOFFU=VATT-VATTI;
			Serial3.print("   VATTI=");
			Serial3.print(VATTI_temp,2);
			Serial3.print("   VATTS=");
			Serial3.print(VATTS_temp,2);
			Serial3.print("   VAOFFU=");
			Serial3.println(VAOFFU);
 		}
 		if(tankType==IRREGULAR_SIMPLE){
 			float VATT=totalVolume(R);
 			float VATTI=totalVolume(ROFFI);
 			VAOFFU = VATT-VATTI;
 		}
 		if(tankType==IRREGULAR_EXCEL){
 			float VATT=totalVolume(R);
 			float VATTI=totalVolume(ROFFI);
 			VAOFFU = VATT - VATTI;
 		}
 		return(VAOFFU);
 	}
 	void setAvailable(bool status){
 		available = status;
 	}
 	bool isAvailable(){
 		return available;
 	}

};



#endif /* SRC_CONFIG_PINES_OBJETOS_TANQUE_H_ */
