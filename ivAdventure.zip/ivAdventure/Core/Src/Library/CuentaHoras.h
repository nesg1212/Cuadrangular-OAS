/*
 * CuentaHoras.h
 *
 *  Created on: 24/02/2021
 *      Author: Ing.JoseBenitez
 */

#ifndef SRC_LIBRARY_CUENTAHORAS_H_
#define SRC_LIBRARY_CUENTAHORAS_H_

class CuentaHoras{
private:
	uint8_t hour_init;
	uint8_t min_init;
	uint8_t sec_init;
public:
	CuentaHoras(){}

	void init(uint8_t hour_init, uint8_t min_init, uint8_t sec_init){
		this->hour_init = hour_init;
		this->min_init = min_init;
		this->sec_init = sec_init;
	}

	bool diff(uint8_t hour_act, uint8_t min_act, uint8_t sec_act, uint8_t* minTras, uint8_t* secTras, uint8_t min_max){
		uint32_t actTime = (min_act*60) + sec_act;
		uint32_t prevTime = (min_init*60) + sec_init;
		uint32_t secElapsed;

		if((actTime - prevTime) < 0){
			secElapsed = (3600-prevTime) + actTime;
		}
		else{
			secElapsed = actTime - prevTime;
		}

		*minTras = int(secElapsed/60);
		*secTras = secElapsed - (*minTras*60);

		if(*minTras >= min_max){
			uint32_t secElapsed2 = prevTime + (*minTras*60) + *secTras;
			if(secElapsed2 > 3600){
				secElapsed2 = (3600-secElapsed2);
			}
			this->min_init = int(secElapsed2/60);
			this->sec_init = secElapsed2 - (min_init*60);
			*minTras -= min_max;
			return(true);
		}
		return(false);
	}

	void substractTime(uint8_t* minTras, uint8_t* secTras){
		uint32_t subtractTime = (*minTras*60) + *secTras;
		uint32_t prevTime = (min_init*60) + sec_init;
		uint32_t secElapsed;

		if((prevTime - subtractTime) < 0){
			secElapsed = (3600-subtractTime) + prevTime;
		}
		else{
			secElapsed = prevTime - subtractTime;
		}

		min_init = int(secElapsed/60);
		sec_init = secElapsed - (min_init*60);
	}

//	bool isTimeFlag(uint8_t hour_act, uint8_t min_act, uint8_t sec_act,uint8_t min_max){
//		uint32_t actTime = (hour_act*3600) + (min_act*60) + sec_act;
//		uint32_t prevTime = (hour_init*3600) + (min_init*60) + sec_init;
//		uint32_t sec_minMax = min_max*60;
//		uint32_t secElapsed;
//
//		if((actTime - prevTime) < 0){
//			secElapsed = (86400-prevTime) + actTime;
//		}
//		else{
//			secElapsed = actTime - prevTime;
//		}
//
//		//Serial2.print("transcurrido ->");
//		//Serial2.println((int)secElapsed);
//
//		if(secElapsed*10 >= sec_minMax){
//			hour_init = hour_act;
//			min_init = min_act;
//			sec_init = sec_act;
//			return(true);
//		}
//		return(false);
//	}


};

#endif /* SRC_LIBRARY_CUENTAHORAS_H_ */
