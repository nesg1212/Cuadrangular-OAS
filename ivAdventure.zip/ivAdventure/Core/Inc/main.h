/*
 * main.h
 *
 *  Created on: Oct 5, 2021
 *      Author: dac
 */

#ifndef CORE_INC_MAIN_H_
#define CORE_INC_MAIN_H_


#ifdef __cplusplus
extern "C" {
#endif

#if defined(STM32F411xE)
 #include "stm32f4xx_hal.h"

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);
void Error_Handler(void);

 #define B1_Pin GPIO_PIN_13
 #define B1_GPIO_Port GPIOC
 #define USART_TX_Pin GPIO_PIN_2
 #define USART_TX_GPIO_Port GPIOA
 #define USART_RX_Pin GPIO_PIN_3
 #define USART_RX_GPIO_Port GPIOA
 #define LD2_Pin GPIO_PIN_5
 #define LD2_GPIO_Port GPIOA
 #define TMS_Pin GPIO_PIN_13
 #define TMS_GPIO_Port GPIOA
 #define TCK_Pin GPIO_PIN_14
 #define TCK_GPIO_Port GPIOA
 #define SWO_Pin GPIO_PIN_3
 #define SWO_GPIO_Port GPIOB

#elif defined(STM32F107xC)

 #include "stm32f1xx_hal.h"

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);
void Error_Handler(void);

 #define B1_Pin GPIO_PIN_13
 #define B1_GPIO_Port GPIOC
 #define USART_TX_Pin GPIO_PIN_2
 #define USART_TX_GPIO_Port GPIOA
 #define USART_RX_Pin GPIO_PIN_3
 #define USART_RX_GPIO_Port GPIOA
 #define LD2_Pin GPIO_PIN_5
 #define LD2_GPIO_Port GPIOA
 #define TMS_Pin GPIO_PIN_13
 #define TMS_GPIO_Port GPIOA
 #define TCK_Pin GPIO_PIN_14
 #define TCK_GPIO_Port GPIOA
 #define SWO_Pin GPIO_PIN_3
 #define SWO_GPIO_Port GPIOB

 #define SIMCom_RST_Pin GPIO_PIN_3
 #define SIMCom_RST_GPIO_Port GPIOE
 #define SIMCom_EN_Pin GPIO_PIN_4
 #define SIMCom_EN_GPIO_Port GPIOE
 #define SIMCom_TXD_Pin GPIO_PIN_12
 #define SIMCom_TXD_GPIO_Port GPIOC
 #define SIMCom_RXD_Pin GPIO_PIN_2
 #define SIMCom_RXD_GPIO_Port GPIOD

#else
 #error "Please select the ivAdventure target device "
#endif


#ifdef __cplusplus
}
#endif


#endif /* CORE_INC_MAIN_H_ */
